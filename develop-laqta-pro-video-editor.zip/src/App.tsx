import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowUpFromLine,
  Check,
  Clapperboard,
  Columns2,
  Save,
  Wrench,
  X,
} from 'lucide-react';
import { ExportModal } from './components/ExportModal';
import { CapCutTemplatePreset, HomeScreen } from './components/HomeScreen';
import { QuranGenerationRequest } from './components/QuranStudioPanel';
import { TimelinePanel } from './components/TimelinePanel';
import {
  EDITOR_TOOL_TABS,
  ToolDrawerPanel,
} from './components/ToolDrawerPanel';
import { buildCompleteQuranScene } from './services/quranService';
import { VideoPreviewPlayer } from './components/VideoPreviewPlayer';
import {
  CAPCUT_READY_TEMPLATES,
  CapCutStickerItem,
  TEXT_STYLE_PRESETS,
} from './constants/presets';
import {
  BuiltInSoundPreset,
  generateBuiltInSoundAsset,
} from './engine/audioEngine';
import { computeClipSlots, computeProjectDuration } from './engine/compositor';
import {
  generateSampleMp4File,
  importMediaFile,
} from './services/mediaService';
import {
  fetchStockNatureVideoFile,
  resolveNatureVideoFilesForQuran,
  StockNatureClipSpec,
} from './services/natureVideoService';
import {
  deleteProjectFromStorage,
  listSavedProjects,
  loadProjectFromStorage,
  saveProjectToStorage,
} from './services/storageService';
import { buildWordTimingsForPhrase } from './services/subtitleService';
import {
  ActiveToolTab,
  AspectRatio,
  AudioClip,
  DEFAULT_ADJUSTMENTS,
  MediaAsset,
  OverlayClip,
  ProjectData,
  ProjectStateSnapshot,
  ProjectSummary,
  TextOverlay,
  TransitionType,
  VideoClip,
  VideoEffectClip,
  VideoEffectType,
} from './types/editor';

interface ToastBanner {
  id: number;
  message: string;
  tone: 'info' | 'error' | 'success';
}

type WorkspaceLayoutMode = 'video-focus' | 'split-studio' | 'tools-full';

function getInitialLayoutMode(): WorkspaceLayoutMode {
  if (typeof window !== 'undefined' && window.innerWidth < 1024) {
    return 'video-focus';
  }
  return 'split-studio';
}

function createEmptyProject(name = 'مشروع جديد'): ProjectData {
  const now = Date.now();
  return {
    id: `proj_${now}_${Math.random().toString(36).slice(2, 6)}`,
    name,
    createdAt: now,
    updatedAt: now,
    aspectRatio: '9:16',
    canvasBgColor: '#000000',
    assets: [],
    clips: [],
    texts: [],
    effects: [],
    overlays: [],
    audioClips: [],
  };
}

function snapshotOf(p: ProjectData): ProjectStateSnapshot {
  return JSON.parse(
    JSON.stringify({
      clips: p.clips,
      texts: p.texts,
      effects: p.effects || [],
      overlays: p.overlays || [],
      audioClips: p.audioClips,
      aspectRatio: p.aspectRatio,
      canvasBgColor: p.canvasBgColor,
    })
  );
}

export function App() {
  const [view, setView] = useState<'home' | 'editor'>('home');
  const [layoutMode, setLayoutMode] = useState<WorkspaceLayoutMode>(() =>
    getInitialLayoutMode()
  );
  const [exportResPreset, setExportResPreset] = useState<'720p' | '1080p'>(
    '720p'
  );
  const [savedProjects, setSavedProjects] = useState<ProjectSummary[]>([]);
  const [project, setProject] = useState<ProjectData>(() =>
    createEmptyProject()
  );

  const [undoStack, setUndoStack] = useState<ProjectStateSnapshot[]>([]);
  const [redoStack, setRedoStack] = useState<ProjectStateSnapshot[]>([]);
  const gestureSnapshotRef = useRef<ProjectStateSnapshot | null>(null);

  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveToolTab>('edit');
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [selectedTextId, setSelectedTextId] = useState<string | null>(null);
  const [selectedEffectId, setSelectedEffectId] = useState<string | null>(null);
  const [selectedOverlayId, setSelectedOverlayId] = useState<string | null>(
    null
  );
  const [selectedAudioId, setSelectedAudioId] = useState<string | null>(null);

  const [isBusy, setIsBusy] = useState(false);
  const [busyMessage, setBusyMessage] = useState('');
  const [saveState, setSaveState] = useState<'saved' | 'saving'>('saved');
  const [showExportModal, setShowExportModal] = useState(false);
  const [toast, setToast] = useState<ToastBanner | null>(null);

  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const quickMediaInputRef = useRef<HTMLInputElement | null>(null);

  const notify = useCallback(
    (message: string, tone: 'info' | 'error' | 'success' = 'info') => {
      const id = Date.now();
      setToast({ id, message, tone });
      window.setTimeout(() => {
        setToast((curr) => (curr?.id === id ? null : curr));
      }, 4200);
    },
    []
  );

  const refreshSavedProjects = useCallback(async () => {
    const list = await listSavedProjects();
    setSavedProjects(list);
  }, []);

  useEffect(() => {
    refreshSavedProjects();
  }, [refreshSavedProjects]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setLayoutMode((prev) =>
          prev === 'video-focus' ? 'split-studio' : prev
        );
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const effects = useMemo(() => project.effects || [], [project.effects]);
  const overlays = useMemo(() => project.overlays || [], [project.overlays]);

  const totalDuration = useMemo(
    () =>
      computeProjectDuration(
        project.clips,
        project.texts,
        project.audioClips
      ),
    [project.audioClips, project.clips, project.texts]
  );

  const selectedClip = useMemo(
    () => project.clips.find((c) => c.id === selectedClipId) || null,
    [project.clips, selectedClipId]
  );
  const selectedText = useMemo(
    () => project.texts.find((t) => t.id === selectedTextId) || null,
    [project.texts, selectedTextId]
  );
  const selectedEffect = useMemo(
    () => effects.find((e) => e.id === selectedEffectId) || null,
    [effects, selectedEffectId]
  );
  const selectedOverlay = useMemo(
    () => overlays.find((o) => o.id === selectedOverlayId) || null,
    [overlays, selectedOverlayId]
  );
  const selectedAudio = useMemo(
    () => project.audioClips.find((a) => a.id === selectedAudioId) || null,
    [project.audioClips, selectedAudioId]
  );

  const clearAllSelections = () => {
    setSelectedClipId(null);
    setSelectedTextId(null);
    setSelectedEffectId(null);
    setSelectedOverlayId(null);
    setSelectedAudioId(null);
  };

  const openToolTab = useCallback((tab: ActiveToolTab) => {
    setActiveTab(tab);
    setLayoutMode((prev) => (prev === 'video-focus' ? 'split-studio' : prev));
  }, []);

  const mutateProjectWithHistory = useCallback(
    (mutator: (prev: ProjectData) => ProjectData) => {
      setProject((prev) => {
        const snap = snapshotOf(prev);
        setUndoStack((u) => [...u.slice(-44), snap]);
        setRedoStack([]);
        return mutator(prev);
      });
    },
    []
  );

  const handleUndo = useCallback(() => {
    setUndoStack((u) => {
      if (u.length === 0) return u;
      const last = u[u.length - 1];
      setProject((curr) => {
        setRedoStack((r) => [...r, snapshotOf(curr)]);
        return {
          ...curr,
          ...last,
        };
      });
      return u.slice(0, -1);
    });
  }, []);

  const handleRedo = useCallback(() => {
    setRedoStack((r) => {
      if (r.length === 0) return r;
      const next = r[r.length - 1];
      setProject((curr) => {
        setUndoStack((u) => [...u, snapshotOf(curr)]);
        return {
          ...curr,
          ...next,
        };
      });
      return r.slice(0, -1);
    });
  }, []);

  const persistNow = useCallback(
    async (projToSave: ProjectData, showToast = false) => {
      setSaveState('saving');
      try {
        let thumb = projToSave.thumbnailDataUrl;
        if (previewCanvasRef.current && projToSave.clips.length > 0) {
          try {
            thumb = previewCanvasRef.current.toDataURL('image/jpeg', 0.6);
          } catch {
            // ignore
          }
        }
        await saveProjectToStorage({
          ...projToSave,
          thumbnailDataUrl: thumb,
        });
        setSaveState('saved');
        await refreshSavedProjects();
        if (showToast) {
          notify('تم حفظ المشروع في مشاريعك ✓', 'success');
        }
      } catch {
        setSaveState('saved');
      }
    },
    [notify, refreshSavedProjects]
  );

  useEffect(() => {
    if (view !== 'editor') return;
    setSaveState('saving');
    const timer = window.setTimeout(() => {
      persistNow(project, false);
    }, 950);
    return () => clearTimeout(timer);
  }, [project, view, persistNow]);

  const buildClipFromAsset = (asset: MediaAsset): VideoClip => ({
    id: `clip_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    assetId: asset.id,
    type: asset.type === 'image' ? 'image' : 'video',
    name: asset.name,
    trimStart: 0,
    duration: Number(Math.max(0.5, asset.duration).toFixed(2)),
    sourceDuration: Math.max(0.5, asset.duration),
    speed: 1,
    volume: 100,
    muted: false,
    fitMode: 'blur-fill',
    rotation: 0,
    flipH: false,
    kenBurns: asset.type === 'image',
    adjustments: { ...DEFAULT_ADJUSTMENTS },
    transitionIn: { type: 'none', duration: 0.7 },
  });

  const buildOverlayFromAsset = (
    asset: MediaAsset,
    atTime: number
  ): OverlayClip => ({
    id: `ov_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    assetId: asset.id,
    type: asset.type === 'image' ? 'image' : 'video',
    name: asset.name,
    startTime: Number(Math.max(0, atTime).toFixed(2)),
    trimStart: 0,
    duration: Number(Math.min(5, Math.max(1.5, asset.duration)).toFixed(2)),
    sourceDuration: Math.max(0.5, asset.duration),
    x: 74,
    y: 26,
    scale: 36,
    opacity: 100,
    borderRadius: 22,
  });

  const buildAudioClipFromAsset = (
    asset: MediaAsset,
    atTime: number,
    category: 'music' | 'voiceover' | 'sfx' = 'music'
  ): AudioClip => ({
    id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    assetId: asset.id,
    name: asset.name,
    category,
    startTime: Number(Math.max(0, atTime).toFixed(2)),
    trimStart: 0,
    duration: Number(Math.max(0.4, asset.duration).toFixed(2)),
    sourceDuration: Math.max(0.4, asset.duration),
    volume: 90,
    muted: false,
    fadeIn: 0.15,
    fadeOut: 0.25,
  });

  const buildTemplateLayersForClips = useCallback(
    async (
      templateId: CapCutTemplatePreset,
      rawClips: VideoClip[],
      overrideAspect?: AspectRatio
    ): Promise<{
      clips: VideoClip[];
      texts: TextOverlay[];
      effects: VideoEffectClip[];
      audioAssets: MediaAsset[];
      audioClips: AudioClip[];
      aspectRatio: AspectRatio;
      title: string;
    }> => {
      const tpl =
        CAPCUT_READY_TEMPLATES.find((t) => t.id === templateId) ||
        CAPCUT_READY_TEMPLATES[0];

      let workingClips = rawClips.map((c) => ({ ...c }));
      // If user uploaded just 1 video clip for a template, automatically split it at midpoint
      // so the template's signature transition & dual color grade shine immediately!
      if (workingClips.length === 1 && workingClips[0].duration >= 1.4) {
        const c0 = workingClips[0];
        const half = Number((c0.duration / 2).toFixed(2));
        const part1: VideoClip = { ...c0, duration: half };
        const part2: VideoClip = {
          ...c0,
          id: `clip_${Date.now()}_t2`,
          name: `${c0.name} (2)`,
          trimStart:
            c0.type === 'image'
              ? 0
              : Number((c0.trimStart + half * (c0.speed || 1)).toFixed(2)),
          duration: Number((c0.duration - half).toFixed(2)),
          transitionIn: {
            type: tpl.transition,
            duration: tpl.transitionDuration,
          },
        };
        workingClips = [part1, part2];
      }

      // 100% PURE UNALTERED CLIPS: Zero forced filters, zero forced contrast tweaks, zero forced transitions!
      const gradedClips = workingClips.map((c) => ({
        ...c,
        fitMode: 'cover' as const,
        adjustments: { ...DEFAULT_ADJUSTMENTS },
        transitionIn: { type: 'none' as TransitionType, duration: 0.7 },
      }));

      const totalDur = Math.max(
        2.5,
        gradedClips.reduce((acc, c) => acc + c.duration, 0)
      );

      const builtTexts: TextOverlay[] = tpl.textsBlueprint.map((bp, idx) => {
        const preset =
          TEXT_STYLE_PRESETS.find((p) => p.id === bp.presetId) ||
          TEXT_STYLE_PRESETS[0];
        const dur = Math.max(0.7, Number((totalDur * bp.durRatio).toFixed(2)));
        return {
          id: `txt_tpl_${Date.now()}_${idx}`,
          text: bp.text,
          originalText: bp.text,
          startTime: Number((totalDur * bp.startRatio).toFixed(2)),
          duration: dur,
          fontFamily: preset.style.fontFamily || 'Cairo',
          fontSize: bp.fontSize || preset.style.fontSize || 48,
          fontWeight: preset.style.fontWeight || 800,
          color: preset.style.color || '#FFFFFF',
          strokeColor: preset.style.strokeColor || '#000000',
          strokeWidth: preset.style.strokeWidth ?? 6,
          shadowColor: preset.style.shadowColor || '#000000',
          shadowBlur: preset.style.shadowBlur ?? 14,
          bgColor: preset.style.bgColor || '#09090B',
          bgOpacity: preset.style.bgOpacity ?? 45,
          bgRadius: preset.style.bgRadius ?? 20,
          opacity: 100,
          align: 'center',
          x: 50,
          y: bp.y,
          animation: 'none',
          presetId: preset.id,
          isSubtitle: Boolean(bp.highlightWords),
          isSticker: Boolean(bp.isSticker),
          highlightWords: Boolean(bp.highlightWords),
          highlightColor:
            bp.highlightColor || preset.style.highlightColor || '#00E5DF',
          wordTimings: buildWordTimingsForPhrase(bp.text, dur),
        };
      });

      const audioAssets: MediaAsset[] = [];
      const builtAudios: AudioClip[] = [];

      // Dedicated Holy Quran Template Branch:
      // Pure Real Multi-Scene HD Nature Videos + 1:00+ Min Recitation + Millisecond-Synced Written Ayahs
      // ZERO pre-applied Effects, ZERO pre-applied Filters, ZERO pre-applied Transitions!
      if (tpl.quranPreset) {
        const finalAspect = overrideAspect || tpl.aspect;
        const qScene = await buildCompleteQuranScene({
          surahNumber: tpl.quranPreset.surahNumber,
          startAyah: tpl.quranPreset.startAyah,
          endAyah: tpl.quranPreset.endAyah,
          reciterId: tpl.quranPreset.reciterId,
          visualThemeId: 'waterfall-nature-reels',
          targetAspectRatio: finalAspect,
          minDurationSec: tpl.quranPreset.minDurationSec ?? 64,
          customIncludeEnglish: tpl.quranPreset.includeEnglish,
          customHighlightWords: tpl.quranPreset.highlightWords,
          onStatus: (msg) => setBusyMessage(msg),
        });

        const targetDur = Math.max(60, qScene.totalDuration);
        const maxShotSec = 7.5;
        const tiledClips: VideoClip[] = [];
        let acc = 0;
        let safety = 0;
        while (
          acc < targetDur - 0.05 &&
          gradedClips.length > 0 &&
          safety < 160
        ) {
          const base = gradedClips[safety % gradedClips.length];
          const passNum = Math.floor(safety / gradedClips.length);
          const trimOffset =
            base.sourceDuration > maxShotSec + 1
              ? ((passNum * 4.0) % Math.max(1, base.sourceDuration - maxShotSec))
              : 0;
          const remain = Number((targetDur - acc).toFixed(2));
          const availDur = Math.max(0.8, base.sourceDuration - trimOffset);
          const segDur = Math.min(maxShotSec, availDur, Math.max(0.6, remain));
          tiledClips.push({
            ...base,
            id: `clip_q_${Date.now()}_${safety}`,
            trimStart: Number(trimOffset.toFixed(2)),
            muted: true,
            fitMode: 'cover',
            duration: Number(segDur.toFixed(2)),
            adjustments: { ...DEFAULT_ADJUSTMENTS },
            transitionIn: { type: 'none', duration: 0.7 },
          });
          acc += segDur;
          safety++;
        }

        if (qScene.audioAsset && qScene.recitationAudioClip) {
          audioAssets.push(qScene.audioAsset);
          builtAudios.push(qScene.recitationAudioClip);
        }

        return {
          clips: tiledClips,
          texts: qScene.textOverlays,
          effects: [],
          audioAssets,
          audioClips: builtAudios,
          aspectRatio: finalAspect,
          title: tpl.title,
        };
      }

      if (tpl.soundPreset) {
        const musicAsset = await generateBuiltInSoundAsset(tpl.soundPreset);
        audioAssets.push(musicAsset);
        const musicClip = buildAudioClipFromAsset(musicAsset, 0, 'music');
        musicClip.duration = Number(
          Math.min(musicAsset.duration, totalDur).toFixed(2)
        );
        musicClip.volume = 68;
        builtAudios.push(musicClip);
      }

      if (tpl.sfxPreset) {
        const sfxAsset = await generateBuiltInSoundAsset(tpl.sfxPreset);
        audioAssets.push(sfxAsset);
        const sfxTime =
          gradedClips.length > 1
            ? Math.max(0, gradedClips[0].duration - 0.3)
            : 0.1;
        builtAudios.push(buildAudioClipFromAsset(sfxAsset, sfxTime, 'sfx'));
      }

      return {
        clips: gradedClips,
        texts: builtTexts,
        effects: [],
        audioAssets,
        audioClips: builtAudios,
        aspectRatio: overrideAspect || tpl.aspect,
        title: tpl.title,
      };
    },
    []
  );

  const importFilesIntoProject = useCallback(
    async (
      files: FileList,
      startFreshProject = false,
      asOverlay = false,
      initialTab: ActiveToolTab = 'edit',
      templateId?: CapCutTemplatePreset
    ) => {
      setIsBusy(true);
      setBusyMessage('جاري قراءة الوسائط وتجهيز الخط الزمني...');
      setIsPlaying(false);

      const importedAssets: MediaAsset[] = [];
      const newVideoClips: VideoClip[] = [];
      const newOverlays: OverlayClip[] = [];
      const newAudioClips: AudioClip[] = [];
      let detectedAspect: AspectRatio | null = null;

      try {
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          setBusyMessage(
            `جاري استيراد «${file.name}» (${i + 1}/${files.length})...`
          );
          const { asset, memoryWarning } = await importMediaFile(file);
          importedAssets.push(asset);

          if (memoryWarning) notify(memoryWarning, 'info');

          if (asset.type === 'video' || asset.type === 'image') {
            if (asOverlay && !startFreshProject) {
              newOverlays.push(buildOverlayFromAsset(asset, currentTime));
            } else {
              newVideoClips.push(buildClipFromAsset(asset));
              if (!detectedAspect && asset.width && asset.height) {
                const r = asset.width / asset.height;
                if (r > 1.25) detectedAspect = '16:9';
                else if (r > 0.9 && r <= 1.25) detectedAspect = '1:1';
                else detectedAspect = '9:16';
              }
            }
          } else if (asset.type === 'audio') {
            newAudioClips.push(
              buildAudioClipFromAsset(
                asset,
                startFreshProject ? 0 : currentTime,
                'music'
              )
            );
          }
        }

        if (startFreshProject) {
          const firstName =
            importedAssets[0]?.name.replace(/\.[^.]+$/, '') || 'مشروع جديد';
          const fresh = createEmptyProject(firstName);

          if (templateId && newVideoClips.length > 0) {
            const styled = await buildTemplateLayersForClips(
              templateId,
              newVideoClips
            );
            fresh.name = styled.title;
            fresh.aspectRatio = styled.aspectRatio;
            fresh.assets = [...importedAssets, ...styled.audioAssets];
            fresh.clips = styled.clips;
            fresh.texts = styled.texts;
            fresh.effects = styled.effects;
            fresh.audioClips = [...newAudioClips, ...styled.audioClips];
          } else {
            fresh.aspectRatio = detectedAspect || '9:16';
            fresh.assets = importedAssets;
            fresh.clips = newVideoClips;
            fresh.audioClips = newAudioClips;
          }

          fresh.thumbnailDataUrl = importedAssets.find(
            (a) => a.thumbnailDataUrl
          )?.thumbnailDataUrl;

          setUndoStack([]);
          setRedoStack([]);
          setProject(fresh);
          setCurrentTime(0);
          clearAllSelections();
          setSelectedClipId(fresh.clips[0]?.id || null);
          setActiveTab(initialTab);
          setLayoutMode(
            initialTab !== 'edit' ? 'split-studio' : getInitialLayoutMode()
          );
          setView('editor');
          notify(
            templateId
              ? 'تم تطبيق القالب الجاهز على وسائطك بنجاح! ✨'
              : 'تم فتح المشروع في الاستوديو بنجاح!',
            'success'
          );
        } else {
          mutateProjectWithHistory((prev) => ({
            ...prev,
            assets: [...prev.assets, ...importedAssets],
            clips: [...prev.clips, ...newVideoClips],
            overlays: [...(prev.overlays || []), ...newOverlays],
            audioClips: [...prev.audioClips, ...newAudioClips],
          }));
          if (newOverlays[0]) {
            clearAllSelections();
            setSelectedOverlayId(newOverlays[0].id);
          } else if (newVideoClips[0]) {
            clearAllSelections();
            setSelectedClipId(newVideoClips[0].id);
          } else if (newAudioClips[0]) {
            clearAllSelections();
            setSelectedAudioId(newAudioClips[0].id);
          }
          notify(`تمت إضافة ${importedAssets.length} عنصر بنجاح ✓`, 'success');
        }
      } catch (err) {
        notify(
          err instanceof Error ? err.message : 'تعذر استيراد الملف المختار.',
          'error'
        );
      } finally {
        setIsBusy(false);
        setBusyMessage('');
      }
    },
    [buildTemplateLayersForClips, currentTime, mutateProjectWithHistory, notify]
  );

  // Ready CapCut & Holy Quran 52-Templates Generator (Real HD Nature Videos + Recitation + Synced Ayahs!)
  const handleCreateDemoProject = async (
    template: CapCutTemplatePreset = 'viral-reel',
    overrideAspect?: AspectRatio
  ) => {
    setIsBusy(true);
    setBusyMessage('جاري تجهيز القالب وفيديوهات الطبيعة والتلاوة عالية الدقة...');
    try {
      const tplDef = CAPCUT_READY_TEMPLATES.find((t) => t.id === template);
      const effectiveAspect = overrideAspect || tplDef?.aspect || '9:16';
      const isQuranTpl = Boolean(tplDef?.quranPreset);

      const visualAssets: MediaAsset[] = [];
      const rawClips: VideoClip[] = [];

      if (isQuranTpl || tplDef?.naturePackId) {
        const packToLoad =
          tplDef?.quranPreset?.naturePackId ||
          tplDef?.naturePackId ||
          'mixed-nature';
        const templateIdx = CAPCUT_READY_TEMPLATES.findIndex(
          (t) => t.id === template
        );
        const natureFiles = await resolveNatureVideoFilesForQuran({
          packId: packToLoad,
          isWidescreenLong: effectiveAspect === '16:9',
          sceneCount: 4,
          seedOffset: Math.max(0, templateIdx),
          onStatus: (msg) => setBusyMessage(msg),
        });
        const importedNatureAssets = await Promise.all(
          natureFiles.map((nf) => importMediaFile(nf))
        );
        for (const imported of importedNatureAssets) {
          visualAssets.push(imported.asset);
          const vc = buildClipFromAsset(imported.asset);
          vc.fitMode = 'cover';
          vc.muted = true;
          rawClips.push(vc);
        }
        // If this is a 1-minute+ non-Quran nature template, tile the 4 real nature videos cleanly across 62s!
        if (!isQuranTpl && tplDef?.durationHint?.includes('01:00')) {
          const extended: VideoClip[] = [];
          let acc = 0;
          let k = 0;
          while (acc < 62 && rawClips.length > 0 && k < 20) {
            const base = rawClips[k % rawClips.length];
            const dur = Math.min(7.5, base.sourceDuration, Math.max(1, 62 - acc));
            extended.push({
              ...base,
              id: `clip_nat_${Date.now()}_${k}`,
              duration: Number(dur.toFixed(2)),
            });
            acc += dur;
            k++;
          }
          rawClips.splice(0, rawClips.length, ...extended);
        }
      } else {
        const mp4Desert = await generateSampleMp4File('desert-sunset', 3.0);
        const mp4City = await generateSampleMp4File('neon-city', 3.0);
        const res1 = await importMediaFile(mp4Desert);
        const res2 = await importMediaFile(mp4City);
        visualAssets.push(res1.asset, res2.asset);
        rawClips.push(
          buildClipFromAsset(res1.asset),
          buildClipFromAsset(res2.asset)
        );
      }

      const styled = await buildTemplateLayersForClips(
        template,
        rawClips,
        effectiveAspect
      );

      const demoProj = createEmptyProject(styled.title);
      demoProj.aspectRatio = styled.aspectRatio;
      demoProj.assets = [...visualAssets, ...styled.audioAssets];
      demoProj.clips = styled.clips;
      demoProj.texts = styled.texts;
      demoProj.effects = styled.effects;
      demoProj.audioClips = styled.audioClips;
      demoProj.thumbnailDataUrl = visualAssets[0]?.thumbnailDataUrl;

      setUndoStack([]);
      setRedoStack([]);
      setProject(demoProj);
      setCurrentTime(0.45);
      clearAllSelections();
      setSelectedClipId(styled.clips[0]?.id || null);
      setActiveTab('edit');
      setLayoutMode(getInitialLayoutMode());
      setView('editor');
      notify(`تم فتح قالب «${styled.title}» بنجاح! ✨`, 'success');
    } catch (err) {
      notify(
        err instanceof Error ? err.message : 'تعذر تجهيز القالب.',
        'error'
      );
    } finally {
      setIsBusy(false);
      setBusyMessage('');
    }
  };

  // Apply any of the 16 Ready Templates directly inside the Editor onto current clips!
  const handleApplyTemplateInEditor = useCallback(
    async (templateId: CapCutTemplatePreset) => {
      if (project.clips.length === 0) {
        await handleCreateDemoProject(templateId);
        return;
      }
      setIsBusy(true);
      setBusyMessage('جاري تطبيق القالب الجاهز على مقاطعك...');
      try {
        setIsPlaying(false);
        const styled = await buildTemplateLayersForClips(
          templateId,
          project.clips
        );
        mutateProjectWithHistory((prev) => ({
          ...prev,
          aspectRatio: styled.aspectRatio,
          assets: [...prev.assets, ...styled.audioAssets],
          clips: styled.clips,
          texts: styled.texts,
          effects: styled.effects,
          audioClips: styled.audioClips,
        }));
        setCurrentTime(0.2);
        notify(`تم تطبيق قالب «${styled.title}» على مشروعك بنجاح! ✨`, 'success');
      } finally {
        setIsBusy(false);
        setBusyMessage('');
      }
    },
    [
      buildTemplateLayersForClips,
      mutateProjectWithHistory,
      notify,
      project.clips,
    ]
  );

  // Full Custom Holy Quran Video Generator (114 Surahs × 10 Reciters × 12 Visual Themes + Custom Phone BG!)
  const handleGenerateQuranProject = useCallback(
    async (req: QuranGenerationRequest, fromEditor = false) => {
      setIsBusy(true);
      setIsPlaying(false);
      setBusyMessage('جاري تجهيز الآيات الكريمة والتلاوة الصوتية...');
      try {
        const qScene = await buildCompleteQuranScene({
          surahNumber: req.surahNumber,
          startAyah: req.startAyah,
          endAyah: req.endAyah,
          reciterId: req.reciterId,
          visualThemeId: req.visualThemeId,
          targetAspectRatio: req.targetAspectRatio,
          minDurationSec: req.minDurationSec ?? 64,
          customIncludeEnglish: req.includeEnglish,
          customHighlightWords: req.highlightWords,
          onStatus: (msg) => setBusyMessage(msg),
        });

        let baseAssets: MediaAsset[] = [];
        let seedClips: VideoClip[] = [];

        if (req.customBgFiles && req.customBgFiles.length > 0) {
          setBusyMessage('جاري استيراد فيديو الخلفية من جهازك...');
          for (let i = 0; i < req.customBgFiles.length; i++) {
            const { asset } = await importMediaFile(req.customBgFiles[i]);
            baseAssets.push(asset);
            if (asset.type !== 'audio') {
              const vc = buildClipFromAsset(asset);
              vc.fitMode = 'cover';
              seedClips.push(vc);
            }
          }
        } else if (
          fromEditor &&
          req.keepExistingClips &&
          project.clips.length > 0
        ) {
          baseAssets = [...project.assets];
          seedClips = project.clips.map((c) => ({ ...c, fitMode: 'cover' }));
        } else {
          // Download 4 diverse real camera-filmed HD Nature/Ocean/Mountain/Meadow/Sky/Mosque videos in parallel!
          const natureFiles = await resolveNatureVideoFilesForQuran({
            packId: req.naturePackId || 'mixed-nature',
            isWidescreenLong: req.targetAspectRatio === '16:9',
            sceneCount: 4,
            seedOffset: req.surahNumber,
            onStatus: (msg) => setBusyMessage(msg),
          });
          const importedAll = await Promise.all(
            natureFiles.map((nf) => importMediaFile(nf))
          );
          for (const { asset } of importedAll) {
            baseAssets.push(asset);
            const vc = buildClipFromAsset(asset);
            vc.fitMode = 'cover';
            vc.muted = true;
            seedClips.push(vc);
          }
        }

        // Sequence pure unaltered HD nature shots cleanly across full 1:00+ minute recitation (ZERO forced filters/transitions/effects!)
        const targetDur = Math.max(3.5, qScene.totalDuration);
        const maxShotSec = targetDur > 10 ? 7.5 : Math.max(2.5, targetDur / 2);
        const tiledClips: VideoClip[] = [];
        let acc = 0;
        let idx = 0;
        while (acc < targetDur - 0.05 && seedClips.length > 0 && idx < 160) {
          const srcClip = seedClips[idx % seedClips.length];
          const passNum = Math.floor(idx / seedClips.length);
          const trimOffset =
            srcClip.type === 'video' && srcClip.sourceDuration > maxShotSec + 1
              ? ((passNum * 4.0) %
                  Math.max(1, srcClip.sourceDuration - maxShotSec))
              : 0;
          const remain = Number((targetDur - acc).toFixed(2));
          const availDur =
            srcClip.type === 'image'
              ? 7
              : Math.max(0.8, srcClip.sourceDuration - trimOffset);
          const segDur = Math.min(maxShotSec, availDur, Math.max(0.6, remain));
          tiledClips.push({
            ...srcClip,
            id: `qclip_${Date.now()}_${idx}`,
            trimStart: Number(trimOffset.toFixed(2)),
            muted: true,
            fitMode: 'cover',
            duration: Number(segDur.toFixed(2)),
            adjustments: { ...DEFAULT_ADJUSTMENTS },
            transitionIn: { type: 'none', duration: 0.7 },
          });
          acc += segDur;
          idx++;
        }

        // 100% Empty Effects Track so user adds their own effects freely!
        const qEffects: VideoEffectClip[] = [];

        const extraAssets = qScene.audioAsset ? [qScene.audioAsset] : [];
        const audioClips = qScene.recitationAudioClip
          ? [qScene.recitationAudioClip]
          : [];

        if (fromEditor && req.keepExistingClips) {
          mutateProjectWithHistory((prev) => ({
            ...prev,
            name: qScene.title,
            aspectRatio: qScene.theme.aspectRatio,
            assets: [...prev.assets, ...extraAssets],
            clips: tiledClips,
            texts: qScene.textOverlays,
            effects: qEffects,
            audioClips,
          }));
        } else {
          const freshProj = createEmptyProject(qScene.title);
          freshProj.aspectRatio = qScene.theme.aspectRatio;
          freshProj.assets = [...baseAssets, ...extraAssets];
          freshProj.clips = tiledClips;
          freshProj.texts = qScene.textOverlays;
          freshProj.effects = qEffects;
          freshProj.audioClips = audioClips;
          freshProj.thumbnailDataUrl = baseAssets.find(
            (a) => a.thumbnailDataUrl
          )?.thumbnailDataUrl;

          setUndoStack([]);
          setRedoStack([]);
          setProject(freshProj);
        }

        setCurrentTime(0.25);
        clearAllSelections();
        setSelectedClipId(tiledClips[0]?.id || null);
        setActiveTab('edit');
        setLayoutMode(getInitialLayoutMode());
        setView('editor');
        notify(
          `تم إنشاء الفيديو القرآني لسورة ${qScene.surahNameAr} بالتلاوة والآيات المتزامنة بنجاح! 🕌✨`,
          'success'
        );
      } catch (err) {
        notify(
          err instanceof Error
            ? err.message
            : 'تعذر إنشاء الفيديو القرآني حالياً.',
          'error'
        );
      } finally {
        setIsBusy(false);
        setBusyMessage('');
      }
    },
    [mutateProjectWithHistory, notify, project.assets, project.clips]
  );

  // CapCut Split at Playhead
  const handleSplitAtPlayhead = useCallback(() => {
    const slots = computeClipSlots(project.clips);
    const targetSlot = slots.find(
      (s) => currentTime > s.startTime + 0.2 && currentTime < s.endTime - 0.2
    );
    if (!targetSlot) {
      notify(
        'ضع المؤشر الأبيض داخل المقطع (بعيداً عن الطرف) لتقسيمه.',
        'info'
      );
      return;
    }

    const { clip, index, startTime } = targetSlot;
    const firstDur = Number((currentTime - startTime).toFixed(2));
    const secondDur = Number((clip.duration - firstDur).toFixed(2));
    const secondTrimStart =
      clip.type === 'image'
        ? 0
        : Number((clip.trimStart + firstDur * (clip.speed || 1)).toFixed(2));

    const part1: VideoClip = { ...clip, duration: firstDur };
    const part2: VideoClip = {
      ...clip,
      id: `clip_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: `${clip.name} (2)`,
      trimStart: secondTrimStart,
      duration: secondDur,
      transitionIn: { type: 'none', duration: 0.7 },
    };

    mutateProjectWithHistory((prev) => {
      const nextClips = [...prev.clips];
      nextClips.splice(index, 1, part1, part2);
      return { ...prev, clips: nextClips };
    });
    clearAllSelections();
    setSelectedClipId(part2.id);
    notify('تم تقسيم المقطع بنجاح ✂️', 'success');
  }, [currentTime, mutateProjectWithHistory, notify, project.clips]);

  // Authentic CapCut Freeze Frame (تجميد الإطار الحالي لمدة 2 ثانية)
  const handleFreezeFrameAtPlayhead = useCallback(async () => {
    const canvas = previewCanvasRef.current;
    if (!canvas || project.clips.length === 0) return;

    try {
      const blob = await new Promise<Blob | null>((res) =>
        canvas.toBlob((b) => res(b), 'image/jpeg', 0.92)
      );
      if (!blob) return;

      const file = new File([blob], `تجميد-إطار-${currentTime.toFixed(1)}s.jpg`, {
        type: 'image/jpeg',
      });
      const { asset } = await importMediaFile(file);
      const freezeClip: VideoClip = {
        ...buildClipFromAsset(asset),
        duration: 2.0,
        kenBurns: false,
      };

      const slots = computeClipSlots(project.clips);
      const activeIdx = Math.max(
        0,
        slots.findIndex(
          (s) => currentTime >= s.startTime && currentTime <= s.endTime
        )
      );

      mutateProjectWithHistory((prev) => {
        const nextClips = [...prev.clips];
        nextClips.splice(activeIdx + 1, 0, freezeClip);
        return {
          ...prev,
          assets: [...prev.assets, asset],
          clips: nextClips,
        };
      });
      clearAllSelections();
      setSelectedClipId(freezeClip.id);
      notify('تم تجميد الإطار وإدراجه لمدة ثانيتين ❄️', 'success');
    } catch {
      notify('تعذر التقاط الإطار الحالي.', 'error');
    }
  }, [currentTime, mutateProjectWithHistory, notify, project.clips]);

  // Authentic CapCut Extract Audio (فصل الصوت إلى مسار مستقل)
  const handleExtractClipAudio = useCallback(
    (clip: VideoClip) => {
      const slots = computeClipSlots(project.clips);
      const slot = slots.find((s) => s.clip.id === clip.id);
      const startAt = slot ? slot.startTime : 0;

      const extractedAudio: AudioClip = {
        id: `aud_ext_${Date.now()}`,
        assetId: clip.assetId,
        name: `صوت: ${clip.name}`,
        category: 'music',
        startTime: Number(startAt.toFixed(2)),
        trimStart: clip.trimStart,
        duration: clip.duration,
        sourceDuration: clip.sourceDuration,
        volume: clip.volume || 100,
        muted: false,
        fadeIn: 0.05,
        fadeOut: 0.05,
      };

      mutateProjectWithHistory((prev) => ({
        ...prev,
        clips: prev.clips.map((c) =>
          c.id === clip.id ? { ...c, muted: true } : c
        ),
        audioClips: [...prev.audioClips, extractedAudio],
      }));
      clearAllSelections();
      setSelectedAudioId(extractedAudio.id);
      openToolTab('audio');
      notify('تم استخراج الصوت في مسار مستقل وكتم صوت الفيديو الأصلي 🎵', 'success');
    },
    [mutateProjectWithHistory, notify, openToolTab, project.clips]
  );

  const handleTrimClipToPlayhead = useCallback(
    (edge: 'start' | 'end') => {
      const slots = computeClipSlots(project.clips);
      const slot =
        slots.find((s) => s.clip.id === selectedClipId) ||
        slots.find((s) => currentTime >= s.startTime && currentTime <= s.endTime);

      if (!slot) return;
      const { clip, startTime, endTime } = slot;

      if (edge === 'start') {
        if (currentTime <= startTime + 0.05 || currentTime >= endTime - 0.25) {
          notify('ضع المؤشر داخل المقطع لقص بدايته.', 'info');
          return;
        }
        const cutAmount = currentTime - startTime;
        mutateProjectWithHistory((prev) => ({
          ...prev,
          clips: prev.clips.map((c) =>
            c.id === clip.id
              ? {
                  ...c,
                  trimStart:
                    c.type === 'image'
                      ? 0
                      : Number(
                          (c.trimStart + cutAmount * (c.speed || 1)).toFixed(2)
                        ),
                  duration: Number((c.duration - cutAmount).toFixed(2)),
                }
              : c
          ),
        }));
        setCurrentTime(startTime);
      } else {
        if (currentTime <= startTime + 0.25 || currentTime >= endTime - 0.05) {
          notify('ضع المؤشر داخل المقطع لقص نهايته.', 'info');
          return;
        }
        const newDur = Number((currentTime - startTime).toFixed(2));
        mutateProjectWithHistory((prev) => ({
          ...prev,
          clips: prev.clips.map((c) =>
            c.id === clip.id ? { ...c, duration: newDur } : c
          ),
        }));
      }
    },
    [currentTime, mutateProjectWithHistory, notify, project.clips, selectedClipId]
  );

  const handleMergeClipWithNext = useCallback(() => {
    const idx = project.clips.findIndex((c) => c.id === selectedClipId);
    if (idx === -1 || idx >= project.clips.length - 1) return;

    const clipA = project.clips[idx];
    const clipB = project.clips[idx + 1];

    if (clipA.assetId === clipB.assetId) {
      const merged: VideoClip = {
        ...clipA,
        name: clipA.name.replace(/\s*\(2\)$/, ''),
        duration: Number((clipA.duration + clipB.duration).toFixed(2)),
      };
      mutateProjectWithHistory((prev) => {
        const next = [...prev.clips];
        next.splice(idx, 2, merged);
        return { ...prev, clips: next };
      });
      setSelectedClipId(merged.id);
      notify('تم دمج المقطعين بنجاح ✓', 'success');
    } else {
      mutateProjectWithHistory((prev) => {
        const next = [...prev.clips];
        next[idx + 1] = {
          ...clipB,
          adjustments: { ...clipA.adjustments },
          transitionIn: { type: 'fade', duration: 0.5 },
        };
        return { ...prev, clips: next };
      });
      notify('تم دمج الانتقال واللون بين المقطعين ✓', 'success');
    }
  }, [mutateProjectWithHistory, notify, project.clips, selectedClipId]);

  const handleReorderClip = useCallback(
    (direction: 'prev' | 'next') => {
      const idx = project.clips.findIndex((c) => c.id === selectedClipId);
      if (idx === -1) return;
      const targetIdx = direction === 'prev' ? idx - 1 : idx + 1;
      if (targetIdx < 0 || targetIdx >= project.clips.length) return;

      mutateProjectWithHistory((prev) => {
        const next = [...prev.clips];
        const [moved] = next.splice(idx, 1);
        next.splice(targetIdx, 0, moved);
        return { ...prev, clips: next };
      });
    },
    [mutateProjectWithHistory, project.clips, selectedClipId]
  );

  const handleDuplicateSelected = useCallback(() => {
    if (selectedClipId) {
      const idx = project.clips.findIndex((c) => c.id === selectedClipId);
      if (idx === -1) return;
      const copy: VideoClip = {
        ...JSON.parse(JSON.stringify(project.clips[idx])),
        id: `clip_${Date.now()}_dup`,
      };
      mutateProjectWithHistory((prev) => {
        const next = [...prev.clips];
        next.splice(idx + 1, 0, copy);
        return { ...prev, clips: next };
      });
      setSelectedClipId(copy.id);
    } else if (selectedTextId) {
      const target = project.texts.find((t) => t.id === selectedTextId);
      if (!target) return;
      const copy: TextOverlay = {
        ...JSON.parse(JSON.stringify(target)),
        id: `txt_${Date.now()}_dup`,
        startTime: target.startTime + 0.5,
        y: Math.min(88, target.y + 8),
      };
      mutateProjectWithHistory((prev) => ({
        ...prev,
        texts: [...prev.texts, copy],
      }));
      setSelectedTextId(copy.id);
    } else if (selectedEffectId) {
      const target = effects.find((ef) => ef.id === selectedEffectId);
      if (!target) return;
      const copy: VideoEffectClip = {
        ...target,
        id: `fx_${Date.now()}_dup`,
        startTime: target.startTime + target.duration,
      };
      mutateProjectWithHistory((prev) => ({
        ...prev,
        effects: [...(prev.effects || []), copy],
      }));
      setSelectedEffectId(copy.id);
    } else if (selectedOverlayId) {
      const target = overlays.find((ov) => ov.id === selectedOverlayId);
      if (!target) return;
      const copy: OverlayClip = {
        ...target,
        id: `ov_${Date.now()}_dup`,
        x: Math.min(85, target.x + 6),
        y: Math.min(85, target.y + 6),
      };
      mutateProjectWithHistory((prev) => ({
        ...prev,
        overlays: [...(prev.overlays || []), copy],
      }));
      setSelectedOverlayId(copy.id);
    } else if (selectedAudioId) {
      const target = project.audioClips.find((a) => a.id === selectedAudioId);
      if (!target) return;
      const copy: AudioClip = {
        ...target,
        id: `aud_${Date.now()}_dup`,
        startTime: target.startTime + target.duration,
      };
      mutateProjectWithHistory((prev) => ({
        ...prev,
        audioClips: [...prev.audioClips, copy],
      }));
      setSelectedAudioId(copy.id);
    }
  }, [
    effects,
    mutateProjectWithHistory,
    overlays,
    project.audioClips,
    project.clips,
    project.texts,
    selectedAudioId,
    selectedClipId,
    selectedEffectId,
    selectedOverlayId,
    selectedTextId,
  ]);

  const handleDeleteSelected = useCallback(() => {
    if (selectedTextId) {
      mutateProjectWithHistory((prev) => ({
        ...prev,
        texts: prev.texts.filter((t) => t.id !== selectedTextId),
      }));
      setSelectedTextId(null);
    } else if (selectedEffectId) {
      mutateProjectWithHistory((prev) => ({
        ...prev,
        effects: (prev.effects || []).filter((e) => e.id !== selectedEffectId),
      }));
      setSelectedEffectId(null);
    } else if (selectedOverlayId) {
      mutateProjectWithHistory((prev) => ({
        ...prev,
        overlays: (prev.overlays || []).filter((o) => o.id !== selectedOverlayId),
      }));
      setSelectedOverlayId(null);
    } else if (selectedAudioId) {
      mutateProjectWithHistory((prev) => ({
        ...prev,
        audioClips: prev.audioClips.filter((a) => a.id !== selectedAudioId),
      }));
      setSelectedAudioId(null);
    } else if (selectedClipId) {
      mutateProjectWithHistory((prev) => ({
        ...prev,
        clips: prev.clips.filter((c) => c.id !== selectedClipId),
      }));
      setSelectedClipId(null);
    }
  }, [
    mutateProjectWithHistory,
    selectedAudioId,
    selectedClipId,
    selectedEffectId,
    selectedOverlayId,
    selectedTextId,
  ]);

  useEffect(() => {
    if (view !== 'editor') return;
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
      } else if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      } else if (e.key.toLowerCase() === 's' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        handleSplitAtPlayhead();
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        handleDeleteSelected();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    view,
    handleUndo,
    handleRedo,
    handleSplitAtPlayhead,
    handleDeleteSelected,
  ]);

  if (view === 'home') {
    return (
      <>
        <HomeScreen
          savedProjects={savedProjects}
          isBusy={isBusy}
          busyMessage={busyMessage}
          onCreateWithFiles={(files, initialTab = 'edit', templateId) =>
            importFilesIntoProject(files, true, false, initialTab, templateId)
          }
          onCreateEmpty={(initialTab = 'media') => {
            const empty = createEmptyProject('مشروع جديد');
            setUndoStack([]);
            setRedoStack([]);
            setProject(empty);
            setCurrentTime(0);
            clearAllSelections();
            setActiveTab(initialTab);
            setLayoutMode('split-studio');
            setView('editor');
          }}
          onCreateDemoProject={handleCreateDemoProject}
          onCreateQuranProject={(req) =>
            handleGenerateQuranProject(req, false)
          }
          onOpenProject={async (projectId) => {
            setIsBusy(true);
            setBusyMessage('جاري فتح المشروع...');
            try {
              const loaded = await loadProjectFromStorage(projectId);
              if (loaded) {
                setUndoStack([]);
                setRedoStack([]);
                setProject(loaded);
                setCurrentTime(0);
                clearAllSelections();
                setSelectedClipId(loaded.clips[0]?.id || null);
                setActiveTab('edit');
                setLayoutMode(getInitialLayoutMode());
                setView('editor');
              }
            } finally {
              setIsBusy(false);
            }
          }}
          onDeleteProject={async (projectId) => {
            await deleteProjectFromStorage(projectId);
            await refreshSavedProjects();
            notify('تم حذف المشروع.', 'info');
          }}
        />
        {toast && (
          <div className="fixed bottom-16 left-4 right-4 sm:right-auto sm:max-w-md z-50 rounded-xl px-4 py-2.5 text-xs font-bold shadow-2xl border bg-[#191B22] border-[#00E5DF]/50 text-white">
            {toast.message}
          </div>
        )}
      </>
    );
  }

  return (
    <div className="h-[100dvh] w-full bg-[#060709] text-white flex flex-col overflow-hidden">
      {/* Hidden Direct Quick-Add Media Input (triggered by CapCut [ + ] button on Timeline!) */}
      <input
        ref={quickMediaInputRef}
        type="file"
        multiple
        accept="video/*,image/*,audio/*"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) {
            importFilesIntoProject(e.target.files, false, false);
            e.target.value = '';
          }
        }}
      />

      {/* ==================== CAPCUT SIGNATURE TOP HEADER BAR ====================
          Right: [ ✕ ] Exit + Editable Name + Auto-save badge
          Center (Desktop): Separated Workspace Mode Toggle
          Left: [ 720P ▾ ] Resolution Pill + [ تصدير ↑ ] CapCut Cyan Pill */}
      <header className="h-12 px-2.5 sm:px-4 bg-[#0B0C0F] border-b border-zinc-900 flex items-center justify-between gap-2 shrink-0">
        {/* Right: CapCut [ ✕ ] Close + Project Title */}
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 flex-1">
          <button
            type="button"
            data-testid="back-home-btn"
            title="حفظ والعودة للمشاريع"
            onClick={async () => {
              setIsPlaying(false);
              await persistNow(project, false);
              setView('home');
            }}
            className="w-8 h-8 rounded-lg hover:bg-zinc-800 text-zinc-200 flex items-center justify-center transition cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>

          <input
            type="text"
            value={project.name}
            onChange={(e) =>
              setProject((p) => ({ ...p, name: e.target.value }))
            }
            aria-label="اسم المشروع"
            className="bg-transparent hover:bg-zinc-900 focus:bg-zinc-900 px-1.5 py-1 rounded text-xs sm:text-sm font-extrabold text-white outline-none min-w-0 flex-1 max-w-[115px] sm:max-w-[200px] truncate"
          />

          <button
            type="button"
            onClick={() => persistNow(project, true)}
            title="حفظ التقدم"
            className="p-1.5 rounded-lg text-zinc-400 hover:text-[#00E5DF] cursor-pointer shrink-0"
          >
            {saveState === 'saving' ? (
              <span className="text-[10px] text-zinc-500">يحفظ..</span>
            ) : (
              <Check className="w-3.5 h-3.5 text-[#00E5DF]" />
            )}
          </button>
        </div>

        {/* Center Desktop Workspace Separation Switcher */}
        <div
          data-testid="workspace-mode-switcher"
          className="hidden md:flex items-center gap-1 bg-[#14151A] p-1 rounded-xl border border-zinc-800 shrink-0"
        >
          <button
            type="button"
            onClick={() => setLayoutMode('split-studio')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
              layoutMode === 'split-studio'
                ? 'bg-[#00E5DF]/20 text-[#00E5DF]'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Columns2 className="w-3.5 h-3.5" />
            <span>استوديو مفصول</span>
          </button>
          <button
            type="button"
            onClick={() => setLayoutMode('video-focus')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
              layoutMode === 'video-focus'
                ? 'bg-white/15 text-white'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Clapperboard className="w-3.5 h-3.5" />
            <span>الفيديو والخط الزمني</span>
          </button>
          <button
            type="button"
            onClick={() => setLayoutMode('tools-full')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
              layoutMode === 'tools-full'
                ? 'bg-amber-500/20 text-amber-300'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>الأدوات كاملة</span>
          </button>
        </div>

        {/* Left: Signature CapCut [ 720P ▾ ] Pill + Cyan [ تصدير ↑ ] Pill */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <select
            aria-label="دقة التصدير"
            value={exportResPreset}
            onChange={(e) =>
              setExportResPreset(e.target.value as '720p' | '1080p')
            }
            className="bg-[#181920] border border-zinc-800 rounded-full px-2.5 py-1 text-[11px] font-black text-zinc-200 outline-none cursor-pointer"
          >
            <option value="720p">720P</option>
            <option value="1080p">1080P</option>
          </select>

          <button
            type="button"
            onClick={() => persistNow(project, true)}
            className="hidden sm:inline-flex p-1.5 rounded-lg bg-[#181920] text-zinc-300 hover:text-white border border-zinc-800 cursor-pointer"
            title="حفظ نسخة"
          >
            <Save className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            data-testid="open-export-modal-btn"
            onClick={() => {
              setIsPlaying(false);
              setShowExportModal(true);
            }}
            className="inline-flex items-center gap-1 px-3.5 py-1.5 rounded-full bg-[#00E5DF] hover:brightness-110 text-zinc-950 font-black text-xs shadow-md transition active:scale-95 cursor-pointer"
          >
            <ArrowUpFromLine className="w-3.5 h-3.5 stroke-[2.8]" />
            <span>تصدير</span>
          </button>
        </div>
      </header>

      {/* ==================== SEPARATED CAPCUT STUDIO WORKSPACE ====================
          Zone A: Pure Uncluttered Video Player Stage + Multi-Track Timeline
          Zone B: Independent CapCut Tools Dock / Tool Sheet (Never crowds the video!) */}
      <main className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden p-1.5 sm:p-2 lg:p-3 gap-2 lg:gap-3">
        {/* ==================== ZONE A: VIDEO STAGE & TIMELINE ==================== */}
        {layoutMode !== 'tools-full' && (
          <section
            data-testid="video-workspace-zone"
            aria-label="شاشة الفيديو والخط الزمني"
            className={`order-1 lg:order-2 flex flex-col rounded-xl bg-[#000000] border border-zinc-800/90 overflow-hidden min-w-0 ${
              layoutMode === 'video-focus'
                ? 'flex-1 min-h-0'
                : 'h-[34dvh] sm:h-[38dvh] lg:h-full lg:flex-1 shrink-0'
            }`}
          >
            {/* Unobstructed Pure-Black CapCut Video Preview */}
            <div className="flex-1 min-h-0 overflow-hidden">
              <VideoPreviewPlayer
                assets={project.assets}
                clips={project.clips}
                texts={project.texts}
                effects={effects}
                overlays={overlays}
                audioClips={project.audioClips}
                aspectRatio={project.aspectRatio}
                bgColor={project.canvasBgColor}
                currentTime={currentTime}
                totalDuration={totalDuration}
                isPlaying={isPlaying}
                canUndo={undoStack.length > 0}
                canRedo={redoStack.length > 0}
                selectedTextId={selectedTextId}
                selectedOverlayId={selectedOverlayId}
                onUndo={handleUndo}
                onRedo={handleRedo}
                onTimeUpdate={setCurrentTime}
                onTogglePlay={() => setIsPlaying((p) => !p)}
                onStopAtEnd={() => setIsPlaying(false)}
                onSelectText={(id) => {
                  clearAllSelections();
                  setSelectedTextId(id);
                  if (id) openToolTab('text');
                }}
                onMoveText={(id, x, y) => {
                  setProject((prev) => ({
                    ...prev,
                    texts: prev.texts.map((t) =>
                      t.id === id ? { ...t, x, y } : t
                    ),
                  }));
                }}
                onSelectOverlay={(id) => {
                  clearAllSelections();
                  setSelectedOverlayId(id);
                  if (id) openToolTab('overlay');
                }}
                onMoveOverlay={(id, x, y) => {
                  setProject((prev) => ({
                    ...prev,
                    overlays: (prev.overlays || []).map((ov) =>
                      ov.id === id ? { ...ov, x, y } : ov
                    ),
                  }));
                }}
                canvasRefExternal={previewCanvasRef}
              />
            </div>

            {/* CapCut Multi-Track Filmstrip Timeline */}
            <div
              className={`shrink-0 ${
                layoutMode === 'split-studio' ? 'hidden lg:block' : 'block'
              }`}
            >
              <TimelinePanel
                assets={project.assets}
                clips={project.clips}
                texts={project.texts}
                effects={effects}
                overlays={overlays}
                audioClips={project.audioClips}
                currentTime={currentTime}
                totalDuration={totalDuration}
                selectedClipId={selectedClipId}
                selectedTextId={selectedTextId}
                selectedEffectId={selectedEffectId}
                selectedOverlayId={selectedOverlayId}
                selectedAudioId={selectedAudioId}
                onSeek={(t) => {
                  setIsPlaying(false);
                  setCurrentTime(t);
                }}
                onQuickAddMedia={() => quickMediaInputRef.current?.click()}
                onQuickAddText={() => openToolTab('text')}
                onQuickAddAudio={() => openToolTab('audio')}
                onToggleMuteAllClips={() => {
                  const shouldMute = !project.clips.every(
                    (c) => c.type === 'image' || c.muted
                  );
                  mutateProjectWithHistory((prev) => ({
                    ...prev,
                    clips: prev.clips.map((c) => ({ ...c, muted: shouldMute })),
                  }));
                  notify(
                    shouldMute
                      ? 'تم كتم الصوت الأصلي للمقاطع 🔇'
                      : 'تم تفعيل الصوت الأصلي للمقاطع 🔊',
                    'info'
                  );
                }}
                onSelectClip={(id) => {
                  clearAllSelections();
                  setSelectedClipId(id);
                }}
                onSelectText={(id) => {
                  clearAllSelections();
                  setSelectedTextId(id);
                  if (id) openToolTab('text');
                }}
                onSelectEffect={(id) => {
                  clearAllSelections();
                  setSelectedEffectId(id);
                  if (id) openToolTab('effects');
                }}
                onSelectOverlay={(id) => {
                  clearAllSelections();
                  setSelectedOverlayId(id);
                  if (id) openToolTab('overlay');
                }}
                onSelectAudio={(id) => {
                  clearAllSelections();
                  setSelectedAudioId(id);
                  if (id) openToolTab('audio');
                }}
                onOpenTransitionForClip={(clipId) => {
                  clearAllSelections();
                  setSelectedClipId(clipId);
                  openToolTab('transitions');
                }}
                onSplitAtPlayhead={handleSplitAtPlayhead}
                onFreezeFrameAtPlayhead={handleFreezeFrameAtPlayhead}
                onMergeClipWithNext={handleMergeClipWithNext}
                onTrimClipToPlayhead={handleTrimClipToPlayhead}
                onReorderClip={handleReorderClip}
                onDuplicateSelected={handleDuplicateSelected}
                onDeleteSelected={handleDeleteSelected}
                onUpdateClipTrimLive={(clipId, newTrim, newDur) => {
                  if (!gestureSnapshotRef.current) {
                    gestureSnapshotRef.current = snapshotOf(project);
                  }
                  setProject((prev) => ({
                    ...prev,
                    clips: prev.clips.map((c) =>
                      c.id === clipId
                        ? { ...c, trimStart: newTrim, duration: newDur }
                        : c
                    ),
                  }));
                }}
                onUpdateTextTimingLive={(textId, start, dur) => {
                  if (!gestureSnapshotRef.current) {
                    gestureSnapshotRef.current = snapshotOf(project);
                  }
                  setProject((prev) => ({
                    ...prev,
                    texts: prev.texts.map((t) =>
                      t.id === textId
                        ? { ...t, startTime: start, duration: dur }
                        : t
                    ),
                  }));
                }}
                onUpdateEffectTimingLive={(effectId, start, dur) => {
                  if (!gestureSnapshotRef.current) {
                    gestureSnapshotRef.current = snapshotOf(project);
                  }
                  setProject((prev) => ({
                    ...prev,
                    effects: (prev.effects || []).map((ef) =>
                      ef.id === effectId
                        ? { ...ef, startTime: start, duration: dur }
                        : ef
                    ),
                  }));
                }}
                onUpdateOverlayTimingLive={(overlayId, start, dur) => {
                  if (!gestureSnapshotRef.current) {
                    gestureSnapshotRef.current = snapshotOf(project);
                  }
                  setProject((prev) => ({
                    ...prev,
                    overlays: (prev.overlays || []).map((ov) =>
                      ov.id === overlayId
                        ? { ...ov, startTime: start, duration: dur }
                        : ov
                    ),
                  }));
                }}
                onUpdateAudioTimingLive={(audioId, start, dur) => {
                  if (!gestureSnapshotRef.current) {
                    gestureSnapshotRef.current = snapshotOf(project);
                  }
                  setProject((prev) => ({
                    ...prev,
                    audioClips: prev.audioClips.map((a) =>
                      a.id === audioId
                        ? { ...a, startTime: start, duration: dur }
                        : a
                    ),
                  }));
                }}
                onCommitGestureHistory={() => {
                  if (gestureSnapshotRef.current) {
                    const snap = gestureSnapshotRef.current;
                    gestureSnapshotRef.current = null;
                    setUndoStack((u) => [...u.slice(-44), snap]);
                    setRedoStack([]);
                  }
                }}
              />
            </div>
          </section>
        )}

        {/* ==================== ZONE B: CAPCUT BOTTOM DOCK / INDEPENDENT TOOLS STUDIO ==================== */}
        {layoutMode === 'video-focus' ? (
          /* Authentic CapCut Bottom Icon Bar cleanly separated below Timeline! */
          <aside
            data-testid="collapsed-tools-dock"
            aria-label="شريط أدوات CapCut"
            className="order-2 lg:order-1 shrink-0 lg:w-[96px] rounded-xl bg-[#14151A] border border-zinc-800/90 px-2 py-2 shadow-2xl"
          >
            <div className="grid grid-cols-7 sm:grid-cols-7 lg:grid-cols-1 gap-1 overflow-y-auto max-h-full">
              {EDITOR_TOOL_TABS.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    data-testid={`tab-${tab.id}`}
                    onClick={() => openToolTab(tab.id)}
                    className="flex flex-col items-center justify-center gap-1 py-1.5 px-0.5 rounded-lg hover:bg-zinc-800 text-zinc-200 hover:text-[#00E5DF] transition cursor-pointer"
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="text-[10px] font-bold truncate max-w-full">
                      {tab.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </aside>
        ) : (
          /* Expanded Separated CapCut Studio Drawer / Side Panel */
          <aside
            aria-label="لوحة أدوات CapCut"
            className={`order-2 lg:order-1 min-h-0 flex flex-col ${
              layoutMode === 'tools-full'
                ? 'flex-1 w-full max-w-4xl mx-auto'
                : 'flex-1 lg:flex-none lg:w-[430px] xl:w-[465px]'
            }`}
          >
            <ToolDrawerPanel
              activeTab={activeTab}
              onChangeTab={setActiveTab}
              aspectRatio={project.aspectRatio}
              bgColor={project.canvasBgColor}
              onChangeAspectRatio={(ar) =>
                mutateProjectWithHistory((p) => ({ ...p, aspectRatio: ar }))
              }
              onChangeBgColor={(c) =>
                mutateProjectWithHistory((p) => ({ ...p, canvasBgColor: c }))
              }
              assets={project.assets}
              clips={project.clips}
              texts={project.texts}
              effects={effects}
              overlays={overlays}
              audioClips={project.audioClips}
              totalDuration={totalDuration}
              currentTime={currentTime}
              selectedClip={selectedClip}
              selectedText={selectedText}
              selectedEffect={selectedEffect}
              selectedOverlay={selectedOverlay}
              selectedAudio={selectedAudio}
              onSelectClip={(id) => {
                clearAllSelections();
                setSelectedClipId(id);
              }}
              onSelectText={(id) => {
                clearAllSelections();
                setSelectedTextId(id);
              }}
              onSelectEffect={(id) => {
                clearAllSelections();
                setSelectedEffectId(id);
              }}
              onSelectOverlay={(id) => {
                clearAllSelections();
                setSelectedOverlayId(id);
              }}
              onSelectAudio={(id) => {
                clearAllSelections();
                setSelectedAudioId(id);
              }}
              onImportFiles={(files, asOv = false) =>
                importFilesIntoProject(files, false, asOv)
              }
              onAddAssetToTimeline={(asset, asOverlay = false) => {
                if (asset.type === 'audio') {
                  const ac = buildAudioClipFromAsset(
                    asset,
                    currentTime,
                    'music'
                  );
                  mutateProjectWithHistory((prev) => ({
                    ...prev,
                    audioClips: [...prev.audioClips, ac],
                  }));
                  clearAllSelections();
                  setSelectedAudioId(ac.id);
                } else if (asOverlay) {
                  const ov = buildOverlayFromAsset(asset, currentTime);
                  mutateProjectWithHistory((prev) => ({
                    ...prev,
                    overlays: [...(prev.overlays || []), ov],
                  }));
                  clearAllSelections();
                  setSelectedOverlayId(ov.id);
                } else {
                  const vc = buildClipFromAsset(asset);
                  mutateProjectWithHistory((prev) => ({
                    ...prev,
                    clips: [...prev.clips, vc],
                  }));
                  clearAllSelections();
                  setSelectedClipId(vc.id);
                }
                notify(`تمت إضافة «${asset.name}» ✓`, 'success');
              }}
              onAddStockNatureVideo={async (spec: StockNatureClipSpec) => {
                setIsBusy(true);
                setBusyMessage(`جاري إضافة مشهد الطبيعة: «${spec.nameAr}»...`);
                try {
                  const file = await fetchStockNatureVideoFile(spec, (m) =>
                    setBusyMessage(m)
                  );
                  const { asset } = await importMediaFile(file);
                  const vc = buildClipFromAsset(asset);
                  vc.fitMode = 'cover';
                  vc.muted = true;
                  mutateProjectWithHistory((prev) => ({
                    ...prev,
                    assets: [...prev.assets, asset],
                    clips: [...prev.clips, vc],
                  }));
                  clearAllSelections();
                  setSelectedClipId(vc.id);
                  notify(`تمت إضافة فيديو الطبيعة «${spec.nameAr}» إلى الخط الزمني! 🏞️`, 'success');
                } finally {
                  setIsBusy(false);
                  setBusyMessage('');
                }
              }}
              onGenerateSampleClip={async (theme) => {
                setIsBusy(true);
                setBusyMessage('جاري توليد لقطة MP4...');
                try {
                  const file = await generateSampleMp4File(theme, 2.8);
                  const { asset } = await importMediaFile(file);
                  const vc = buildClipFromAsset(asset);
                  mutateProjectWithHistory((prev) => ({
                    ...prev,
                    assets: [...prev.assets, asset],
                    clips: [...prev.clips, vc],
                  }));
                  clearAllSelections();
                  setSelectedClipId(vc.id);
                  notify('تمت إضافة اللقطة إلى الخط الزمني!', 'success');
                } finally {
                  setIsBusy(false);
                }
              }}
              onSplitAtPlayhead={handleSplitAtPlayhead}
              onFreezeFrameAtPlayhead={handleFreezeFrameAtPlayhead}
              onExtractClipAudio={handleExtractClipAudio}
              onUpdateClip={(clipId, patch) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  clips: prev.clips.map((c) =>
                    c.id === clipId ? { ...c, ...patch } : c
                  ),
                }));
              }}
              onUpdateClipAdjustments={(clipId, adjPatch) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  clips: prev.clips.map((c) =>
                    c.id === clipId
                      ? { ...c, adjustments: { ...c.adjustments, ...adjPatch } }
                      : c
                  ),
                }));
              }}
              onApplyAdjustmentsToAll={(adj) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  clips: prev.clips.map((c) => ({
                    ...c,
                    adjustments: { ...adj },
                  })),
                }));
                notify('تم التطبيق على جميع المقاطع ✓', 'success');
              }}
              onApplyTransitionToAll={(
                type: TransitionType,
                duration: number
              ) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  clips: prev.clips.map((c, idx) =>
                    idx === 0 ? c : { ...c, transitionIn: { type, duration } }
                  ),
                }));
                notify('تم تطبيق الانتقال على الكل ✓', 'success');
              }}
              onPreviewTransition={(clipId) => {
                const slots = computeClipSlots(project.clips);
                const found = slots.find((s) => s.clip.id === clipId);
                if (found) {
                  setCurrentTime(Math.max(0, found.startTime - 0.25));
                  setIsPlaying(true);
                }
              }}
              onAddText={(presetId = 'bold-words', customInitialText) => {
                const preset =
                  TEXT_STYLE_PRESETS.find((p) => p.id === presetId) ||
                  TEXT_STYLE_PRESETS[0];
                const sampleText =
                  customInitialText || preset.sampleAr || 'نص عربي جديد';
                const dur = Math.min(3.5, Math.max(1.5, totalDuration || 3));
                const staggerOffset = (project.texts.length % 4) * 9 - 12;
                const newText: TextOverlay = {
                  id: `txt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
                  text: sampleText,
                  startTime: Number(Math.max(0, currentTime).toFixed(2)),
                  duration: dur,
                  fontFamily: preset.style.fontFamily || 'Cairo',
                  fontSize: preset.style.fontSize || 52,
                  fontWeight: preset.style.fontWeight || 800,
                  color: preset.style.color || '#FFFFFF',
                  strokeColor: preset.style.strokeColor || '#000000',
                  strokeWidth: preset.style.strokeWidth ?? 6,
                  shadowColor: preset.style.shadowColor || '#000000',
                  shadowBlur: preset.style.shadowBlur ?? 14,
                  bgColor: preset.style.bgColor || '#000000',
                  bgOpacity: preset.style.bgOpacity ?? 0,
                  bgRadius: preset.style.bgRadius ?? 18,
                  opacity: 100,
                  align: 'center',
                  x: 50,
                  y: Math.max(18, Math.min(82, 50 + staggerOffset)),
                  animation: preset.style.animation || 'pop',
                  presetId: preset.id,
                  highlightWords: Boolean(preset.style.highlightWords),
                  highlightColor: preset.style.highlightColor || '#00E5DF',
                  wordTimings: buildWordTimingsForPhrase(sampleText, dur),
                };
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  texts: [...prev.texts, newText],
                }));
                clearAllSelections();
                setSelectedTextId(newText.id);
              }}
              onAddSticker={(sticker: CapCutStickerItem) => {
                const dur = Math.min(3.2, Math.max(1.5, totalDuration || 3));
                const offset = (project.texts.length % 5) * 7 - 14;
                const stickerOverlay: TextOverlay = {
                  id: `stk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
                  text: sticker.text,
                  startTime: Number(Math.max(0, currentTime).toFixed(2)),
                  duration: dur,
                  fontFamily: sticker.fontFamily || 'Cairo',
                  fontSize: sticker.fontSize || 64,
                  fontWeight: 900,
                  color: sticker.color || '#FFFFFF',
                  strokeColor: '#000000',
                  strokeWidth: sticker.bgOpacity ? 0 : 3,
                  shadowColor: '#000000',
                  shadowBlur: 14,
                  bgColor: sticker.bgColor || '#000000',
                  bgOpacity: sticker.bgOpacity || 0,
                  bgRadius: 24,
                  opacity: 100,
                  align: 'center',
                  x: Math.max(20, Math.min(80, 50 + offset)),
                  y: Math.max(20, Math.min(75, 34 + offset)),
                  animation: sticker.animation,
                  isSticker: true,
                  highlightWords: false,
                };
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  texts: [...prev.texts, stickerOverlay],
                }));
                clearAllSelections();
                setSelectedTextId(stickerOverlay.id);
                notify(`تمت إضافة الملصق «${sticker.label}» — اسحبه على الفيديو!`, 'success');
              }}
              onUpdateText={(textId, patch) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  texts: prev.texts.map((t) =>
                    t.id === textId ? { ...t, ...patch } : t
                  ),
                }));
              }}
              onDeleteTextById={(textId) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  texts: prev.texts.filter((t) => t.id !== textId),
                }));
                if (selectedTextId === textId) setSelectedTextId(null);
              }}
              onAddVideoEffect={(
                effectType: VideoEffectType,
                nameAr: string
              ) => {
                const fx: VideoEffectClip = {
                  id: `fx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
                  effectType,
                  name: nameAr,
                  startTime: Number(Math.max(0, currentTime).toFixed(2)),
                  duration: Math.min(
                    3.0,
                    Math.max(1.2, (totalDuration || 3) - currentTime)
                  ),
                  intensity: 80,
                };
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  effects: [...(prev.effects || []), fx],
                }));
                clearAllSelections();
                setSelectedEffectId(fx.id);
                notify(`تمت إضافة مؤثر «${nameAr}» 🌟`, 'success');
              }}
              onUpdateVideoEffect={(effectId, patch) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  effects: (prev.effects || []).map((ef) =>
                    ef.id === effectId ? { ...ef, ...patch } : ef
                  ),
                }));
              }}
              onDeleteEffectById={(effectId) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  effects: (prev.effects || []).filter(
                    (ef) => ef.id !== effectId
                  ),
                }));
                if (selectedEffectId === effectId) setSelectedEffectId(null);
              }}
              onUpdateOverlay={(overlayId, patch) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  overlays: (prev.overlays || []).map((ov) =>
                    ov.id === overlayId ? { ...ov, ...patch } : ov
                  ),
                }));
              }}
              onDeleteOverlayById={(overlayId) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  overlays: (prev.overlays || []).filter(
                    (ov) => ov.id !== overlayId
                  ),
                }));
                if (selectedOverlayId === overlayId) setSelectedOverlayId(null);
              }}
              onDeleteAudioById={(audioId) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  audioClips: prev.audioClips.filter((a) => a.id !== audioId),
                }));
                if (selectedAudioId === audioId) setSelectedAudioId(null);
              }}
              isBusy={isBusy}
              onGenerateQuranInEditor={(req) =>
                handleGenerateQuranProject(req, true)
              }
              onApplyTemplateToProject={handleApplyTemplateInEditor}
              onReplaceAllSubtitles={(newSubs, appendMode = false) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  texts: appendMode
                    ? [...prev.texts, ...newSubs]
                    : [
                        ...prev.texts.filter((t) => !t.isSubtitle),
                        ...newSubs,
                      ],
                }));
                if (newSubs[0]) {
                  clearAllSelections();
                  setSelectedTextId(newSubs[0].id);
                  setCurrentTime(newSubs[0].startTime + 0.05);
                }
              }}
              onReplaceAllTexts={(newTexts) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  texts: newTexts,
                }));
              }}
              onAddBuiltInSound={async (presetId: BuiltInSoundPreset) => {
                const asset = await generateBuiltInSoundAsset(presetId);
                const ac = buildAudioClipFromAsset(
                  asset,
                  presetId.endsWith('sfx') ? currentTime : 0,
                  presetId.endsWith('sfx') ? 'sfx' : 'music'
                );
                if (totalDuration > 0 && ac.duration > totalDuration) {
                  ac.duration = Number(totalDuration.toFixed(2));
                }
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  assets: [...prev.assets, asset],
                  audioClips: [...prev.audioClips, ac],
                }));
                clearAllSelections();
                setSelectedAudioId(ac.id);
                notify(`تمت إضافة «${asset.name}» 🎵`, 'success');
              }}
              onAddRecordedVoiceover={async (blob) => {
                const file = new File(
                  [blob],
                  `تعليق-صوتي-${new Date().toLocaleTimeString('ar-EG')}.webm`,
                  { type: blob.type || 'audio/webm' }
                );
                const { asset } = await importMediaFile(file);
                const ac = buildAudioClipFromAsset(
                  asset,
                  currentTime,
                  'voiceover'
                );
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  assets: [...prev.assets, asset],
                  audioClips: [...prev.audioClips, ac],
                }));
                clearAllSelections();
                setSelectedAudioId(ac.id);
                notify('تمت إضافة التعليق الصوتي المسجل بنجاح 🎙️', 'success');
              }}
              onUpdateAudio={(audioId, patch) => {
                mutateProjectWithHistory((prev) => ({
                  ...prev,
                  audioClips: prev.audioClips.map((a) =>
                    a.id === audioId ? { ...a, ...patch } : a
                  ),
                }));
              }}
              onSeek={(t) => {
                setIsPlaying(false);
                setCurrentTime(t);
              }}
              onNotify={notify}
              isExpandedFull={layoutMode === 'tools-full'}
              onToggleExpandFull={() =>
                setLayoutMode((prev) =>
                  prev === 'tools-full' ? 'split-studio' : 'tools-full'
                )
              }
              onCloseDrawer={() => setLayoutMode('video-focus')}
            />
          </aside>
        )}
      </main>

      {/* Real MP4 Export Modal */}
      {showExportModal && (
        <ExportModal
          project={project}
          initialResolution={exportResPreset}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {/* Sleek CapCut Toast Banner */}
      {toast && (
        <div
          className={`fixed bottom-4 left-4 z-50 rounded-xl px-4 py-2.5 text-xs font-bold shadow-2xl border max-w-sm transition ${
            toast.tone === 'error'
              ? 'bg-rose-950/95 border-rose-500/50 text-rose-100'
              : 'bg-[#191B22]/95 border-[#00E5DF]/50 text-white'
          }`}
        >
          {toast.message}
        </div>
      )}
    </div>
  );
}
export default App;
