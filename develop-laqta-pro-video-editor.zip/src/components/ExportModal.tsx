import React, { useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  Film,
  Share2,
  X,
} from 'lucide-react';
import { getResolutionDimensions } from '../constants/presets';
import { exportProjectToMp4, ExportResult } from '../engine/exporter';
import {
  ExportProgress,
  ExportSettings,
  ProjectData,
} from '../types/editor';

interface ExportModalProps {
  project: ProjectData;
  initialResolution?: '720p' | '1080p';
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  project,
  initialResolution = '720p',
  onClose,
}) => {
  const [settings, setSettings] = useState<ExportSettings>({
    resolution: initialResolution || '720p',
    fps: 30,
    quality: 'high',
  });
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState<ExportProgress | null>(null);
  const [result, setResult] = useState<ExportResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const dims = getResolutionDimensions(
    project.aspectRatio,
    settings.resolution
  );

  const handleStartExport = async () => {
    setErrorMsg(null);
    setResult(null);
    setIsExporting(true);
    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const res = await exportProjectToMp4({
        project,
        settings,
        onProgress: setProgress,
        signal: controller.signal,
      });
      setResult(res);
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        setErrorMsg('تم إلغاء التصدير بناءً على طلبك.');
      } else {
        setErrorMsg(
          err instanceof Error
            ? err.message
            : 'حدث خطأ غير متوقع أثناء ترميز الفيديو.'
        );
      }
    } finally {
      setIsExporting(false);
      abortRef.current = null;
    }
  };

  const handleDownloadMp4 = () => {
    if (!result) return;
    const a = document.createElement('a');
    a.href = result.url;
    a.download = result.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleNativeShare = async () => {
    if (!result) return;
    const file = new File([result.blob], result.fileName, {
      type: result.mimeType,
    });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          title: project.name,
          text: 'تم المونتاج والتصدير عبر تطبيق لقطة برو – Laqta Pro',
          files: [file],
        });
        return;
      } catch {
        // User canceled share sheet -> ignore
      }
    } else {
      handleDownloadMp4();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#111521] border border-slate-700/90 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-5 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white">
                تصدير ملف فيديو حقيقي (MP4)
              </h2>
              <p className="text-[11px] text-slate-400">
                تُدمج كافة الفلاتر والانتقالات والنصوص والصوت داخل ملف الفيديو
              </p>
            </div>
          </div>

          {!isExporting && (
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Settings Selector (shown before export or when re-exporting) */}
        {!isExporting && !result && (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 block">
                دقة الفيديو النهائية
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {(
                  [
                    {
                      id: '720p',
                      title: '720p HD (موصى به)',
                      desc: 'سريع ومثالي لهاتف Samsung A04 والواتساب',
                    },
                    {
                      id: '1080p',
                      title: '1080p Full HD',
                      desc: 'أعلى وضوح ليوتيوب والريلز الاحترافي',
                    },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    data-testid={`res-${opt.id}`}
                    onClick={() =>
                      setSettings((s) => ({ ...s, resolution: opt.id }))
                    }
                    className={`p-3 rounded-2xl border text-right transition cursor-pointer ${
                      settings.resolution === opt.id
                        ? 'border-cyan-400 bg-cyan-500/15'
                        : 'border-slate-800 bg-[#0B0E16] hover:border-slate-600'
                    }`}
                  >
                    <div className="text-xs font-extrabold text-white">
                      {opt.title}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {opt.desc}
                    </div>
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-cyan-300 font-mono">
                الأبعاد الناتجة: {dims.width} × {dims.height} بكسل ({project.aspectRatio})
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">
                  معدل الإطارات (FPS)
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  {([24, 30] as const).map((fps) => (
                    <button
                      key={fps}
                      type="button"
                      onClick={() => setSettings((s) => ({ ...s, fps }))}
                      className={`py-2 rounded-xl text-xs font-bold cursor-pointer ${
                        settings.fps === fps
                          ? 'bg-indigo-500 text-white'
                          : 'bg-[#0B0E16] text-slate-300 border border-slate-800'
                      }`}
                    >
                      {fps} FPS
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">
                  معدل البت والجودة
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  {(
                    [
                      { id: 'standard', label: 'متوازن' },
                      { id: 'high', label: 'عالي النقاء' },
                    ] as const
                  ).map((q) => (
                    <button
                      key={q.id}
                      type="button"
                      onClick={() => setSettings((s) => ({ ...s, quality: q.id }))}
                      className={`py-2 rounded-xl text-xs font-bold cursor-pointer ${
                        settings.quality === q.id
                          ? 'bg-indigo-500 text-white'
                          : 'bg-[#0B0E16] text-slate-300 border border-slate-800'
                      }`}
                    >
                      {q.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {errorMsg && (
              <div className="rounded-2xl bg-rose-950/60 border border-rose-500/40 p-3.5 flex items-start gap-2.5 text-xs text-rose-200">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">تنبيه أثناء التصدير:</p>
                  <p className="mt-0.5 leading-relaxed">{errorMsg}</p>
                </div>
              </div>
            )}

            <button
              type="button"
              data-testid="start-mp4-export-btn"
              onClick={handleStartExport}
              className="w-full py-4 rounded-2xl bg-gradient-to-l from-cyan-400 via-sky-500 to-indigo-500 text-slate-950 font-black text-sm shadow-xl shadow-cyan-500/20 hover:brightness-110 transition cursor-pointer"
            >
              بدء تصدير ملف الفيديو (.MP4) الآن
            </button>
          </div>
        )}

        {/* Live Progress View */}
        {isExporting && progress && (
          <div className="space-y-4 py-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-cyan-300">{progress.message}</span>
              <span className="font-mono font-black text-white text-sm">
                {progress.percent}%
              </span>
            </div>

            <div className="w-full h-3.5 rounded-full bg-slate-900 border border-slate-800 overflow-hidden p-0.5">
              <div
                style={{ width: `${progress.percent}%` }}
                className="h-full rounded-full bg-gradient-to-l from-cyan-400 via-sky-500 to-indigo-500 transition-all duration-150"
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>
                الإطارات: {progress.currentFrame} / {progress.totalFrames}
              </span>
              {progress.engineLabel && (
                <span className="text-emerald-400">{progress.engineLabel}</span>
              )}
            </div>

            <button
              type="button"
              onClick={() => abortRef.current?.abort()}
              className="w-full py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-bold cursor-pointer"
            >
              إلغاء التصدير
            </button>
          </div>
        )}

        {/* Export Complete Result + Real Playable MP4 Video Preview */}
        {result && !isExporting && (
          <div className="space-y-4" data-testid="export-success-panel">
            <div className="rounded-2xl bg-emerald-950/45 border border-emerald-500/40 p-3 flex items-center gap-2.5 text-xs text-emerald-200">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="font-extrabold">
                  تم إنتاج ملف الفيديو النهائي بنجاح ({result.engineUsed})!
                </p>
                <p className="text-[11px] text-emerald-300/90 mt-0.5">
                  الأبعاد: {result.width}×{result.height} • المدة:{' '}
                  {result.duration.toFixed(1)} ثانية • الحجم:{' '}
                  {(result.sizeBytes / 1024).toFixed(0)} KB
                </p>
                {result.downgradedResolutionNote && (
                  <p className="text-[11px] text-amber-300 mt-1">
                    {result.downgradedResolutionNote}
                  </p>
                )}
              </div>
            </div>

            {/* Real playable HTML5 <video> element loaded directly from exported MP4 blob */}
            <div className="rounded-2xl overflow-hidden bg-black border border-slate-800 flex items-center justify-center max-h-72">
              <video
                src={result.url}
                controls
                playsInline
                data-testid="exported-video-player"
                className="max-h-72 w-auto mx-auto"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                data-testid="download-mp4-btn"
                onClick={handleDownloadMp4}
                className="py-3.5 px-4 rounded-2xl bg-gradient-to-l from-cyan-400 to-sky-500 text-slate-950 font-black text-xs inline-flex items-center justify-center gap-2 shadow-lg hover:brightness-110 transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>تنزيل ملف MP4 إلى الجهاز</span>
              </button>

              <button
                type="button"
                onClick={handleNativeShare}
                className="py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs inline-flex items-center justify-center gap-2 border border-slate-700 transition cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-cyan-400" />
                <span>مشاركة الفيديو</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
