import React from 'react';
import {
  Aperture,
  Ban,
  Binary,
  Camera,
  Clapperboard,
  Cloud,
  Contrast,
  Disc3,
  Droplets,
  Eye,
  Feather,
  Film,
  Flame,
  Gem,
  Heart,
  Image as ImageIcon,
  Leaf,
  Moon,
  Mountain,
  Palmtree,
  Radio,
  Snowflake,
  Sparkle,
  Sparkles,
  Sun,
  SunMedium,
  Sunset,
  Trees,
  Waves,
  Wind,
  Zap,
} from 'lucide-react';
import { FilterIconKey } from '../constants/presets';

/**
 * Authentic CapCut 3-Overlapping-Rings Filter Icon for main toolbar & badges
 */
export const CapCutFilterToolbarIcon: React.FC<{ className?: string }> = ({
  className = 'w-4 h-4',
}) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.1"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <circle cx="12" cy="8.5" r="5" />
    <circle cx="8.5" cy="14.5" r="5" />
    <circle cx="15.5" cy="14.5" r="5" />
  </svg>
);

export const FilterPresetIcon: React.FC<{
  iconKey: FilterIconKey;
  className?: string;
}> = ({ iconKey, className = 'w-4 h-4' }) => {
  switch (iconKey) {
    case 'off':
      return <Ban className={className} />;
    case 'cinema':
      return <Clapperboard className={className} />;
    case 'aperture':
      return <Aperture className={className} />;
    case 'moon':
      return <Moon className={className} />;
    case 'sun':
      return <SunMedium className={className} />;
    case 'zap':
      return <Zap className={className} />;
    case 'sparkles':
      return <Sparkles className={className} />;
    case 'sparkle':
      return <Sparkle className={className} />;
    case 'heart':
      return <Heart className={className} />;
    case 'cloud':
      return <Cloud className={className} />;
    case 'sunset':
      return <Sunset className={className} />;
    case 'golden':
      return <Sun className={className} />;
    case 'flame':
      return <Flame className={className} />;
    case 'trees':
      return <Trees className={className} />;
    case 'snow':
      return <Snowflake className={className} />;
    case 'wind':
      return <Wind className={className} />;
    case 'camera':
      return <Camera className={className} />;
    case 'film':
      return <Film className={className} />;
    case 'contrast':
      return <Contrast className={className} />;
    case 'binary':
      return <Binary className={className} />;
    case 'mountain':
      return <Mountain className={className} />;
    case 'eye':
      return <Eye className={className} />;
    case 'disc':
      return <Disc3 className={className} />;
    case 'waves':
      return <Waves className={className} />;
    case 'radio':
      return <Radio className={className} />;
    case 'gem':
      return <Gem className={className} />;
    case 'feather':
      return <Feather className={className} />;
    case 'droplets':
      return <Droplets className={className} />;
    case 'leaf':
      return <Leaf className={className} />;
    case 'palm':
      return <Palmtree className={className} />;
    case 'image':
      return <ImageIcon className={className} />;
    default:
      return <Sparkles className={className} />;
  }
};
