import React, { useRef, useState } from 'react';
import {
  BookOpen,
  Captions,
  Clock,
  Film,
  FolderOpen,
  Layers,
  LayoutTemplate,
  Play,
  Plus,
  Scissors,
  Smartphone,
  Sparkles,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  CAPCUT_READY_TEMPLATES,
  CapCutTemplatePreset,
  TEMPLATE_CATEGORIES,
  TemplateCategory,
} from '../constants/presets';
import {
  QuranGenerationRequest,
  QuranStudioPanel,
} from './QuranStudioPanel';
import { ActiveToolTab, ProjectSummary } from '../types/editor';

export type { CapCutTemplatePreset };

interface HomeScreenProps {
  savedProjects: ProjectSummary[];
  isBusy: boolean;
  busyMessage: string;
  onCreateWithFiles: (
    files: FileList,
    initialTab?: ActiveToolTab,
    templateId?: CapCutTemplatePreset
  ) => void;
  onCreateEmpty: (initialTab?: ActiveToolTab) => void;
  onCreateDemoProject: (
    template?: CapCutTemplatePreset,
    overrideAspect?: '9:16' | '16:9'
  ) => void;
  onCreateQuranProject: (req: QuranGenerationRequest) => void;
  onOpenProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => void;
}

function formatDurationBadge(seconds: number): string {
  const s = Math.max(0, Math.round(seconds));
  const mins = Math.floor(s / 60);
  const secs = s % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function formatRelativeDate(timestamp: number): string {
  const diffMin = Math.floor((Date.now() - timestamp) / 60000);
  if (diffMin < 1) return 'الآن';
  if (diffMin < 60) return `منذ ${diffMin} د`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `منذ ${diffHr} س`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 30) return `منذ ${diffDays} يوم`;
  return new Date(timestamp).toLocaleDateString('ar-EG');
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  savedProjects,
  isBusy,
  busyMessage,
  onCreateWithFiles,
  onCreateEmpty,
  onCreateDemoProject,
  onCreateQuranProject,
  onOpenProject,
  onDeleteProject,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const templateFileInputRef = useRef<HTMLInputElement>(null);
  const pendingTabRef = useRef<ActiveToolTab>('edit');
  const pendingTemplateRef = useRef<CapCutTemplatePreset>('viral-reel');

  const [homeSection, setHomeSection] = useState<
    'edits' | 'templates' | 'quran-maker'
  >('edits');
  const [templateCat, setTemplateCat] = useState<TemplateCategory>('all');
  const [showApkGuide, setShowApkGuide] = useState(false);

  const triggerFilePickerForTab = (tab: ActiveToolTab = 'edit') => {
    pendingTabRef.current = tab;
    fileInputRef.current?.click();
  };

  const triggerUserMediaForTemplate = (tplId: CapCutTemplatePreset) => {
    pendingTemplateRef.current = tplId;
    templateFileInputRef.current?.click();
  };

  const filteredTemplates = CAPCUT_READY_TEMPLATES.filter(
    (t) => templateCat === 'all' || t.category === templateCat
  );

  return (
    <div className="min-h-screen bg-[#0B0C0F] text-white flex flex-col select-none">
      {/* Hidden Standard Multi-Media File Picker */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="video/*,image/*,audio/*"
        data-testid="home-media-input"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onCreateWithFiles(e.target.files, pendingTabRef.current);
            e.target.value = '';
          }
        }}
      />

      {/* Hidden Template User-Media Picker (Applies selected template directly onto user's phone videos/photos!) */}
      <input
        ref={templateFileInputRef}
        type="file"
        multiple
        accept="video/*,image/*"
        data-testid="template-media-input"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onCreateWithFiles(e.target.files, 'edit', pendingTemplateRef.current);
            e.target.value = '';
          }
        }}
      />

      {/* CapCut Minimal Sleek Header */}
      <header className="sticky top-0 z-20 bg-[#0B0C0F]/95 backdrop-blur-md border-b border-zinc-800/80">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white text-black flex items-center justify-center shadow-md">
              <Scissors className="w-5 h-5 stroke-[2.6]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base sm:text-lg font-black tracking-tight text-white">
                  لقطة برو
                </span>
                <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-[#00E5DF] text-zinc-950">
                  PRO
                </span>
              </div>
              <p className="text-[10px] text-zinc-400">
                محرر فيديو متكامل بأسلوب CapCut • ترجمة تلقائية وقوالب مجانية بلا حدود
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowApkGuide(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#181A20] hover:bg-zinc-800 text-xs font-bold text-zinc-200 border border-zinc-800 transition cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5 text-[#00E5DF]" />
              <span>تطبيق APK</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main CapCut Home Body */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 pt-5 pb-24 space-y-6">
        {/* 1. Signature CapCut Glowing Cyan "+ مشروع جديد" Hero Card */}
        <section className="space-y-3.5">
          <button
            type="button"
            disabled={isBusy}
            onClick={() => triggerFilePickerForTab('edit')}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              if (!isBusy && e.dataTransfer.files?.length) {
                onCreateWithFiles(e.dataTransfer.files, 'edit');
              }
            }}
            className="w-full h-32 sm:h-36 rounded-2xl bg-gradient-to-l from-[#00E5DF] via-[#00D2E6] to-[#0891B2] hover:brightness-105 active:scale-[0.995] transition shadow-[0_10px_35px_rgba(0,229,223,0.22)] flex flex-col items-center justify-center gap-2 text-zinc-950 cursor-pointer disabled:opacity-50"
          >
            <div className="w-11 h-11 rounded-xl bg-zinc-950 text-[#00E5DF] flex items-center justify-center shadow-lg">
              <Plus className="w-6 h-6 stroke-[3]" />
            </div>
            <div className="text-center">
              <span className="text-lg sm:text-xl font-black block">
                مشروع جديد
              </span>
              <span className="text-[11px] font-bold text-zinc-900/80">
                اختر فيديو أو صوراً من هاتفك وابدأ المونتاج فوراً
              </span>
            </div>
          </button>

          {/* 2. Authentic CapCut + Holy Quran Quick Studio Row */}
          <div className="grid grid-cols-4 gap-2 sm:gap-3">
            <button
              type="button"
              disabled={isBusy}
              data-testid="quick-open-quran-maker-btn"
              onClick={() => setHomeSection('quran-maker')}
              className="flex flex-col items-center justify-center gap-1.5 py-3 px-1.5 rounded-2xl bg-gradient-to-b from-amber-500/20 to-[#16181E] hover:brightness-110 border border-amber-400/50 transition cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-[11px] sm:text-xs font-black text-amber-200 text-center">
                فيديو قرآني 🕌
              </span>
            </button>

            <button
              type="button"
              disabled={isBusy}
              onClick={() => setHomeSection('templates')}
              data-testid="quick-open-templates-btn"
              className="flex flex-col items-center justify-center gap-1.5 py-3 px-1.5 rounded-2xl bg-[#16181E] hover:bg-[#1E2028] border border-zinc-800/90 transition cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-purple-500/15 text-purple-300 flex items-center justify-center">
                <LayoutTemplate className="w-5 h-5" />
              </div>
              <span className="text-[11px] sm:text-xs font-bold text-zinc-200 text-center">
                80 قالب نقي
              </span>
            </button>

            <button
              type="button"
              disabled={isBusy}
              onClick={() => triggerFilePickerForTab('captions')}
              className="flex flex-col items-center justify-center gap-1.5 py-3 px-1.5 rounded-2xl bg-[#16181E] hover:bg-[#1E2028] border border-zinc-800/90 transition cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-[#00E5DF]/15 text-[#00E5DF] flex items-center justify-center">
                <Captions className="w-5 h-5" />
              </div>
              <span className="text-[11px] sm:text-xs font-bold text-zinc-200 text-center">
                ترجمة تلقائية
              </span>
            </button>

            <button
              type="button"
              disabled={isBusy}
              data-testid="create-demo-project-btn"
              onClick={() => onCreateDemoProject('viral-reel')}
              className="flex flex-col items-center justify-center gap-1.5 py-3 px-1.5 rounded-2xl bg-[#16181E] hover:bg-[#1E2028] border border-[#00E5DF]/30 transition cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-[#00E5DF]/15 text-[#00E5DF] flex items-center justify-center">
                <Sparkles className="w-5 h-5" />
              </div>
              <span className="text-[11px] sm:text-xs font-bold text-[#00E5DF] text-center">
                تجربة فورية
              </span>
            </button>
          </div>
        </section>

        {/* Loading Progress Banner */}
        {isBusy && (
          <div className="rounded-2xl bg-[#142024] border border-[#00E5DF]/40 px-4 py-3.5 flex items-center gap-3 text-[#00E5DF]">
            <div className="w-5 h-5 rounded-full border-2 border-[#00E5DF] border-t-transparent animate-spin shrink-0" />
            <span className="text-xs sm:text-sm font-bold text-white">
              {busyMessage}
            </span>
          </div>
        )}

        {/* Section Switcher: مشاريعي | صانع الفيديو القرآني 🕌 | القوالب الجاهزة (30) */}
        <div className="flex items-center justify-between border-b border-zinc-800/90 pb-2 gap-2 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-4 shrink-0">
            <button
              type="button"
              onClick={() => setHomeSection('edits')}
              className={`pb-2 text-xs sm:text-sm font-black relative cursor-pointer transition ${
                homeSection === 'edits'
                  ? 'text-white after:content-[""] after:absolute after:bottom-[-9px] after:inset-x-0 after:h-[3px] after:rounded-full after:bg-[#00E5DF]'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              مشاريعي ({savedProjects.length})
            </button>

            <button
              type="button"
              data-testid="home-quran-tab"
              onClick={() => setHomeSection('quran-maker')}
              className={`pb-2 text-xs sm:text-sm font-black relative cursor-pointer transition ${
                homeSection === 'quran-maker'
                  ? 'text-amber-300 after:content-[""] after:absolute after:bottom-[-9px] after:inset-x-0 after:h-[3px] after:rounded-full after:bg-amber-400'
                  : 'text-amber-200/75 hover:text-amber-200'
              }`}
            >
              صانع الفيديو القرآني 🕌
            </button>

            <button
              type="button"
              data-testid="home-templates-tab"
              onClick={() => setHomeSection('templates')}
              className={`pb-2 text-xs sm:text-sm font-black relative cursor-pointer transition ${
                homeSection === 'templates'
                  ? 'text-white after:content-[""] after:absolute after:bottom-[-9px] after:inset-x-0 after:h-[3px] after:rounded-full after:bg-[#00E5DF]'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              القوالب الجاهزة ({CAPCUT_READY_TEMPLATES.length}) ✨
            </button>
          </div>

          <button
            type="button"
            onClick={() => onCreateEmpty('media')}
            className="text-xs font-bold text-zinc-400 hover:text-[#00E5DF] cursor-pointer"
          >
            + استوديو فارغ
          </button>
        </div>

        {/* Dedicated Full Holy Quran Video Studio Section on Home */}
        {homeSection === 'quran-maker' ? (
          <div className="max-w-3xl mx-auto">
            <QuranStudioPanel
              hasExistingClips={false}
              isBusy={isBusy}
              onGenerateQuranVideo={onCreateQuranProject}
            />
          </div>
        ) : homeSection === 'edits' ? (
          <div className="space-y-6">
            {savedProjects.length === 0 ? (
              <div className="rounded-2xl bg-[#14161B] border border-zinc-800/80 p-6 text-center space-y-2.5">
                <div className="w-11 h-11 rounded-2xl bg-zinc-900 border border-zinc-800 mx-auto flex items-center justify-center text-zinc-500">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <p className="text-zinc-200 font-bold text-sm">
                  تظهر مشاريعك المحفوظة هنا تلقائياً
                </p>
                <p className="text-xs text-zinc-500">
                  اختر فيديو من هاتفك بالأعلى، أو اختر أياً من القوالب الـ 16 الجاهزة بالأسفل!
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {savedProjects.map((proj) => (
                  <div
                    key={proj.id}
                    onClick={() => onOpenProject(proj.id)}
                    className="group rounded-2xl bg-[#15171D] hover:bg-[#1B1E26] border border-zinc-800/90 hover:border-[#00E5DF]/50 p-3 flex items-center gap-3.5 transition cursor-pointer"
                  >
                    <div className="w-20 h-20 rounded-xl bg-zinc-900 overflow-hidden relative shrink-0 border border-zinc-800">
                      {proj.thumbnailDataUrl ? (
                        <img
                          src={proj.thumbnailDataUrl}
                          alt={proj.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Film className="w-6 h-6 text-zinc-600" />
                        </div>
                      )}
                      <span className="absolute bottom-1 right-1 text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-black/80 text-white">
                        {formatDurationBadge(proj.duration)}
                      </span>
                    </div>

                    <div className="flex-1 min-w-0 space-y-1">
                      <h4 className="font-extrabold text-sm text-white truncate">
                        {proj.name}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-zinc-400">
                        <span className="inline-flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatRelativeDate(proj.updatedAt)}
                        </span>
                        <span>•</span>
                        <span>{proj.aspectRatio}</span>
                        <span>•</span>
                        <span>{proj.clipCount} مقاطع</span>
                      </div>
                      <span className="inline-block text-[11px] font-bold text-[#00E5DF]">
                        فتح المشروع ←
                      </span>
                    </div>

                    <button
                      type="button"
                      title="حذف المشروع"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteProject(proj.id);
                      }}
                      className="p-2 rounded-xl text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 transition cursor-pointer shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Dedicated Quranic Nature Videos Showcase: BOTH Reels (9:16) & Long YouTube (16:9)! */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-amber-300" />
                  <h3 className="text-sm sm:text-base font-black text-amber-100">
                    قوالب القرآن الكريم بفيديوهات الطبيعة الحقيقية (للريلز 📱 والطويل 📺)
                  </h3>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setTemplateCat('quran');
                      setHomeSection('templates');
                    }}
                    className="text-xs font-extrabold text-amber-300 hover:underline cursor-pointer"
                  >
                    قرآن ريلز دقيقة+ (15)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTemplateCat('quran-long');
                      setHomeSection('templates');
                    }}
                    className="text-xs font-extrabold text-[#00E5DF] hover:underline cursor-pointer"
                  >
                    قرآن طويل 16:9 (15) ←
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {[
                  ...CAPCUT_READY_TEMPLATES.filter((t) => t.category === 'quran').slice(0, 4),
                  ...CAPCUT_READY_TEMPLATES.filter((t) => t.category === 'quran-long').slice(0, 4),
                ].map((tpl) => (
                  <div
                    key={tpl.id}
                    className={`rounded-2xl bg-gradient-to-br ${tpl.gradient} border border-amber-400/30 hover:border-amber-300 p-3.5 flex flex-col justify-between gap-3 transition`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-black/65 text-amber-300 border border-amber-400/30 truncate">
                          {tpl.badge}
                        </span>
                        <span className="text-[10px] font-mono text-zinc-200 bg-black/60 px-1.5 py-0.5 rounded shrink-0">
                          {tpl.aspect}
                        </span>
                      </div>
                      <h4 className="text-sm font-black text-white leading-snug">
                        {tpl.title}
                      </h4>
                      <p className="text-[11px] text-zinc-300 line-clamp-2 leading-relaxed">
                        {tpl.subtitle}
                      </p>
                    </div>

                    {/* Launch directly with real Nature video + Recitation as EITHER Reels 9:16 OR Long 16:9! */}
                    <div className="grid grid-cols-3 gap-1">
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => onCreateDemoProject(tpl.id, '9:16')}
                        className="py-2 px-1 rounded-xl bg-amber-400 hover:brightness-110 text-zinc-950 font-black text-[10px] inline-flex items-center justify-center gap-0.5 cursor-pointer disabled:opacity-50"
                      >
                        <span>📱 ريلز</span>
                      </button>

                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => onCreateDemoProject(tpl.id, '16:9')}
                        className="py-2 px-1 rounded-xl bg-[#00E5DF] hover:brightness-110 text-zinc-950 font-black text-[10px] inline-flex items-center justify-center gap-0.5 cursor-pointer disabled:opacity-50"
                      >
                        <span>📺 طويل</span>
                      </button>

                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => triggerUserMediaForTemplate(tpl.id)}
                        className="py-2 px-1 rounded-xl bg-black/65 hover:bg-black text-white border border-white/15 font-bold text-[10px] inline-flex items-center justify-center gap-0.5 cursor-pointer disabled:opacity-50"
                      >
                        <Upload className="w-2.5 h-2.5 text-amber-300" />
                        <span>ملفك</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* General Pro CapCut Templates Strip */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#00E5DF]" />
                  <h3 className="text-sm sm:text-base font-black text-white">
                    قوالب المونتاج الاحترافية للريلز واليوتيوب ({CAPCUT_READY_TEMPLATES.length} قالباً)
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setTemplateCat('all');
                    setHomeSection('templates');
                  }}
                  className="text-xs font-extrabold text-[#00E5DF] hover:underline cursor-pointer"
                >
                  عرض كل الـ {CAPCUT_READY_TEMPLATES.length} قالباً ←
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {CAPCUT_READY_TEMPLATES.filter((t) => !t.quranPreset)
                  .slice(0, 8)
                  .map((tpl) => (
                    <div
                      key={tpl.id}
                      className={`rounded-2xl bg-gradient-to-br ${tpl.gradient} border border-zinc-800 hover:border-[#00E5DF]/60 p-3.5 flex flex-col justify-between gap-3 transition`}
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-black/65 text-[#00E5DF] border border-[#00E5DF]/30 truncate">
                            {tpl.badge}
                          </span>
                          <span className="text-[10px] font-mono text-zinc-300 bg-black/50 px-1.5 py-0.5 rounded shrink-0">
                            {tpl.aspect}
                          </span>
                        </div>
                        <h4 className="text-sm font-black text-white leading-snug">
                          {tpl.title}
                        </h4>
                        <p className="text-[11px] text-zinc-300 line-clamp-2 leading-relaxed">
                          {tpl.subtitle}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => triggerUserMediaForTemplate(tpl.id)}
                          className="py-2 px-2 rounded-xl bg-[#00E5DF] hover:brightness-110 text-zinc-950 font-black text-[11px] inline-flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
                        >
                          <Upload className="w-3 h-3" />
                          <span>بوسائطك</span>
                        </button>

                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => onCreateDemoProject(tpl.id)}
                          className="py-2 px-2 rounded-xl bg-black/60 hover:bg-black/80 text-white border border-white/15 font-bold text-[11px] inline-flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
                        >
                          <Play className="w-3 h-3 text-[#00E5DF] fill-current" />
                          <span>تجربة فورية</span>
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        ) : (
          /* Full 16 CapCut Ready Templates Gallery with Category Filters */
          <div className="space-y-4">
            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {TEMPLATE_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setTemplateCat(cat.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold shrink-0 transition cursor-pointer ${
                    templateCat === cat.id
                      ? 'bg-[#00E5DF] text-zinc-950 font-black'
                      : 'bg-[#16181F] text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {filteredTemplates.map((tpl) => (
                <div
                  key={tpl.id}
                  data-testid={`home-template-card-${tpl.id}`}
                  className={`rounded-2xl bg-gradient-to-br ${tpl.gradient} border border-zinc-800 hover:border-[#00E5DF]/60 p-4 flex flex-col justify-between gap-4 transition`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-black/65 text-[#00E5DF] border border-[#00E5DF]/30">
                        {tpl.badge}
                      </span>
                      <span className="text-[10px] font-mono text-zinc-200 bg-black/55 px-2 py-0.5 rounded">
                        {tpl.aspect} • {tpl.durationHint}
                      </span>
                    </div>
                    <h4 className="text-base font-black text-white">
                      {tpl.title}
                    </h4>
                    <p className="text-xs text-zinc-300 leading-relaxed">
                      {tpl.subtitle}
                    </p>
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {tpl.tags.map((tg) => (
                        <span
                          key={tg}
                          className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-black/50 text-zinc-200"
                        >
                          {tg}
                        </span>
                      ))}
                    </div>
                  </div>

                  {tpl.quranPreset ? (
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => onCreateDemoProject(tpl.id, '9:16')}
                        className="py-2.5 px-2 rounded-xl bg-amber-400 hover:brightness-110 text-zinc-950 font-black text-[11px] inline-flex items-center justify-center gap-1 transition cursor-pointer disabled:opacity-50"
                      >
                        <span>📱 ريلز 9:16</span>
                      </button>

                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => onCreateDemoProject(tpl.id, '16:9')}
                        className="py-2.5 px-2 rounded-xl bg-[#00E5DF] hover:brightness-110 text-zinc-950 font-black text-[11px] inline-flex items-center justify-center gap-1 transition cursor-pointer disabled:opacity-50"
                      >
                        <span>📺 طويل 16:9</span>
                      </button>

                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => triggerUserMediaForTemplate(tpl.id)}
                        className="py-2.5 px-2 rounded-xl bg-black/65 hover:bg-black text-white border border-white/20 font-bold text-[11px] inline-flex items-center justify-center gap-1 transition cursor-pointer disabled:opacity-50"
                      >
                        <Upload className="w-3 h-3 text-amber-300" />
                        <span>بوسائطك</span>
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => triggerUserMediaForTemplate(tpl.id)}
                        className="py-2.5 px-3 rounded-xl bg-[#00E5DF] hover:brightness-110 text-zinc-950 font-black text-xs inline-flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>استخدم بوسائطك</span>
                      </button>

                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => onCreateDemoProject(tpl.id)}
                        className="py-2.5 px-3 rounded-xl bg-black/65 hover:bg-black text-white border border-white/20 font-bold text-xs inline-flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50"
                      >
                        <Layers className="w-3.5 h-3.5 text-[#00E5DF]" />
                        <span>تجربة جاهزة</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Bottom CapCut Navigation Bar */}
      <nav className="fixed bottom-0 inset-x-0 z-20 h-14 bg-[#121318]/95 backdrop-blur-md border-t border-zinc-800/90 flex items-center justify-around max-w-5xl mx-auto">
        <button
          type="button"
          onClick={() => setHomeSection('edits')}
          className={`flex flex-col items-center gap-0.5 text-[11px] font-bold cursor-pointer ${
            homeSection === 'edits' ? 'text-[#00E5DF]' : 'text-zinc-500'
          }`}
        >
          <Scissors className="w-4 h-4" />
          <span>التحرير</span>
        </button>

        <button
          type="button"
          onClick={() => setHomeSection('templates')}
          className={`flex flex-col items-center gap-0.5 text-[11px] font-bold cursor-pointer ${
            homeSection === 'templates' ? 'text-[#00E5DF]' : 'text-zinc-500'
          }`}
        >
          <LayoutTemplate className="w-4 h-4" />
          <span>القوالب ({CAPCUT_READY_TEMPLATES.length})</span>
        </button>
      </nav>

      {/* Android APK Guide Modal */}
      {showApkGuide && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#16181F] border border-zinc-700 rounded-3xl max-w-xl w-full p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-[#00E5DF]" />
                <h3 className="text-base sm:text-lg font-extrabold text-white">
                  تثبيت كـ Android APK على هاتف Samsung A04
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowApkGuide(false)}
                className="p-1.5 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
              المشروع مجهز بالكامل بملف Capacitor{' '}
              <code className="text-[#00E5DF] bg-zinc-900 px-1.5 py-0.5 rounded">
                capacitor.config.json
              </code>{' '}
              وسير عمل GitHub Actions تلقائي لإنتاج ملف APK جاهز للتثبيت مع تفعيل{' '}
              <code className="text-emerald-300">largeHeap</code> و{' '}
              <code className="text-emerald-300">hardwareAccelerated</code>.
            </p>

            <pre
              dir="ltr"
              className="bg-black p-3 rounded-xl text-[11px] text-[#00E5DF] overflow-x-auto border border-zinc-800"
            >{`npm install && npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android && npx cap sync android
cd android && ./gradlew assembleDebug`}</pre>

            <button
              type="button"
              onClick={() => setShowApkGuide(false)}
              className="w-full py-3 rounded-xl bg-[#00E5DF] text-zinc-950 font-black text-sm hover:brightness-110 transition cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
