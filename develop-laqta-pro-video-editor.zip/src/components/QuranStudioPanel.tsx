import React, { useRef, useState } from 'react';
import {
  BookOpen,
  Clock,
  Mic,
  MonitorPlay,
  Smartphone,
  Sparkles,
  Trees,
  Upload,
} from 'lucide-react';
import {
  NATURE_PACK_OPTIONS,
  NaturePackId,
} from '../services/natureVideoService';
import {
  OFFLINE_QURAN_GEMS,
  QURAN_RECITERS,
  QURAN_VISUAL_THEMES,
  QuranVisualThemeId,
  SURAHS_LIST,
} from '../services/quranService';
import { AspectRatio } from '../types/editor';

export interface QuranGenerationRequest {
  surahNumber: number;
  startAyah: number;
  endAyah: number;
  reciterId: string;
  visualThemeId: QuranVisualThemeId;
  targetAspectRatio: AspectRatio;
  naturePackId: NaturePackId;
  minDurationSec: number;
  includeEnglish: boolean;
  highlightWords: boolean;
  customBgFiles?: FileList | null;
  keepExistingClips: boolean;
}

interface QuranStudioPanelProps {
  hasExistingClips: boolean;
  isBusy: boolean;
  onGenerateQuranVideo: (req: QuranGenerationRequest) => void;
}

const LONG_MINUTE_PLUS_PASSAGES: Array<{
  id: string;
  label: string;
  surah: number;
  start: number;
  end: number;
}> = [
  { id: 'long-mulk', label: '⏱️ سورة الملك (1-14 • 1:35 د)', surah: 67, start: 1, end: 14 },
  { id: 'long-rahman', label: '⏱️ سورة الرحمن (1-25 • 1:30 د)', surah: 55, start: 1, end: 25 },
  { id: 'long-kahf', label: '⏱️ سورة الكهف (1-11 • 1:25 د)', surah: 18, start: 1, end: 11 },
  { id: 'long-yasin', label: '⏱️ سورة يس (1-16 • 1:25 د)', surah: 36, start: 1, end: 16 },
  { id: 'long-ala', label: '⏱️ سورة الأعلى كاملة (19 آية • 1:05 د)', surah: 87, start: 1, end: 19 },
  { id: 'long-shams', label: '⏱️ سورة الشمس كاملة (15 آية • 1:08 د)', surah: 91, start: 1, end: 15 },
  { id: 'long-layl', label: '⏱️ سورة الليل كاملة (21 آية • 1:18 د)', surah: 92, start: 1, end: 21 },
  { id: 'long-furqan', label: '⏱️ عباد الرحمن (63-77 • دقيقتان)', surah: 25, start: 1, end: 15 },
];
// Fix exact Furqan verse range 63-77
LONG_MINUTE_PLUS_PASSAGES[7] = {
  id: 'long-furqan',
  label: '⏱️ عباد الرحمن (الفرقان 63-77 • 2:00 د)',
  surah: 25,
  start: 63,
  end: 77,
};

export const QuranStudioPanel: React.FC<QuranStudioPanelProps> = ({
  hasExistingClips,
  isBusy,
  onGenerateQuranVideo,
}) => {
  const bgFileInputRef = useRef<HTMLInputElement>(null);

  const [targetAspectRatio, setTargetAspectRatio] =
    useState<AspectRatio>('9:16');
  const [minDurationSec, setMinDurationSec] = useState<number>(64); // Default 1+ Minute ("دقيقة وأكثر"!)
  const [naturePackId, setNaturePackId] =
    useState<NaturePackId>('mixed-nature');
  const [surahNumber, setSurahNumber] = useState<number>(91); // Surah Ash-Shams full 15 verses (~1:08 naturally!)
  const [startAyah, setStartAyah] = useState<number>(1);
  const [endAyah, setEndAyah] = useState<number>(15);
  const [reciterId, setReciterId] = useState<string>('alafasy');
  const [visualThemeId, setVisualThemeId] =
    useState<QuranVisualThemeId>('waterfall-nature-reels');
  const [includeEnglish, setIncludeEnglish] = useState<boolean>(false);
  const [highlightWords, setHighlightWords] = useState<boolean>(false);
  const [keepExistingClips, setKeepExistingClips] =
    useState<boolean>(hasExistingClips);

  const currentSurah =
    SURAHS_LIST.find((s) => s.number === surahNumber) || SURAHS_LIST[0];

  const handleSelectSurah = (num: number) => {
    const info = SURAHS_LIST.find((s) => s.number === num) || SURAHS_LIST[0];
    setSurahNumber(num);
    setStartAyah(1);
    setEndAyah(Math.min(info.ayahCount, 16));
  };

  return (
    <div className="space-y-4" data-testid="quran-studio-panel">
      {/* Hidden Custom Background Video/Image Picker */}
      <input
        ref={bgFileInputRef}
        type="file"
        multiple
        accept="video/*,image/*"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            onGenerateQuranVideo({
              surahNumber,
              startAyah,
              endAyah,
              reciterId,
              visualThemeId,
              targetAspectRatio,
              naturePackId,
              minDurationSec,
              includeEnglish,
              highlightWords,
              customBgFiles: e.target.files,
              keepExistingClips: false,
            });
            e.target.value = '';
          }
        }}
      />

      {/* Pure & Accurate Banner */}
      <div className="rounded-2xl bg-gradient-to-br from-emerald-950/85 via-[#131A26] to-amber-950/45 border border-amber-400/45 p-3.5 space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-amber-300 shrink-0" />
            <h3 className="text-xs sm:text-sm font-black text-amber-100">
              قوالب وصانع القرآن النقي (دقيقة وأكثر • بدون مؤثرات مسبقة) 🏞️🕌
            </h3>
          </div>
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-200 border border-emerald-400/35 shrink-0">
            نقي 100% خام
          </span>
        </div>
        <p className="text-[11px] text-zinc-300 leading-relaxed">
          يُنشئ القالب{' '}
          <strong className="text-amber-300">
            فقط بالآيات المكتوبة بمزامنة دقيقة بالمللي ثانية + صوت التلاوة الصافي + فيديوهات الطبيعة الحقيقية
          </strong>{' '}
          بمدة <strong className="text-emerald-300">دقيقة فأكثر (01:00+)</strong>{' '}
          وبدون أي فلاتر أو انتقالات أو مؤثرات مسبقة لتضيفها أنت بنفسك بحرية!
        </p>
      </div>

      {/* STEP 1: Format (Reels vs Long 16:9) + Minimum Duration Selector (1:00+ / 2:00+ / Single) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <div className="space-y-1.5">
          <span className="text-[11px] font-extrabold text-white block">
            1. مقاس الفيديو:
          </span>
          <div className="grid grid-cols-3 gap-1.5">
            <button
              type="button"
              data-testid="quran-format-reels"
              onClick={() => setTargetAspectRatio('9:16')}
              className={`py-2 px-1.5 rounded-xl border text-center transition cursor-pointer flex flex-col items-center gap-0.5 ${
                targetAspectRatio === '9:16'
                  ? 'bg-amber-400/20 border-amber-300 text-amber-200 font-black'
                  : 'bg-[#1B1D24] border-zinc-800 text-zinc-300'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-300" />
              <span className="text-[11px]">ريلز 9:16</span>
            </button>

            <button
              type="button"
              data-testid="quran-format-long"
              onClick={() => setTargetAspectRatio('16:9')}
              className={`py-2 px-1.5 rounded-xl border text-center transition cursor-pointer flex flex-col items-center gap-0.5 ${
                targetAspectRatio === '16:9'
                  ? 'bg-[#00E5DF]/20 border-[#00E5DF] text-[#00E5DF] font-black'
                  : 'bg-[#1B1D24] border-zinc-800 text-zinc-300'
              }`}
            >
              <MonitorPlay className="w-3.5 h-3.5 text-[#00E5DF]" />
              <span className="text-[11px]">طويل 16:9</span>
            </button>

            <button
              type="button"
              data-testid="quran-format-square"
              onClick={() => setTargetAspectRatio('1:1')}
              className={`py-2 px-1.5 rounded-xl border text-center transition cursor-pointer flex flex-col items-center gap-0.5 ${
                targetAspectRatio === '1:1'
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200 font-black'
                  : 'bg-[#1B1D24] border-zinc-800 text-zinc-300'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span className="text-[11px]">مربع 1:1</span>
            </button>
          </div>
        </div>

        <div className="space-y-1.5">
          <span className="text-[11px] font-extrabold text-emerald-300 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            <span>2. مدة الفيديو المستهدفة:</span>
          </span>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { sec: 64, label: 'دقيقة+ ⏱️', sub: '01:05+' },
              { sec: 122, label: 'دقيقتان+ ⏱️', sub: '02:02+' },
              { sec: 0, label: 'مفردة', sub: 'حسب الآيات' },
            ].map((dOpt) => (
              <button
                key={dOpt.sec}
                type="button"
                data-testid={`quran-dur-${dOpt.sec}`}
                onClick={() => setMinDurationSec(dOpt.sec)}
                className={`py-1.5 px-1 rounded-xl border text-center transition cursor-pointer ${
                  minDurationSec === dOpt.sec
                    ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200 font-black'
                    : 'bg-[#1B1D24] border-zinc-800 text-zinc-300'
                }`}
              >
                <div className="text-[11px]">{dOpt.label}</div>
                <div className="text-[9px] text-zinc-400 font-mono">
                  {dOpt.sub}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* STEP 2: 10 Real Nature & Atmospheric Video Packs */}
      <div className="bg-[#161922] p-3 rounded-2xl border border-emerald-500/30 space-y-2">
        <span className="text-xs font-extrabold text-emerald-300 flex items-center gap-1.5">
          <Trees className="w-4 h-4" />
          <span>3. اختر فيديوهات الطبيعة الخلفية النقية (10 باقات حقيقية HD):</span>
        </span>
        <div className="grid grid-cols-2 gap-1.5 max-h-44 overflow-y-auto pr-0.5">
          {NATURE_PACK_OPTIONS.map((pk) => {
            const active = naturePackId === pk.id;
            return (
              <button
                key={pk.id}
                type="button"
                data-testid={`nature-pack-${pk.id}`}
                onClick={() => setNaturePackId(pk.id)}
                className={`p-2 rounded-xl border text-right transition cursor-pointer ${
                  active
                    ? 'bg-emerald-500/20 border-emerald-400 text-white'
                    : 'bg-black/60 border-zinc-800 text-zinc-300 hover:border-zinc-600'
                }`}
              >
                <div className="text-[11px] font-extrabold truncate">
                  {pk.labelAr}
                </div>
                <div className="text-[9px] text-zinc-400 line-clamp-1">
                  {pk.descAr}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* STEP 3: 22 Pure Clean Quranic Scene Presets */}
      <div className="space-y-2">
        <span className="text-xs font-extrabold text-amber-200 block">
          4. أو اختر قالباً قرآنياً جاهزاً بنقرة واحدة ({QURAN_VISUAL_THEMES.length} قالب نقي):
        </span>
        <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-0.5">
          {QURAN_VISUAL_THEMES.map((qt) => {
            const active = visualThemeId === qt.id;
            return (
              <button
                key={qt.id}
                type="button"
                data-testid={`quran-theme-${qt.id}`}
                onClick={() => {
                  setVisualThemeId(qt.id);
                  setTargetAspectRatio(qt.aspectRatio);
                  setNaturePackId(qt.defaultNaturePack);
                  setIncludeEnglish(qt.includeEnglishTranslation);
                  setHighlightWords(qt.highlightWords);
                }}
                className={`p-2.5 rounded-xl bg-gradient-to-br ${qt.gradient} border text-right transition cursor-pointer ${
                  active
                    ? 'border-amber-300 ring-1 ring-amber-300/60 shadow-lg'
                    : 'border-zinc-800 hover:border-amber-400/50'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-black/65 text-amber-300 truncate">
                    {qt.badge}
                  </span>
                  <span className="text-[9px] font-mono text-zinc-300">
                    {qt.aspectRatio}
                  </span>
                </div>
                <div className="text-xs font-black text-white truncate">
                  {qt.nameAr}
                </div>
                <div className="text-[10px] text-zinc-300 line-clamp-1 mt-0.5">
                  {qt.descAr}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Quick 1-Minute+ Passages Strip */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-bold text-zinc-300 block">
          مقاطع وسور جاهزة بمدة دقيقة وأكثر:
        </span>
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {LONG_MINUTE_PLUS_PASSAGES.map((lp) => {
            const selected =
              surahNumber === lp.surah &&
              startAyah === lp.start &&
              endAyah === lp.end;
            return (
              <button
                key={lp.id}
                type="button"
                onClick={() => {
                  setSurahNumber(lp.surah);
                  setStartAyah(lp.start);
                  setEndAyah(lp.end);
                }}
                className={`px-3 py-1.5 rounded-full text-[11px] font-bold shrink-0 transition cursor-pointer ${
                  selected
                    ? 'bg-[#00E5DF] text-zinc-950 font-black'
                    : 'bg-[#142028] text-cyan-200 border border-cyan-500/35 hover:border-[#00E5DF]'
                }`}
              >
                {lp.label}
              </button>
            );
          })}

          {OFFLINE_QURAN_GEMS.map((gem) => {
            const selected =
              surahNumber === gem.surahNumber &&
              startAyah === gem.startAyah &&
              endAyah === gem.endAyah;
            return (
              <button
                key={gem.id}
                type="button"
                data-testid={`quran-gem-${gem.id}`}
                onClick={() => {
                  setSurahNumber(gem.surahNumber);
                  setStartAyah(gem.startAyah);
                  setEndAyah(gem.endAyah);
                }}
                className={`px-3 py-1.5 rounded-full text-[11px] font-bold shrink-0 transition cursor-pointer ${
                  selected
                    ? 'bg-amber-400 text-zinc-950 font-black'
                    : 'bg-[#1B1D24] text-zinc-200 border border-zinc-800 hover:border-amber-400/50'
                }`}
              >
                {gem.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Full 114 Surahs Selector + Ayah Range (Up to 80 Verses!) */}
      <div className="bg-[#1B1D24] p-3 rounded-2xl border border-zinc-800 space-y-2.5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <label className="space-y-1 block">
            <span className="text-[11px] font-bold text-zinc-300">
              السورة الكريمة (114 سورة)
            </span>
            <select
              data-testid="quran-surah-select"
              value={surahNumber}
              onChange={(e) => handleSelectSurah(parseInt(e.target.value, 10))}
              className="w-full rounded-xl bg-black border border-zinc-700 px-2.5 py-2 text-xs font-bold text-white"
            >
              {SURAHS_LIST.map((s) => (
                <option key={s.number} value={s.number}>
                  {s.number}. سورة {s.nameAr} ({s.ayahCount} آية)
                </option>
              ))}
            </select>
          </label>

          <label className="space-y-1 block">
            <span className="text-[11px] font-bold text-zinc-300 inline-flex items-center gap-1">
              <Mic className="w-3 h-3 text-amber-300" />
              <span>صوت القارئ</span>
            </span>
            <select
              data-testid="quran-reciter-select"
              value={reciterId}
              onChange={(e) => setReciterId(e.target.value)}
              className="w-full rounded-xl bg-black border border-zinc-700 px-2.5 py-2 text-xs font-bold text-amber-200"
            >
              {QURAN_RECITERS.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.nameAr} — {r.styleAr}
                </option>
              ))}
              <option value="none">بدون تلاوة تلقائية (سأضيف صوتي بنفسي)</option>
            </select>
          </label>
        </div>

        {/* Ayah Start -> End Range up to 80 Ayahs */}
        <div className="grid grid-cols-2 gap-2">
          <label className="space-y-1 block">
            <span className="text-[10px] text-zinc-400">
              من الآية (1 - {currentSurah.ayahCount})
            </span>
            <input
              type="number"
              min={1}
              max={currentSurah.ayahCount}
              value={startAyah}
              onChange={(e) => {
                const v = Math.max(
                  1,
                  Math.min(
                    currentSurah.ayahCount,
                    parseInt(e.target.value, 10) || 1
                  )
                );
                setStartAyah(v);
                if (endAyah < v)
                  setEndAyah(Math.min(currentSurah.ayahCount, v + 8));
              }}
              className="w-full rounded-xl bg-black border border-zinc-700 px-3 py-1.5 text-xs font-mono text-white"
            />
          </label>

          <label className="space-y-1 block">
            <div className="flex items-center justify-between text-[10px] text-zinc-400">
              <span>إلى الآية (حتى 80 آية متصلة)</span>
              <button
                type="button"
                onClick={() =>
                  setEndAyah(
                    Math.min(currentSurah.ayahCount, startAyah + 79)
                  )
                }
                className="text-amber-300 font-bold hover:underline cursor-pointer"
              >
                كامل السورة
              </button>
            </div>
            <input
              type="number"
              min={startAyah}
              max={Math.min(currentSurah.ayahCount, startAyah + 79)}
              value={endAyah}
              onChange={(e) => {
                const v = Math.max(
                  startAyah,
                  Math.min(
                    currentSurah.ayahCount,
                    parseInt(e.target.value, 10) || startAyah
                  )
                );
                setEndAyah(v);
              }}
              className="w-full rounded-xl bg-black border border-zinc-700 px-3 py-1.5 text-xs font-mono text-white"
            />
          </label>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <label className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-200 cursor-pointer">
            <input
              type="checkbox"
              checked={highlightWords}
              onChange={(e) => setHighlightWords(e.target.checked)}
              className="accent-amber-400 w-4 h-4"
            />
            <span>تلوين الكلمات مع التلاوة</span>
          </label>

          <label className="inline-flex items-center gap-1.5 text-xs font-bold text-[#00E5DF] cursor-pointer">
            <input
              type="checkbox"
              checked={includeEnglish}
              onChange={(e) => setIncludeEnglish(e.target.checked)}
              className="accent-[#00E5DF] w-4 h-4"
            />
            <span>إرفاق الترجمة الإنجليزية 🌍</span>
          </label>
        </div>

        {hasExistingClips && (
          <label className="flex items-center gap-2 pt-1 border-t border-zinc-800 text-xs font-bold text-emerald-300 cursor-pointer">
            <input
              type="checkbox"
              checked={keepExistingClips}
              onChange={(e) => setKeepExistingClips(e.target.checked)}
              className="accent-emerald-400 w-4 h-4"
            />
            <span>
              استخدم المقاطع الموجودة حالياً في الخط الزمني بدلاً من تحميل مشاهد طبيعة جديدة
            </span>
          </label>
        )}
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <button
          type="button"
          disabled={isBusy}
          data-testid="generate-quran-video-btn"
          onClick={() =>
            onGenerateQuranVideo({
              surahNumber,
              startAyah,
              endAyah,
              reciterId,
              visualThemeId,
              targetAspectRatio,
              naturePackId,
              minDurationSec,
              includeEnglish,
              highlightWords,
              keepExistingClips,
            })
          }
          className="py-3.5 px-4 rounded-xl bg-gradient-to-l from-amber-300 via-yellow-400 to-amber-500 hover:brightness-105 text-zinc-950 font-black text-xs inline-flex items-center justify-center gap-2 shadow-lg transition cursor-pointer disabled:opacity-50"
        >
          <Sparkles className="w-4 h-4" />
          <span>إنشاء القالب القرآني النقي الآن 🕌</span>
        </button>

        <button
          type="button"
          disabled={isBusy}
          onClick={() => bgFileInputRef.current?.click()}
          className="py-3.5 px-4 rounded-xl bg-[#1B1D24] hover:bg-zinc-800 text-white border border-amber-400/40 font-bold text-xs inline-flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
        >
          <Upload className="w-4 h-4 text-amber-300" />
          <span>ارفع فيديو خاصاً من هاتفك + التلاوة</span>
        </button>
      </div>
    </div>
  );
};
