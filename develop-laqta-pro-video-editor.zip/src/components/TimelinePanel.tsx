import React, { useMemo, useRef, useState } from 'react';
import {
  ArrowLeftRight,
  ChevronLeft,
  ChevronRight,
  Combine,
  Copy,
  Layers,
  Music,
  Plus,
  Scissors,
  Snowflake,
  Trash2,
  Type,
  Volume2,
  VolumeX,
  Wand2,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { FILTER_PRESETS, TRANSITION_PRESETS } from '../constants/presets';
import { computeClipSlots } from '../engine/compositor';
import { CapCutFilterToolbarIcon } from './FilterIcon';
import {
  AudioClip,
  MediaAsset,
  OverlayClip,
  TextOverlay,
  VideoClip,
  VideoEffectClip,
} from '../types/editor';

interface TimelinePanelProps {
  assets: MediaAsset[];
  clips: VideoClip[];
  texts: TextOverlay[];
  effects: VideoEffectClip[];
  overlays: OverlayClip[];
  audioClips: AudioClip[];
  currentTime: number;
  totalDuration: number;
  selectedClipId: string | null;
  selectedTextId: string | null;
  selectedEffectId: string | null;
  selectedOverlayId: string | null;
  selectedAudioId: string | null;
  onSeek: (time: number) => void;
  onQuickAddMedia: () => void;
  onQuickAddText: () => void;
  onQuickAddAudio: () => void;
  onToggleMuteAllClips: () => void;
  onSelectClip: (id: string | null) => void;
  onSelectText: (id: string | null) => void;
  onSelectEffect: (id: string | null) => void;
  onSelectOverlay: (id: string | null) => void;
  onSelectAudio: (id: string | null) => void;
  onOpenTransitionForClip: (clipId: string) => void;
  onSplitAtPlayhead: () => void;
  onFreezeFrameAtPlayhead: () => void;
  onMergeClipWithNext: () => void;
  onTrimClipToPlayhead: (edge: 'start' | 'end') => void;
  onReorderClip: (direction: 'prev' | 'next') => void;
  onDuplicateSelected: () => void;
  onDeleteSelected: () => void;
  onUpdateClipTrimLive: (
    clipId: string,
    newTrimStart: number,
    newDuration: number
  ) => void;
  onUpdateTextTimingLive: (
    textId: string,
    newStartTime: number,
    newDuration: number
  ) => void;
  onUpdateEffectTimingLive: (
    effectId: string,
    newStartTime: number,
    newDuration: number
  ) => void;
  onUpdateOverlayTimingLive: (
    overlayId: string,
    newStartTime: number,
    newDuration: number
  ) => void;
  onUpdateAudioTimingLive: (
    audioId: string,
    newStartTime: number,
    newDuration: number
  ) => void;
  onCommitGestureHistory: () => void;
}

export const TimelinePanel: React.FC<TimelinePanelProps> = ({
  assets,
  clips,
  texts,
  effects,
  overlays,
  audioClips,
  currentTime,
  totalDuration,
  selectedClipId,
  selectedTextId,
  selectedEffectId,
  selectedOverlayId,
  selectedAudioId,
  onSeek,
  onQuickAddMedia,
  onQuickAddText,
  onQuickAddAudio,
  onToggleMuteAllClips,
  onSelectClip,
  onSelectText,
  onSelectEffect,
  onSelectOverlay,
  onSelectAudio,
  onOpenTransitionForClip,
  onSplitAtPlayhead,
  onFreezeFrameAtPlayhead,
  onMergeClipWithNext,
  onTrimClipToPlayhead,
  onReorderClip,
  onDuplicateSelected,
  onDeleteSelected,
  onUpdateClipTrimLive,
  onUpdateTextTimingLive,
  onUpdateEffectTimingLive,
  onUpdateOverlayTimingLive,
  onUpdateAudioTimingLive,
  onCommitGestureHistory,
}) => {
  const [pxPerSec, setPxPerSec] = useState(58);
  const trackAreaRef = useRef<HTMLDivElement | null>(null);

  const assetMap = useMemo(
    () => new Map(assets.map((a) => [a.id, a])),
    [assets]
  );
  const clipSlots = useMemo(() => computeClipSlots(clips), [clips]);
  const selectedClipIndex = clips.findIndex((c) => c.id === selectedClipId);
  const allClipsMuted =
    clips.length > 0 && clips.every((c) => c.type === 'image' || c.muted);
  const hasAnySelection = Boolean(
    selectedClipId ||
      selectedTextId ||
      selectedAudioId ||
      selectedEffectId ||
      selectedOverlayId
  );

  const HEADER_GUTTER_PX = 68;
  const timelineWidthPx = Math.max(
    420,
    HEADER_GUTTER_PX + Math.ceil((Math.max(6, totalDuration) + 3.5) * pxPerSec)
  );

  const ticks = useMemo(() => {
    const step = pxPerSec >= 78 ? 1 : 2;
    const count = Math.ceil((Math.max(6, totalDuration) + 2) / step);
    return Array.from({ length: count + 1 }, (_, i) => i * step);
  }, [pxPerSec, totalDuration]);

  const scrubFromClientX = (clientX: number) => {
    const el = trackAreaRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = Math.max(0, clientX - rect.left - HEADER_GUTTER_PX);
    const t = Math.max(0, Math.min(totalDuration, x / pxPerSec));
    onSeek(t);
  };

  const startDrag = (
    e: React.PointerEvent,
    onMoveDeltaSec: (deltaSec: number) => void
  ) => {
    e.stopPropagation();
    const startX = e.clientX;
    let moved = false;

    const handleMove = (ev: PointerEvent) => {
      moved = true;
      const dx = ev.clientX - startX;
      onMoveDeltaSec(dx / pxPerSec);
    };
    const handleUp = () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
      if (moved) onCommitGestureHistory();
    };

    window.addEventListener('pointermove', handleMove);
    window.addEventListener('pointerup', handleUp);
  };

  const formatRulerTick = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  return (
    <div className="bg-[#101115] border-t border-zinc-800/90 flex flex-col select-none relative">
      {/* CapCut Quick Action Strip right above Filmstrip */}
      <div className="px-2.5 py-1.5 border-b border-zinc-800/80 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar bg-[#14151A]">
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            data-testid="split-clip-btn"
            onClick={onSplitAtPlayhead}
            disabled={clips.length === 0}
            title="تقسيم عند المؤشر"
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-[11px] font-bold text-white transition cursor-pointer disabled:opacity-35"
          >
            <Scissors className="w-3.5 h-3.5 text-[#00E5DF]" />
            <span>تقسيم</span>
          </button>

          <button
            type="button"
            data-testid="freeze-frame-btn"
            onClick={onFreezeFrameAtPlayhead}
            disabled={clips.length === 0}
            title="تجميد الإطار الحالي (2 ثانية)"
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-[11px] font-bold text-zinc-200 transition cursor-pointer disabled:opacity-35"
          >
            <Snowflake className="w-3.5 h-3.5 text-sky-400" />
            <span>تجميد</span>
          </button>

          <button
            type="button"
            data-testid="trim-start-btn"
            onClick={() => onTrimClipToPlayhead('start')}
            disabled={clips.length === 0}
            className="px-2 py-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-[11px] font-semibold text-zinc-200 cursor-pointer disabled:opacity-35"
          >
            قص يمين
          </button>

          <button
            type="button"
            data-testid="trim-end-btn"
            onClick={() => onTrimClipToPlayhead('end')}
            disabled={clips.length === 0}
            className="px-2 py-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-[11px] font-semibold text-zinc-200 cursor-pointer disabled:opacity-35"
          >
            قص يسار
          </button>

          <button
            type="button"
            data-testid="merge-clips-btn"
            onClick={onMergeClipWithNext}
            disabled={
              selectedClipIndex === -1 || selectedClipIndex >= clips.length - 1
            }
            className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-[11px] font-bold text-zinc-200 cursor-pointer disabled:opacity-35"
          >
            <Combine className="w-3.5 h-3.5 text-[#00E5DF]" />
            <span>دمج</span>
          </button>

          <button
            type="button"
            onClick={() => onReorderClip('prev')}
            disabled={selectedClipIndex <= 0}
            title="تقديم"
            className="p-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-zinc-300 cursor-pointer disabled:opacity-30"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onReorderClip('next')}
            disabled={
              selectedClipIndex === -1 || selectedClipIndex >= clips.length - 1
            }
            title="تأخير"
            className="p-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-zinc-300 cursor-pointer disabled:opacity-30"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={onDuplicateSelected}
            disabled={!hasAnySelection}
            title="نسخ العنصر"
            className="p-1 rounded-lg bg-zinc-800/90 hover:bg-zinc-700 text-zinc-200 cursor-pointer disabled:opacity-30"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            data-testid="delete-selected-btn"
            onClick={onDeleteSelected}
            disabled={!hasAnySelection}
            title="حذف"
            className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 text-[11px] font-bold cursor-pointer disabled:opacity-30"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>حذف</span>
          </button>
        </div>

        {/* Zoom Slider */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => setPxPerSec((z) => Math.max(24, z - 14))}
            className="p-1 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-400 cursor-pointer"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setPxPerSec((z) => Math.min(140, z + 14))}
            className="p-1 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-400 cursor-pointer"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* CapCut Floating White [ + ] Add Media Button on right edge! */}
      <button
        type="button"
        data-testid="floating-add-media-btn"
        title="إضافة فيديو أو صورة جديدة"
        onClick={onQuickAddMedia}
        className="absolute right-2.5 top-[82px] z-30 w-8 h-8 rounded-lg bg-white hover:bg-[#00E5DF] text-zinc-950 shadow-xl flex items-center justify-center transition active:scale-95 cursor-pointer"
      >
        <Plus className="w-5 h-5 stroke-[2.8]" />
      </button>

      {/* Multi-Track Scrollable CapCut Filmstrip Area */}
      <div
        dir="ltr"
        className="overflow-x-auto overflow-y-auto max-h-[215px] relative bg-[#0D0E12]"
      >
        <div
          ref={trackAreaRef}
          style={{ width: `${timelineWidthPx}px` }}
          className="relative pb-2.5 min-h-[168px]"
        >
          {/* Time Ruler */}
          <div
            onPointerDown={(e) => {
              scrubFromClientX(e.clientX);
              const onMove = (ev: PointerEvent) => scrubFromClientX(ev.clientX);
              const onUp = () => {
                window.removeEventListener('pointermove', onMove);
                window.removeEventListener('pointerup', onUp);
              };
              window.addEventListener('pointermove', onMove);
              window.addEventListener('pointerup', onUp);
            }}
            className="h-6 bg-[#111217] border-b border-zinc-800/80 relative cursor-pointer sticky top-0 z-20"
          >
            {ticks.map((sec) => (
              <div
                key={sec}
                style={{ left: `${HEADER_GUTTER_PX + sec * pxPerSec}px` }}
                className="absolute top-0 bottom-0 flex items-center pointer-events-none"
              >
                <span className="text-[10px] font-mono text-zinc-500 -translate-x-1/2">
                  {formatRulerTick(sec)}
                </span>
              </div>
            ))}
          </div>

          {/* Track 1: Orange Text / Captions / Stickers Track */}
          <div className="relative h-8 my-0.5 flex items-center">
            <button
              type="button"
              onClick={onQuickAddText}
              style={{ width: `${HEADER_GUTTER_PX - 6}px` }}
              className="sticky left-1 z-10 h-7 rounded bg-zinc-900/95 hover:bg-zinc-800 border border-zinc-800 text-[10px] font-bold text-orange-300 flex items-center justify-center gap-0.5 shrink-0 cursor-pointer"
            >
              <Type className="w-3 h-3" />
              <span>+ نص</span>
            </button>

            {texts.map((t) => {
              const left = HEADER_GUTTER_PX + t.startTime * pxPerSec;
              const width = Math.max(30, t.duration * pxPerSec);
              const isSelected = selectedTextId === t.id;
              const origStart = t.startTime;
              const origDur = t.duration;

              return (
                <div
                  key={t.id}
                  style={{ left: `${left}px`, width: `${width}px` }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectText(t.id);
                  }}
                  onPointerDown={(e) => {
                    onSelectText(t.id);
                    startDrag(e, (dt) =>
                      onUpdateTextTimingLive(
                        t.id,
                        Math.max(0, Number((origStart + dt).toFixed(2))),
                        origDur
                      )
                    );
                  }}
                  className={`absolute top-0.5 bottom-0.5 rounded-md px-2 flex items-center justify-between text-[11px] font-bold cursor-grab active:cursor-grabbing overflow-hidden ${
                    isSelected
                      ? 'bg-[#EA580C] border-2 border-white text-white z-10 shadow'
                      : t.isSticker
                        ? 'bg-pink-700/80 border border-pink-400/50 text-pink-50'
                        : 'bg-[#9A3412]/90 border border-orange-500/45 text-orange-100'
                  }`}
                >
                  <span dir="rtl" className="truncate w-full text-right">
                    {t.text}
                  </span>
                  <div
                    onPointerDown={(e) =>
                      startDrag(e, (dt) =>
                        onUpdateTextTimingLive(
                          t.id,
                          origStart,
                          Math.max(0.4, Number((origDur + dt).toFixed(2)))
                        )
                      )
                    }
                    className="w-2 h-full bg-white/75 cursor-ew-resize shrink-0 -mr-2 ml-1"
                  />
                </div>
              );
            })}
          </div>

          {/* Optional Track 2: Purple CapCut Video Effects Track (shown when effects exist) */}
          {effects.length > 0 && (
            <div className="relative h-7 my-0.5 flex items-center">
              <div
                style={{ width: `${HEADER_GUTTER_PX - 6}px` }}
                className="sticky left-1 z-10 h-6 rounded bg-purple-950/90 border border-purple-700/50 text-[10px] font-bold text-purple-200 flex items-center justify-center gap-0.5 shrink-0"
              >
                <Wand2 className="w-3 h-3" />
                <span>مؤثر</span>
              </div>

              {effects.map((ef) => {
                const left = HEADER_GUTTER_PX + ef.startTime * pxPerSec;
                const width = Math.max(30, ef.duration * pxPerSec);
                const isSelected = selectedEffectId === ef.id;
                const origStart = ef.startTime;
                const origDur = ef.duration;

                return (
                  <div
                    key={ef.id}
                    style={{ left: `${left}px`, width: `${width}px` }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectEffect(ef.id);
                    }}
                    onPointerDown={(e) => {
                      onSelectEffect(ef.id);
                      startDrag(e, (dt) =>
                        onUpdateEffectTimingLive(
                          ef.id,
                          Math.max(0, Number((origStart + dt).toFixed(2))),
                          origDur
                        )
                      );
                    }}
                    className={`absolute top-0.5 bottom-0.5 rounded-md px-2 flex items-center justify-between text-[10px] font-bold cursor-grab overflow-hidden ${
                      isSelected
                        ? 'bg-purple-600 border-2 border-white text-white z-10'
                        : 'bg-purple-900/85 border border-purple-400/50 text-purple-100'
                    }`}
                  >
                    <span dir="rtl" className="truncate w-full text-right">
                      ✨ {ef.name}
                    </span>
                    <div
                      onPointerDown={(e) =>
                        startDrag(e, (dt) =>
                          onUpdateEffectTimingLive(
                            ef.id,
                            origStart,
                            Math.max(0.4, Number((origDur + dt).toFixed(2)))
                          )
                        )
                      }
                      className="w-2 h-full bg-white/75 cursor-ew-resize shrink-0 -mr-2 ml-1"
                    />
                  </div>
                );
              })}
            </div>
          )}

          {/* Optional Track 3: Indigo Picture-in-Picture (PIP Overlay) Track */}
          {overlays.length > 0 && (
            <div className="relative h-8 my-0.5 flex items-center">
              <div
                style={{ width: `${HEADER_GUTTER_PX - 6}px` }}
                className="sticky left-1 z-10 h-7 rounded bg-indigo-950/90 border border-indigo-700/50 text-[10px] font-bold text-indigo-200 flex items-center justify-center gap-0.5 shrink-0"
              >
                <Layers className="w-3 h-3" />
                <span>PIP</span>
              </div>

              {overlays.map((ov) => {
                const left = HEADER_GUTTER_PX + ov.startTime * pxPerSec;
                const width = Math.max(32, ov.duration * pxPerSec);
                const isSelected = selectedOverlayId === ov.id;
                const origStart = ov.startTime;
                const origDur = ov.duration;

                return (
                  <div
                    key={ov.id}
                    style={{ left: `${left}px`, width: `${width}px` }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectOverlay(ov.id);
                    }}
                    onPointerDown={(e) => {
                      onSelectOverlay(ov.id);
                      startDrag(e, (dt) =>
                        onUpdateOverlayTimingLive(
                          ov.id,
                          Math.max(0, Number((origStart + dt).toFixed(2))),
                          origDur
                        )
                      );
                    }}
                    className={`absolute top-0.5 bottom-0.5 rounded-md px-2 flex items-center justify-between text-[10px] font-bold cursor-grab overflow-hidden ${
                      isSelected
                        ? 'bg-indigo-600 border-2 border-white text-white z-10'
                        : 'bg-indigo-900/85 border border-indigo-400/50 text-indigo-100'
                    }`}
                  >
                    <span dir="rtl" className="truncate w-full text-right">
                      🖼️ {ov.name}
                    </span>
                    <div
                      onPointerDown={(e) =>
                        startDrag(e, (dt) =>
                          onUpdateOverlayTimingLive(
                            ov.id,
                            origStart,
                            Math.max(0.4, Number((origDur + dt).toFixed(2)))
                          )
                        )
                      }
                      className="w-2 h-full bg-white/75 cursor-ew-resize shrink-0 -mr-2 ml-1"
                    />
                  </div>
                );
              })}
            </div>
          )}

          {/* Track 4: Signature CapCut Main Filmstrip Track + Mute Original Audio Head Button */}
          <div className="relative h-14 my-1 flex items-center bg-[#13151B]/90">
            {/* CapCut "كتم صوت المقطع" button pinned on left of main track */}
            <button
              type="button"
              onClick={onToggleMuteAllClips}
              title="كتم / تشغيل الصوت الأصلي للفيديو"
              style={{ width: `${HEADER_GUTTER_PX - 6}px` }}
              className="sticky left-1 z-10 h-12 rounded-lg bg-[#191B22] hover:bg-zinc-800 border border-zinc-800 flex flex-col items-center justify-center gap-0.5 text-[9px] font-bold text-zinc-300 shrink-0 cursor-pointer"
            >
              {allClipsMuted ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                  <span className="text-rose-300">مكتوم</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-zinc-200" />
                  <span>الصوت</span>
                </>
              )}
            </button>

            {clipSlots.length === 0 ? (
              <button
                type="button"
                onClick={onQuickAddMedia}
                className="ml-4 px-4 py-2 rounded-lg border border-dashed border-zinc-700 hover:border-[#00E5DF] text-xs font-bold text-zinc-400 hover:text-white cursor-pointer"
              >
                + اضغط لإضافة أول مقطع فيديو أو صورة
              </button>
            ) : (
              clipSlots.map((slot, idx) => {
                const { clip, startTime } = slot;
                const asset = assetMap.get(clip.assetId);
                const left = HEADER_GUTTER_PX + startTime * pxPerSec;
                const width = Math.max(36, clip.duration * pxPerSec);
                const isSelected = selectedClipId === clip.id;
                const origTrim = clip.trimStart;
                const origDur = clip.duration;
                const transDef = TRANSITION_PRESETS.find(
                  (tr) => tr.id === clip.transitionIn?.type
                );

                return (
                  <React.Fragment key={clip.id}>
                    <div
                      style={{ left: `${left}px`, width: `${width}px` }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectClip(clip.id);
                      }}
                      className={`absolute top-1 bottom-1 rounded-lg overflow-hidden flex items-center cursor-pointer transition ${
                        isSelected
                          ? 'ring-2 ring-white bg-zinc-800 z-10 shadow-xl'
                          : 'border border-zinc-700/80 bg-zinc-900 hover:border-zinc-500'
                      }`}
                    >
                      {asset?.thumbnailDataUrl && (
                        <div
                          style={{
                            backgroundImage: `url(${asset.thumbnailDataUrl})`,
                            backgroundSize: 'auto 100%',
                            backgroundRepeat: 'repeat-x',
                          }}
                          className="absolute inset-0 opacity-65 pointer-events-none"
                        />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/30 pointer-events-none" />

                      {/* CapCut White Left Trim Handle */}
                      <div
                        title="قص بداية المقطع"
                        onPointerDown={(e) => {
                          onSelectClip(clip.id);
                          startDrag(e, (dt) => {
                            if (clip.type === 'image') {
                              onUpdateClipTrimLive(
                                clip.id,
                                0,
                                Math.max(0.4, origDur - dt)
                              );
                            } else {
                              const maxTrim =
                                origTrim + origDur * (clip.speed || 1) - 0.3;
                              const nextTrim = Math.max(
                                0,
                                Math.min(maxTrim, origTrim + dt * (clip.speed || 1))
                              );
                              const consumed =
                                (nextTrim - origTrim) / (clip.speed || 1);
                              onUpdateClipTrimLive(
                                clip.id,
                                Number(nextTrim.toFixed(2)),
                                Math.max(0.3, Number((origDur - consumed).toFixed(2)))
                              );
                            }
                          });
                        }}
                        className={`relative z-20 h-full w-3 flex items-center justify-center cursor-ew-resize shrink-0 ${
                          isSelected
                            ? 'bg-white text-black'
                            : 'bg-black/45 hover:bg-white/80 text-white hover:text-black'
                        }`}
                      >
                        <div className="w-[2px] h-4 bg-current rounded-full" />
                      </div>

                      {/* Clip Duration & Filter Badge */}
                      <div
                        dir="rtl"
                        className="relative z-10 flex-1 px-1.5 overflow-hidden flex flex-col justify-between h-full py-0.5 pointer-events-none"
                      >
                        <span className="text-[10px] font-bold text-white truncate drop-shadow">
                          {clip.duration.toFixed(1)}s • {clip.name}
                        </span>
                        {clip.adjustments.filter !== 'none' && (
                          <span className="self-start inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded bg-black/75 border border-[#00E5DF]/45 text-[#00E5DF]">
                            <CapCutFilterToolbarIcon className="w-2.5 h-2.5 shrink-0" />
                            <span>
                              {FILTER_PRESETS.find(
                                (f) => f.id === clip.adjustments.filter
                              )?.nameAr || 'فلتر'}
                            </span>
                          </span>
                        )}
                      </div>

                      {/* CapCut White Right Trim Handle */}
                      <div
                        title="قص نهاية المقطع"
                        onPointerDown={(e) => {
                          onSelectClip(clip.id);
                          startDrag(e, (dt) => {
                            if (clip.type === 'image') {
                              onUpdateClipTrimLive(
                                clip.id,
                                0,
                                Math.max(0.4, Number((origDur + dt).toFixed(2)))
                              );
                            } else {
                              const maxDur =
                                (clip.sourceDuration - origTrim) /
                                (clip.speed || 1);
                              const nextDur = Math.max(
                                0.3,
                                Math.min(maxDur, origDur + dt)
                              );
                              onUpdateClipTrimLive(
                                clip.id,
                                origTrim,
                                Number(nextDur.toFixed(2))
                              );
                            }
                          });
                        }}
                        className={`relative z-20 h-full w-3 flex items-center justify-center cursor-ew-resize shrink-0 ${
                          isSelected
                            ? 'bg-white text-black'
                            : 'bg-black/45 hover:bg-white/80 text-white hover:text-black'
                        }`}
                      >
                        <div className="w-[2px] h-4 bg-current rounded-full" />
                      </div>
                    </div>

                    {/* CapCut Square White Transition Button [ | ] between clips */}
                    {idx > 0 && (
                      <button
                        type="button"
                        data-testid={`transition-junction-${idx}`}
                        title={
                          clip.transitionIn.type === 'none'
                            ? 'إضافة انتقال CapCut'
                            : `انتقال: ${transDef?.nameAr}`
                        }
                        style={{ left: `${left - 11}px` }}
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenTransitionForClip(clip.id);
                        }}
                        className={`absolute top-1/2 -translate-y-1/2 z-20 w-[22px] h-[22px] rounded-md flex items-center justify-center shadow-lg transition cursor-pointer ${
                          clip.transitionIn.type !== 'none'
                            ? 'bg-[#00E5DF] text-zinc-950 ring-2 ring-black'
                            : 'bg-white text-zinc-900 hover:bg-[#00E5DF]'
                        }`}
                      >
                        <ArrowLeftRight className="w-3 h-3 stroke-[2.5]" />
                      </button>
                    )}
                  </React.Fragment>
                );
              })
            )}
          </div>

          {/* Track 5: Teal CapCut Audio & Music Waveform Track */}
          <div className="relative h-9 my-0.5 flex items-center">
            <button
              type="button"
              onClick={onQuickAddAudio}
              style={{ width: `${HEADER_GUTTER_PX - 6}px` }}
              className="sticky left-1 z-10 h-8 rounded bg-zinc-900/95 hover:bg-zinc-800 border border-zinc-800 text-[10px] font-bold text-[#00E5DF] flex items-center justify-center gap-0.5 shrink-0 cursor-pointer"
            >
              <Music className="w-3 h-3" />
              <span>+ صوت</span>
            </button>

            {audioClips.length === 0 ? (
              <div
                onClick={onQuickAddAudio}
                style={{ left: `${HEADER_GUTTER_PX}px` }}
                className="ml-2 h-7 px-3 rounded-md bg-[#16181F] hover:bg-zinc-800 border border-zinc-800/90 flex items-center gap-1.5 text-[11px] font-semibold text-zinc-400 cursor-pointer"
              >
                <Music className="w-3 h-3 text-[#00E5DF]" />
                <span>+ إضافة موسيقى أو تعليق صوتي</span>
              </div>
            ) : (
              audioClips.map((ac) => {
                const asset = assetMap.get(ac.assetId);
                const left = HEADER_GUTTER_PX + ac.startTime * pxPerSec;
                const width = Math.max(32, ac.duration * pxPerSec);
                const isSelected = selectedAudioId === ac.id;
                const origStart = ac.startTime;
                const origDur = ac.duration;
                const peaks = asset?.waveformPeaks || [];

                return (
                  <div
                    key={ac.id}
                    style={{ left: `${left}px`, width: `${width}px` }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectAudio(ac.id);
                    }}
                    onPointerDown={(e) => {
                      onSelectAudio(ac.id);
                      startDrag(e, (dt) =>
                        onUpdateAudioTimingLive(
                          ac.id,
                          Math.max(0, Number((origStart + dt).toFixed(2))),
                          origDur
                        )
                      );
                    }}
                    className={`absolute top-0.5 bottom-0.5 rounded-md px-2 flex items-center overflow-hidden cursor-grab ${
                      isSelected
                        ? 'bg-[#0F766E] border-2 border-white text-white z-10'
                        : 'bg-[#115E59]/75 border border-[#00E5DF]/40 text-teal-100'
                    }`}
                  >
                    <div className="absolute inset-x-0 bottom-0 top-2.5 flex items-end gap-[2px] px-1 opacity-40 pointer-events-none">
                      {peaks.map((pk, pi) => (
                        <div
                          key={pi}
                          style={{ height: `${Math.round(pk * 100)}%` }}
                          className="flex-1 bg-[#00E5DF] rounded-t-sm min-w-[2px]"
                        />
                      ))}
                    </div>

                    <span
                      dir="rtl"
                      className="relative z-10 text-[10px] font-bold truncate w-full text-right"
                    >
                      🎵 {ac.name}
                    </span>

                    <div
                      onPointerDown={(e) =>
                        startDrag(e, (dt) => {
                          const maxAudioDur = Math.max(
                            0.3,
                            ac.sourceDuration - ac.trimStart
                          );
                          onUpdateAudioTimingLive(
                            ac.id,
                            origStart,
                            Math.max(
                              0.3,
                              Math.min(maxAudioDur, Number((origDur + dt).toFixed(2)))
                            )
                          );
                        })
                      }
                      className="relative z-20 w-2 h-full bg-white/80 cursor-ew-resize shrink-0 -mr-2 ml-1"
                    />
                  </div>
                );
              })
            )}
          </div>

          {/* Crisp White CapCut Vertical Playhead Line */}
          <div
            data-testid="timeline-playhead"
            style={{ left: `${HEADER_GUTTER_PX + currentTime * pxPerSec}px` }}
            className="absolute top-0 bottom-0 z-30 pointer-events-none"
          >
            <div className="w-2.5 h-2.5 -ml-[4px] bg-white rounded-full shadow" />
            <div className="w-[2px] h-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.9)]" />
          </div>
        </div>
      </div>
    </div>
  );
};
