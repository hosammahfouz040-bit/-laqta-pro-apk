import React, { useRef, useState } from 'react';
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  ArrowLeftRight,
  BookOpen,
  Captions,
  Check,
  CheckCheck,
  Download,
  FileAudio,
  FlipHorizontal,
  FolderPlus,
  Languages,
  Layers,
  LayoutTemplate,
  Maximize2,
  Mic,
  Minimize2,
  Music,
  Play,
  Plus,
  Ratio,
  RotateCcw,
  RotateCw,
  Scissors,
  Sliders,
  Smile,
  Snowflake,
  Sparkles,
  Square,
  Trash2,
  Type,
  Upload,
  Volume2,
  VolumeX,
  Wand2,
} from 'lucide-react';
import {
  ARABIC_FONTS,
  ASPECT_RATIO_OPTIONS,
  CANVAS_BG_SWATCHES,
  CAPCUT_READY_TEMPLATES,
  CAPCUT_STICKER_ITEMS,
  CapCutStickerItem,
  CapCutTemplatePreset,
  FILTER_CATEGORIES,
  FilterCategory,
  FILTER_PRESETS,
  STICKER_CATEGORIES,
  StickerCategory,
  TEMPLATE_CATEGORIES,
  TemplateCategory,
  TEXT_ANIMATIONS,
  TEXT_STYLE_PRESETS,
  TRANSITION_CATEGORIES,
  TransitionCategory,
  TRANSITION_PRESETS,
  VIDEO_EFFECT_CATEGORIES,
  VideoEffectCategory,
  VIDEO_EFFECT_PRESETS,
} from '../constants/presets';
import { CapCutFilterToolbarIcon, FilterPresetIcon } from './FilterIcon';
import {
  REAL_NATURE_STOCK_VIDEOS,
  StockNatureClipSpec,
} from '../services/natureVideoService';
import {
  QuranGenerationRequest,
  QuranStudioPanel,
} from './QuranStudioPanel';
import { BUILT_IN_SOUNDS, BuiltInSoundPreset } from '../engine/audioEngine';
import {
  buildWordTimingsForPhrase,
  exportSubtitlesToSrt,
  extractKeylessAiSubtitles,
  generateSubtitlesFromScript,
  parseSrtContent,
  SPOKEN_SOURCE_LANGUAGES,
  SUPPORTED_TRANSLATION_LANGUAGES,
  translateExistingOverlaysKeyless,
} from '../services/subtitleService';
import {
  ActiveToolTab,
  AspectRatio,
  AudioClip,
  ColorAdjustments,
  DEFAULT_ADJUSTMENTS,
  FitMode,
  MediaAsset,
  OverlayClip,
  TextOverlay,
  TextStylePresetId,
  TransitionType,
  VideoClip,
  VideoEffectClip,
  VideoEffectType,
} from '../types/editor';

export const EDITOR_TOOL_TABS: {
  id: ActiveToolTab;
  label: string;
  icon: React.FC<{ className?: string }>;
}[] = [
  { id: 'edit', label: 'تحرير', icon: Scissors },
  { id: 'quran', label: 'قرآن 🕌', icon: BookOpen },
  { id: 'templates', label: 'قوالب ✨', icon: LayoutTemplate },
  { id: 'audio', label: 'الصوت', icon: Music },
  { id: 'text', label: 'النص', icon: Type },
  { id: 'captions', label: 'الترجمة', icon: Captions },
  { id: 'stickers', label: 'ملصقات', icon: Smile },
  { id: 'overlay', label: 'التراكب', icon: Layers },
  { id: 'effects', label: 'المؤثرات', icon: Wand2 },
  { id: 'transitions', label: 'انتقالات', icon: ArrowLeftRight },
  { id: 'filters', label: 'الفلاتر', icon: CapCutFilterToolbarIcon },
  { id: 'adjust', label: 'ضبط', icon: Sliders },
  { id: 'canvas', label: 'الخلفية', icon: Ratio },
  { id: 'media', label: 'الوسائط +', icon: FolderPlus },
];

interface ToolDrawerPanelProps {
  activeTab: ActiveToolTab;
  onChangeTab: (tab: ActiveToolTab) => void;
  aspectRatio: AspectRatio;
  bgColor: string;
  onChangeAspectRatio: (ar: AspectRatio) => void;
  onChangeBgColor: (color: string) => void;
  assets: MediaAsset[];
  clips: VideoClip[];
  texts: TextOverlay[];
  effects: VideoEffectClip[];
  overlays: OverlayClip[];
  audioClips: AudioClip[];
  totalDuration: number;
  currentTime: number;
  selectedClip: VideoClip | null;
  selectedText: TextOverlay | null;
  selectedEffect: VideoEffectClip | null;
  selectedOverlay: OverlayClip | null;
  selectedAudio: AudioClip | null;
  onSelectClip: (id: string | null) => void;
  onSelectText: (id: string | null) => void;
  onSelectEffect: (id: string | null) => void;
  onSelectOverlay: (id: string | null) => void;
  onSelectAudio: (id: string | null) => void;
  onImportFiles: (files: FileList, asOverlay?: boolean) => void;
  onAddAssetToTimeline: (asset: MediaAsset, asOverlay?: boolean) => void;
  onAddStockNatureVideo: (spec: StockNatureClipSpec) => void;
  onGenerateSampleClip: (theme: 'desert-sunset' | 'neon-city') => void;
  onSplitAtPlayhead: () => void;
  onFreezeFrameAtPlayhead: () => void;
  onExtractClipAudio: (clip: VideoClip) => void;
  onUpdateClip: (clipId: string, patch: Partial<VideoClip>) => void;
  onUpdateClipAdjustments: (
    clipId: string,
    patch: Partial<ColorAdjustments>
  ) => void;
  onApplyAdjustmentsToAll: (adj: ColorAdjustments) => void;
  onApplyTransitionToAll: (type: TransitionType, duration: number) => void;
  onPreviewTransition: (clipId: string) => void;
  onAddText: (presetId?: string, customInitialText?: string) => void;
  onAddSticker: (sticker: CapCutStickerItem) => void;
  onUpdateText: (textId: string, patch: Partial<TextOverlay>) => void;
  onDeleteTextById: (textId: string) => void;
  onAddVideoEffect: (effectType: VideoEffectType, nameAr: string) => void;
  onUpdateVideoEffect: (
    effectId: string,
    patch: Partial<VideoEffectClip>
  ) => void;
  onDeleteEffectById: (effectId: string) => void;
  onUpdateOverlay: (overlayId: string, patch: Partial<OverlayClip>) => void;
  onDeleteOverlayById: (overlayId: string) => void;
  onDeleteAudioById: (audioId: string) => void;
  isBusy?: boolean;
  onGenerateQuranInEditor: (req: QuranGenerationRequest) => void;
  onApplyTemplateToProject: (
    templateId: CapCutTemplatePreset,
    overrideAspect?: AspectRatio
  ) => void;
  onReplaceAllSubtitles: (newSubs: TextOverlay[], appendMode?: boolean) => void;
  onReplaceAllTexts: (newTexts: TextOverlay[]) => void;
  onAddBuiltInSound: (presetId: BuiltInSoundPreset) => void;
  onAddRecordedVoiceover: (blob: Blob) => void;
  onUpdateAudio: (audioId: string, patch: Partial<AudioClip>) => void;
  onSeek: (time: number) => void;
  onNotify: (msg: string, tone?: 'info' | 'error' | 'success') => void;
  isExpandedFull?: boolean;
  onToggleExpandFull?: () => void;
  onCloseDrawer?: () => void;
}

export const ToolDrawerPanel: React.FC<ToolDrawerPanelProps> = ({
  activeTab,
  onChangeTab,
  aspectRatio,
  bgColor,
  onChangeAspectRatio,
  onChangeBgColor,
  assets,
  clips,
  texts,
  effects,
  overlays,
  audioClips,
  totalDuration,
  currentTime,
  selectedClip,
  selectedText,
  selectedEffect,
  selectedOverlay,
  selectedAudio,
  onSelectClip,
  onSelectText,
  onSelectEffect,
  onSelectOverlay,
  onSelectAudio,
  onImportFiles,
  onAddAssetToTimeline,
  onAddStockNatureVideo,
  onGenerateSampleClip,
  onSplitAtPlayhead,
  onFreezeFrameAtPlayhead,
  onExtractClipAudio,
  onUpdateClip,
  onUpdateClipAdjustments,
  onApplyAdjustmentsToAll,
  onApplyTransitionToAll,
  onPreviewTransition,
  onAddText,
  onAddSticker,
  onUpdateText,
  onDeleteTextById,
  onAddVideoEffect,
  onUpdateVideoEffect,
  onDeleteEffectById,
  onUpdateOverlay,
  onDeleteOverlayById,
  onDeleteAudioById,
  isBusy = false,
  onGenerateQuranInEditor,
  onApplyTemplateToProject,
  onReplaceAllSubtitles,
  onReplaceAllTexts,
  onAddBuiltInSound,
  onAddRecordedVoiceover,
  onUpdateAudio,
  onSeek,
  onNotify,
  isExpandedFull,
  onToggleExpandFull,
  onCloseDrawer,
}) => {
  const mediaInputRef = useRef<HTMLInputElement>(null);
  const overlayInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const srtInputRef = useRef<HTMLInputElement>(null);

  // Voiceover recorder
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const voiceRecorderRef = useRef<MediaRecorder | null>(null);
  const voiceChunksRef = useRef<BlobPart[]>([]);

  // Unlimited Keyless CapCut Auto-Captions & Zero-Key Translation State
  const [spokenLang, setSpokenLang] = useState('arabic');
  const [targetLang, setTargetLang] = useState('none');
  const [captionScope, setCaptionScope] = useState<'all' | 'clip'>('all');
  const [appendCaptionsMode, setAppendCaptionsMode] = useState(false);
  const [captionRunCount, setCaptionRunCount] = useState(0);
  const [bilingualMode, setBilingualMode] = useState(false);
  const [captionStyleId, setCaptionStyleId] =
    useState<TextStylePresetId>('bold-words');
  const [isRunningAi, setIsRunningAi] = useState(false);
  const [aiProgressPct, setAiProgressPct] = useState(0);
  const [aiStatusMsg, setAiStatusMsg] = useState('');
  const [quickTranslateLang, setQuickTranslateLang] = useState('en');
  const [isTranslatingExisting, setIsTranslatingExisting] = useState(false);
  const [isDictatingLive, setIsDictatingLive] = useState(false);
  const keepDictatingRef = useRef(false);
  const speechRecRef = useRef<{ stop: () => void; start: () => void } | null>(
    null
  );

  const [filterCat, setFilterCat] = useState<FilterCategory>('all');
  const [effectCat, setEffectCat] = useState<VideoEffectCategory>('all');
  const [transCat, setTransCat] = useState<TransitionCategory>('all');
  const [stickerCat, setStickerCat] = useState<StickerCategory>('all');
  const [editorTemplateCat, setEditorTemplateCat] =
    useState<TemplateCategory>('all');

  const [manualScript, setManualScript] = useState(
    'مرحباً بكم في لقطة برو! محرر الفيديو الاحترافي بأسلوب كاب كات، ترجمة تلقائية ومؤثرات وانتقالات مجاناً.'
  );

  const activeClipForEdit = selectedClip || clips[0] || null;
  const secondOrSelectedClipForTrans =
    selectedClip && clips.findIndex((c) => c.id === selectedClip.id) > 0
      ? selectedClip
      : clips.length > 1
        ? clips[1]
        : clips[0] || null;

  const toggleVoiceRecording = async () => {
    if (isRecordingVoice && voiceRecorderRef.current) {
      voiceRecorderRef.current.stop();
      setIsRecordingVoice(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      voiceChunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      voiceRecorderRef.current = recorder;
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) voiceChunksRef.current.push(ev.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(voiceChunksRef.current, { type: 'audio/webm' });
        if (blob.size > 0) {
          onAddRecordedVoiceover(blob);
        }
      };
      recorder.start();
      setIsRecordingVoice(true);
      onNotify('بدأ تسجيل التعليق الصوتي من الميكروفون...', 'info');
    } catch {
      onNotify(
        'تعذر الوصول إلى الميكروفون. تأكد من منح إذن الميكروفون للمتصفح أو التطبيق.',
        'error'
      );
    }
  };

  // Unlimited Free Local Whisper Speech Recognition + Optional Multi-Language Translation
  const handleRunKeylessAutoCaptions = async () => {
    setIsRunningAi(true);
    setAiProgressPct(5);
    setAiStatusMsg('جاري استخراج الصوت من الفيديو...');
    try {
      const activeClipTarget =
        captionScope === 'clip' && activeClipForEdit
          ? activeClipForEdit.id
          : null;
      const generated = await extractKeylessAiSubtitles({
        assets,
        clips,
        audioClips,
        totalDuration: Math.max(1, totalDuration),
        selectedClipId: activeClipTarget,
        spokenLanguage: spokenLang,
        targetLanguageCode: targetLang,
        bilingual: bilingualMode,
        stylePresetId: captionStyleId,
        onProgress: (pct, msg) => {
          setAiProgressPct(pct);
          setAiStatusMsg(msg);
        },
      });
      onReplaceAllSubtitles(generated, appendCaptionsMode);
      setCaptionRunCount((n) => n + 1);
      onNotify(
        `تم استخراج وإنشاء ${generated.length} جملة ترجمة تلقائية بنجاح (متاح دائماً بلا حدود)!`,
        'success'
      );
    } catch (err) {
      const message =
        err instanceof Error
          ? err.message
          : 'تعذر إتمام استخراج الكلام تلقائياً.';
      onNotify(message, 'error');
    } finally {
      setIsRunningAi(false);
      setAiStatusMsg('');
    }
  };

  // 1-Click Instant Zero-Key Translation of ALL existing texts/captions on timeline!
  const handleInstantTranslateExisting = async () => {
    setIsTranslatingExisting(true);
    try {
      const updated = await translateExistingOverlaysKeyless({
        overlays: texts,
        targetLanguageCode: quickTranslateLang,
        bilingual: bilingualMode,
      });
      onReplaceAllTexts(updated);
      onNotify(
        bilingualMode
          ? 'تم تحويل النصوص إلى ترجمة مزدوجة (أصلي + مترجم) بدون مفتاح!'
          : 'تمت ترجمة جميع النصوص على الفيديو فوراً وبدون مفتاح!',
        'success'
      );
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'تعذر إتمام الترجمة الفورية.',
        'error'
      );
    } finally {
      setIsTranslatingExisting(false);
    }
  };

  // Continuous Multi-Utterance Live Speech Dictation (Auto-restarts seamlessly across pauses!)
  const toggleLiveSpeechDictation = () => {
    if (isDictatingLive) {
      keepDictatingRef.current = false;
      speechRecRef.current?.stop();
      setIsDictatingLive(false);
      return;
    }

    const WinSpeech =
      (window as unknown as { SpeechRecognition?: new () => unknown })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => unknown })
        .webkitSpeechRecognition;

    if (!WinSpeech) {
      onNotify(
        'متصفحك الحالي لا يدعم الإملاء الحي المباشر — استخدم زر استخراج الكلام الذكي Whisper أعلاه!',
        'info'
      );
      return;
    }

    const rec = new WinSpeech() as {
      lang: string;
      continuous: boolean;
      interimResults: boolean;
      onresult: (ev: {
        results: ArrayLike<{ 0: { transcript: string }; isFinal: boolean }>;
      }) => void;
      onend: () => void;
      onerror: () => void;
      start: () => void;
      stop: () => void;
    };

    const iso =
      SPOKEN_SOURCE_LANGUAGES.find((l) => l.code === spokenLang)?.iso || 'ar';
    rec.lang = iso === 'ar' ? 'ar-SA' : iso === 'en' ? 'en-US' : iso;
    rec.continuous = true;
    rec.interimResults = false;

    const accumulatedChunks: string[] = [];

    rec.onresult = (ev) => {
      const currentSession: string[] = [];
      for (let i = 0; i < ev.results.length; i++) {
        currentSession.push(ev.results[i][0].transcript);
      }
      const combined = [...accumulatedChunks, ...currentSession].join('. ');
      if (combined.trim()) {
        setManualScript(combined);
        const generated = generateSubtitlesFromScript(
          combined,
          Math.max(2, totalDuration),
          5,
          captionStyleId
        );
        onReplaceAllSubtitles(generated, appendCaptionsMode);
      }
    };

    rec.onend = () => {
      if (keepDictatingRef.current) {
        // Android Chrome stops after each short pause; auto-restart seamlessly so it works unlimited times!
        try {
          rec.start();
        } catch {
          keepDictatingRef.current = false;
          setIsDictatingLive(false);
        }
      } else {
        setIsDictatingLive(false);
      }
    };
    rec.onerror = () => {
      keepDictatingRef.current = false;
      setIsDictatingLive(false);
    };

    keepDictatingRef.current = true;
    speechRecRef.current = rec;
    rec.start();
    setIsDictatingLive(true);
    onNotify('تحدث بحرية وبلا توقف... يتم تحويل كل جملة تلقائياً إلى ترجمة متزامنة!', 'info');
  };

  const currentTabInfo =
    EDITOR_TOOL_TABS.find((t) => t.id === activeTab) || EDITOR_TOOL_TABS[0];

  return (
    <div
      data-testid="tools-studio-panel"
      className="flex flex-col h-full bg-[#15161B] rounded-t-2xl lg:rounded-xl border border-zinc-800/95 shadow-2xl overflow-hidden select-none"
    >
      {/* Hidden File Pickers */}
      <input
        ref={mediaInputRef}
        type="file"
        multiple
        accept="video/*,image/*,audio/*"
        data-testid="editor-media-input"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) {
            onImportFiles(e.target.files, false);
            e.target.value = '';
          }
        }}
      />
      <input
        ref={overlayInputRef}
        type="file"
        multiple
        accept="image/*,video/*"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) {
            onImportFiles(e.target.files, true);
            e.target.value = '';
          }
        }}
      />
      <input
        ref={audioInputRef}
        type="file"
        multiple
        accept="audio/*,video/*"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) {
            onImportFiles(e.target.files, false);
            e.target.value = '';
          }
        }}
      />
      <input
        ref={srtInputRef}
        type="file"
        accept=".srt,.vtt,.txt"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const content = await f.text();
          const parsed = parseSrtContent(content);
          if (parsed.length > 0) {
            onReplaceAllSubtitles(parsed);
            onNotify(`تم استيراد ${parsed.length} جملة ترجمة من ملف SRT!`, 'success');
          } else {
            onNotify('لم يتم العثور على توقيتات SRT صالحة في الملف.', 'error');
          }
          e.target.value = '';
        }}
      />

      {/* CapCut Sheet Header Bar: Active Tool Title on Right | Expand & [ ✓ ] Done Checkmark on Left */}
      <div className="h-11 px-3 bg-[#1B1D24] border-b border-zinc-800 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-2 h-2 rounded-full bg-[#00E5DF] shrink-0" />
          <h2 className="text-xs sm:text-sm font-black text-white truncate">
            {currentTabInfo.label}
          </h2>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {onToggleExpandFull && (
            <button
              type="button"
              onClick={onToggleExpandFull}
              title={
                isExpandedFull
                  ? 'إظهار شاشة الفيديو'
                  : 'توسيع لوحة الأدوات بملء الشاشة'
              }
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-[11px] font-bold text-zinc-200 cursor-pointer"
            >
              {isExpandedFull ? (
                <>
                  <Minimize2 className="w-3.5 h-3.5 text-[#00E5DF]" />
                  <span>عرض الفيديو</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-3.5 h-3.5 text-[#00E5DF]" />
                  <span className="hidden sm:inline">توسيع</span>
                </>
              )}
            </button>
          )}

          {onCloseDrawer && (
            <button
              type="button"
              data-testid="close-tools-drawer-btn"
              title="حفظ وإظهار الخط الزمني"
              onClick={onCloseDrawer}
              className="w-8 h-8 rounded-lg bg-[#00E5DF] hover:brightness-110 text-zinc-950 flex items-center justify-center shadow cursor-pointer"
            >
              <Check className="w-4 h-4 stroke-[3]" />
            </button>
          )}
        </div>
      </div>

      {/* Authentic CapCut Icon Strip across all 12 tools (Clean 6×2 on narrow mobile or sleek horizontal bar) */}
      <nav className="grid grid-cols-6 gap-1 p-1.5 bg-[#101116] border-b border-zinc-800/90 shrink-0">
        {EDITOR_TOOL_TABS.map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              data-testid={`tab-${tab.id}`}
              onClick={() => onChangeTab(tab.id)}
              className={`flex flex-col items-center justify-center gap-0.5 py-1.5 px-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                active
                  ? 'bg-[#00E5DF]/15 text-[#00E5DF] border border-[#00E5DF]/50'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/70 border border-transparent'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="truncate max-w-full">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Active Tool Body */}
      <div className="flex-1 overflow-y-auto p-3.5 space-y-4">
        {/* ================= 1. EDIT CLIP TAB (CapCut Sub-Toolbar Style) ================= */}
        {activeTab === 'edit' && (
          <div className="space-y-4">
            {!activeClipForEdit ? (
              <div className="text-center py-6 space-y-3">
                <p className="text-xs text-zinc-400">
                  لا يوجد مقطع على الخط الزمني بعد
                </p>
                <button
                  type="button"
                  onClick={() => mediaInputRef.current?.click()}
                  className="px-4 py-2.5 rounded-xl bg-[#00E5DF] text-zinc-950 font-black text-xs cursor-pointer"
                >
                  + استيراد فيديو أو صورة
                </button>
              </div>
            ) : (
              <>
                {/* CapCut Signature Quick Action Buttons Grid */}
                <div className="grid grid-cols-5 gap-1.5">
                  <button
                    type="button"
                    onClick={onSplitAtPlayhead}
                    className="flex flex-col items-center gap-1 py-2.5 px-1 rounded-xl bg-[#1E2028] hover:bg-zinc-800 text-[10px] font-bold text-white cursor-pointer"
                  >
                    <Scissors className="w-4 h-4 text-[#00E5DF]" />
                    <span>تقسيم</span>
                  </button>

                  <button
                    type="button"
                    onClick={onFreezeFrameAtPlayhead}
                    className="flex flex-col items-center gap-1 py-2.5 px-1 rounded-xl bg-[#1E2028] hover:bg-zinc-800 text-[10px] font-bold text-white cursor-pointer"
                  >
                    <Snowflake className="w-4 h-4 text-sky-400" />
                    <span>تجميد</span>
                  </button>

                  {activeClipForEdit.type === 'video' && (
                    <button
                      type="button"
                      onClick={() => onExtractClipAudio(activeClipForEdit)}
                      className="flex flex-col items-center gap-1 py-2.5 px-1 rounded-xl bg-[#1E2028] hover:bg-zinc-800 text-[10px] font-bold text-white cursor-pointer"
                    >
                      <FileAudio className="w-4 h-4 text-emerald-400" />
                      <span>فصل الصوت</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() =>
                      onUpdateClip(activeClipForEdit.id, {
                        flipH: !activeClipForEdit.flipH,
                      })
                    }
                    className={`flex flex-col items-center gap-1 py-2.5 px-1 rounded-xl text-[10px] font-bold cursor-pointer ${
                      activeClipForEdit.flipH
                        ? 'bg-[#00E5DF]/20 text-[#00E5DF] border border-[#00E5DF]/40'
                        : 'bg-[#1E2028] hover:bg-zinc-800 text-white'
                    }`}
                  >
                    <FlipHorizontal className="w-4 h-4" />
                    <span>عكس مرآة</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      onUpdateClip(activeClipForEdit.id, {
                        rotation: ((activeClipForEdit.rotation + 90) % 360) as
                          | 0
                          | 90
                          | 180
                          | 270,
                      })
                    }
                    className="flex flex-col items-center gap-1 py-2.5 px-1 rounded-xl bg-[#1E2028] hover:bg-zinc-800 text-[10px] font-bold text-white cursor-pointer"
                  >
                    <RotateCw className="w-4 h-4 text-amber-300" />
                    <span>تدوير {activeClipForEdit.rotation}°</span>
                  </button>
                </div>

                {/* Clip Selector Chips when >1 clip */}
                {clips.length > 1 && (
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    {clips.map((c, idx) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => onSelectClip(c.id)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold shrink-0 cursor-pointer ${
                          activeClipForEdit.id === c.id
                            ? 'bg-[#00E5DF] text-zinc-950'
                            : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                        }`}
                      >
                        مقطع {idx + 1}: {c.name.slice(0, 14)}
                      </button>
                    ))}
                  </div>
                )}

                {/* Speed Control (CapCut Curve/Normal Speed presets) */}
                {activeClipForEdit.type === 'video' && (
                  <div className="space-y-2 bg-[#1B1D24] p-3 rounded-xl border border-zinc-800">
                    <div className="flex justify-between text-xs">
                      <span className="text-zinc-200 font-bold">
                        السرعة (Speed)
                      </span>
                      <span className="font-mono text-[#00E5DF]">
                        {activeClipForEdit.speed}x
                      </span>
                    </div>
                    <div className="grid grid-cols-6 gap-1">
                      {[0.25, 0.5, 1, 1.5, 2, 3].map((sp) => (
                        <button
                          key={sp}
                          type="button"
                          onClick={() => {
                            const maxDur =
                              (activeClipForEdit.sourceDuration -
                                activeClipForEdit.trimStart) /
                              sp;
                            onUpdateClip(activeClipForEdit.id, {
                              speed: sp,
                              duration: Math.max(0.3, Number(maxDur.toFixed(2))),
                            });
                          }}
                          className={`py-1.5 rounded-lg text-[11px] font-bold cursor-pointer ${
                            activeClipForEdit.speed === sp
                              ? 'bg-[#00E5DF] text-zinc-950'
                              : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800'
                          }`}
                        >
                          {sp}x
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Volume & Mute Original Audio */}
                {activeClipForEdit.type === 'video' && (
                  <div className="space-y-2 bg-[#1B1D24] p-3 rounded-xl border border-zinc-800">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-zinc-200">
                        مستوى صوت المقطع ({activeClipForEdit.volume}%)
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateClip(activeClipForEdit.id, {
                            muted: !activeClipForEdit.muted,
                          })
                        }
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                          activeClipForEdit.muted
                            ? 'bg-rose-500/20 text-rose-300'
                            : 'bg-zinc-800 text-emerald-300'
                        }`}
                      >
                        {activeClipForEdit.muted ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5" />
                            <span>مكتوم</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>مفعل</span>
                          </>
                        )}
                      </button>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={200}
                      step={5}
                      value={activeClipForEdit.volume}
                      onChange={(e) =>
                        onUpdateClip(activeClipForEdit.id, {
                          volume: parseInt(e.target.value, 10),
                          muted: false,
                        })
                      }
                      className="w-full laqta-slider"
                    />
                  </div>
                )}

                {/* Exact Duration & Trim */}
                <div className="space-y-2 bg-[#1B1D24] p-3 rounded-xl border border-zinc-800">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-200 font-bold">مدة المقطع</span>
                    <span className="font-mono text-[#00E5DF]">
                      {activeClipForEdit.duration.toFixed(2)}s
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.4}
                    max={
                      activeClipForEdit.type === 'image'
                        ? 15
                        : Math.max(
                            0.5,
                            (activeClipForEdit.sourceDuration -
                              activeClipForEdit.trimStart) /
                              (activeClipForEdit.speed || 1)
                          )
                    }
                    step={0.05}
                    value={activeClipForEdit.duration}
                    onChange={(e) =>
                      onUpdateClip(activeClipForEdit.id, {
                        duration: parseFloat(e.target.value),
                      })
                    }
                    className="w-full laqta-slider"
                  />
                </div>
              </>
            )}
          </div>
        )}

        {/* ================= 1.2 DEDICATED HOLY QURAN VIDEO STUDIO TAB ================= */}
        {activeTab === 'quran' && (
          <QuranStudioPanel
            hasExistingClips={clips.length > 0}
            isBusy={isBusy}
            onGenerateQuranVideo={onGenerateQuranInEditor}
          />
        )}

        {/* ================= 1.5 READY CAPCUT & QURAN TEMPLATES STUDIO TAB (30 قالب جاهز) ================= */}
        {activeTab === 'templates' && (
          <div className="space-y-3.5">
            <div className="rounded-xl bg-[#1B1D24] border border-[#00E5DF]/35 p-2.5 text-xs text-zinc-200 flex items-center justify-between gap-2">
              <span>
                اختر أي قالب قرآني أو سينمائي لتطبيقه فوراً على مشروعك الحالي بنقرة واحدة!
              </span>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#00E5DF]/20 text-[#00E5DF] shrink-0">
                {CAPCUT_READY_TEMPLATES.length} قالب
              </span>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
              {TEMPLATE_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setEditorTemplateCat(cat.id)}
                  className={`px-3 py-1 rounded-full text-[11px] font-bold shrink-0 transition cursor-pointer ${
                    editorTemplateCat === cat.id
                      ? 'bg-[#00E5DF] text-zinc-950 font-black'
                      : 'bg-[#1B1D24] text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
              {CAPCUT_READY_TEMPLATES.filter(
                (t) =>
                  editorTemplateCat === 'all' ||
                  t.category === editorTemplateCat
              ).map((tpl) => (
                <div
                  key={tpl.id}
                  data-testid={`editor-template-${tpl.id}`}
                  className={`rounded-2xl bg-gradient-to-br ${tpl.gradient} border border-zinc-800 hover:border-[#00E5DF]/65 p-3 flex items-center justify-between gap-3 transition`}
                >
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9px] font-black px-2 py-0.2 rounded-full bg-black/65 text-[#00E5DF]">
                        {tpl.badge}
                      </span>
                      <span className="text-[9px] font-mono text-zinc-300">
                        {tpl.aspect}
                      </span>
                    </div>
                    <h4 className="text-xs font-black text-white truncate">
                      {tpl.title}
                    </h4>
                    <p className="text-[10px] text-zinc-300 line-clamp-1">
                      {tpl.subtitle}
                    </p>
                  </div>

                  {tpl.quranPreset ? (
                    <div className="flex flex-col sm:flex-row items-stretch gap-1 shrink-0">
                      <button
                        type="button"
                        data-testid={`apply-editor-template-${tpl.id}`}
                        onClick={() => onApplyTemplateToProject(tpl.id, '9:16')}
                        className="px-2.5 py-1.5 rounded-lg bg-amber-400 hover:brightness-110 text-zinc-950 font-black text-[10px] transition cursor-pointer"
                      >
                        📱 ريلز 9:16
                      </button>
                      <button
                        type="button"
                        onClick={() => onApplyTemplateToProject(tpl.id, '16:9')}
                        className="px-2.5 py-1.5 rounded-lg bg-[#00E5DF] hover:brightness-110 text-zinc-950 font-black text-[10px] transition cursor-pointer"
                      >
                        📺 طويل 16:9
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      data-testid={`apply-editor-template-${tpl.id}`}
                      onClick={() => onApplyTemplateToProject(tpl.id)}
                      className="px-3 py-2 rounded-xl bg-[#00E5DF] hover:brightness-110 text-zinc-950 font-black text-[11px] shrink-0 transition cursor-pointer"
                    >
                      تطبيق القالب
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= 2. AUDIO & VOICEOVER TAB ================= */}
        {activeTab === 'audio' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => audioInputRef.current?.click()}
                className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-[#00E5DF] text-zinc-950 font-black text-xs hover:brightness-110 transition cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>الأصوات من الجهاز</span>
              </button>

              <button
                type="button"
                onClick={toggleVoiceRecording}
                className={`flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl font-black text-xs transition cursor-pointer ${
                  isRecordingVoice
                    ? 'bg-rose-500 text-white animate-pulse'
                    : 'bg-[#1E2028] hover:bg-zinc-800 text-rose-300 border border-zinc-700'
                }`}
              >
                {isRecordingVoice ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span>إيقاف التسجيل</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    <span>تسجيل صوتي (Voiceover)</span>
                  </>
                )}
              </button>
            </div>

            {selectedAudio && (
              <div className="bg-[#1B1D24] p-3 rounded-2xl border border-[#00E5DF]/40 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#00E5DF] truncate">
                    🎵 {selectedAudio.name}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateAudio(selectedAudio.id, {
                          muted: !selectedAudio.muted,
                        })
                      }
                      className="px-2 py-1 rounded-lg bg-zinc-800 text-[11px] font-bold text-white cursor-pointer"
                    >
                      {selectedAudio.muted ? 'تشغيل' : 'كتم'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteAudioById(selectedAudio.id)}
                      className="p-1.5 rounded-lg bg-rose-500/20 text-rose-300 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-zinc-300">مستوى الصوت</span>
                    <span className="font-mono text-[#00E5DF]">
                      {selectedAudio.volume}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={200}
                    step={5}
                    value={selectedAudio.volume}
                    onChange={(e) =>
                      onUpdateAudio(selectedAudio.id, {
                        volume: parseInt(e.target.value, 10),
                        muted: false,
                      })
                    }
                    className="w-full laqta-slider"
                  />
                </div>
              </div>
            )}

            {audioClips.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {audioClips.map((ac, i) => (
                  <button
                    key={ac.id}
                    type="button"
                    onClick={() => onSelectAudio(ac.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                      selectedAudio?.id === ac.id
                        ? 'bg-[#00E5DF] text-zinc-950'
                        : 'bg-[#1B1D24] border border-zinc-800 text-zinc-300'
                    }`}
                  >
                    {i + 1}. 🎵 {ac.name}
                  </button>
                ))}
              </div>
            )}

            <div className="space-y-2">
              <span className="text-xs font-bold text-zinc-300 block">
                مكتبة موسيقى ومؤثرات CapCut الصوتية (تُضاف عند {currentTime.toFixed(1)}ث):
              </span>
              <div className="space-y-1.5">
                {BUILT_IN_SOUNDS.map((sound) => (
                  <div
                    key={sound.id}
                    className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-[#1B1D24] border border-zinc-800 hover:border-[#00E5DF]/40 transition"
                  >
                    <div>
                      <div className="text-xs font-bold text-white">
                        {sound.nameAr}
                      </div>
                      <div className="text-[10px] text-zinc-400">
                        {sound.desc} • {sound.duration}ث
                      </div>
                    </div>
                    <button
                      type="button"
                      data-testid={`add-sound-${sound.id}`}
                      onClick={() => onAddBuiltInSound(sound.id)}
                      className="px-3 py-1.5 rounded-lg bg-[#00E5DF] hover:brightness-110 text-zinc-950 text-xs font-black transition shrink-0 cursor-pointer"
                    >
                      استخدام
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= 3. TEXT & TEMPLATES TAB ================= */}
        {activeTab === 'text' && (
          <div className="space-y-4">
            <button
              type="button"
              data-testid="add-text-btn"
              onClick={() => onAddText('bold-words')}
              className="w-full py-3 rounded-xl bg-[#00E5DF] text-zinc-950 font-black text-xs inline-flex items-center justify-center gap-2 shadow-md hover:brightness-110 transition cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>إضافة نص جديد +</span>
            </button>

            {texts.length > 0 && (
              <div className="space-y-1.5 bg-[#1B1D24] p-2.5 rounded-xl border border-zinc-800">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-[#00E5DF]">
                    النصوص المضافة ({texts.length}):
                  </span>
                  {selectedText && (
                    <button
                      type="button"
                      onClick={() => onSelectText(null)}
                      className="text-amber-300 hover:underline font-bold cursor-pointer"
                    >
                      + إلغاء التحديد لإضافة نص جديد
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                  {texts.map((t, idx) => (
                    <div
                      key={t.id}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs border transition ${
                        selectedText?.id === t.id
                          ? 'bg-[#00E5DF]/20 border-[#00E5DF] text-white font-bold'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-300'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          onSelectText(t.id);
                          onSeek(t.startTime + 0.05);
                        }}
                        className="truncate max-w-[130px] cursor-pointer"
                      >
                        {idx + 1}. {t.text}
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteTextById(t.id)}
                        className="text-zinc-400 hover:text-rose-400 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <span className="text-xs font-bold text-zinc-300 block">
                قوالب أنماط CapCut النصية:
              </span>
              <div className="grid grid-cols-2 gap-2">
                {TEXT_STYLE_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    data-testid={`text-preset-${preset.id}`}
                    onClick={() => {
                      if (selectedText) {
                        onUpdateText(selectedText.id, {
                          ...preset.style,
                          presetId: preset.id,
                          wordTimings: buildWordTimingsForPhrase(
                            selectedText.text,
                            selectedText.duration
                          ),
                        });
                      } else {
                        onAddText(preset.id);
                      }
                    }}
                    className={`px-3 py-2.5 rounded-xl text-xs transition cursor-pointer text-center ${preset.previewClasses}`}
                  >
                    {preset.nameAr}
                  </button>
                ))}
              </div>
            </div>

            {selectedText && (
              <div className="space-y-3 bg-[#1B1D24] p-3.5 rounded-2xl border border-zinc-800">
                <textarea
                  rows={2}
                  data-testid="text-content-input"
                  value={selectedText.text}
                  onChange={(e) => {
                    const val = e.target.value;
                    onUpdateText(selectedText.id, {
                      text: val,
                      wordTimings: buildWordTimingsForPhrase(
                        val,
                        selectedText.duration
                      ),
                    });
                  }}
                  placeholder="اكتب النص بالعربية أو الإنجليزية..."
                  className="w-full rounded-xl bg-black border border-zinc-700 focus:border-[#00E5DF] px-3 py-2 text-sm text-white outline-none"
                />

                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={selectedText.fontFamily}
                    onChange={(e) =>
                      onUpdateText(selectedText.id, {
                        fontFamily: e.target.value,
                      })
                    }
                    className="w-full rounded-lg bg-black border border-zinc-700 px-2.5 py-2 text-xs text-white"
                  >
                    {ARABIC_FONTS.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.label}
                      </option>
                    ))}
                  </select>

                  <select
                    value={selectedText.animation}
                    onChange={(e) =>
                      onUpdateText(selectedText.id, {
                        animation: e.target.value as TextOverlay['animation'],
                      })
                    }
                    className="w-full rounded-lg bg-black border border-zinc-700 px-2.5 py-2 text-xs text-white"
                  >
                    {TEXT_ANIMATIONS.map((an) => (
                      <option key={an.id} value={an.id}>
                        {an.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center">
                  <label className="bg-black p-1.5 rounded-lg border border-zinc-800 cursor-pointer">
                    <span className="text-[10px] text-zinc-400 block mb-1">
                      النص
                    </span>
                    <input
                      type="color"
                      value={selectedText.color}
                      onChange={(e) =>
                        onUpdateText(selectedText.id, { color: e.target.value })
                      }
                      className="w-full h-5 rounded cursor-pointer bg-transparent"
                    />
                  </label>
                  <label className="bg-black p-1.5 rounded-lg border border-zinc-800 cursor-pointer">
                    <span className="text-[10px] text-zinc-400 block mb-1">
                      الحدود
                    </span>
                    <input
                      type="color"
                      value={selectedText.strokeColor}
                      onChange={(e) =>
                        onUpdateText(selectedText.id, {
                          strokeColor: e.target.value,
                        })
                      }
                      className="w-full h-5 rounded cursor-pointer bg-transparent"
                    />
                  </label>
                  <label className="bg-black p-1.5 rounded-lg border border-zinc-800 cursor-pointer">
                    <span className="text-[10px] text-zinc-400 block mb-1">
                      التوهج
                    </span>
                    <input
                      type="color"
                      value={selectedText.shadowColor}
                      onChange={(e) =>
                        onUpdateText(selectedText.id, {
                          shadowColor: e.target.value,
                        })
                      }
                      className="w-full h-5 rounded cursor-pointer bg-transparent"
                    />
                  </label>
                  <label className="bg-black p-1.5 rounded-lg border border-zinc-800 cursor-pointer">
                    <span className="text-[10px] text-zinc-400 block mb-1">
                      الخلفية
                    </span>
                    <input
                      type="color"
                      value={selectedText.bgColor}
                      onChange={(e) =>
                        onUpdateText(selectedText.id, {
                          bgColor: e.target.value,
                        })
                      }
                      className="w-full h-5 rounded cursor-pointer bg-transparent"
                    />
                  </label>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-zinc-300">حجم الخط</span>
                    <span className="font-mono text-[#00E5DF]">
                      {selectedText.fontSize}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={20}
                    max={120}
                    value={selectedText.fontSize}
                    onChange={(e) =>
                      onUpdateText(selectedText.id, {
                        fontSize: parseInt(e.target.value, 10),
                      })
                    }
                    className="w-full laqta-slider"
                  />
                </div>

                <div className="flex items-center justify-between gap-2 pt-1">
                  <div className="flex items-center gap-1 bg-black p-1 rounded-lg border border-zinc-800">
                    {(
                      [
                        { id: 'right', icon: AlignRight },
                        { id: 'center', icon: AlignCenter },
                        { id: 'left', icon: AlignLeft },
                      ] as const
                    ).map((al) => {
                      const AlIcon = al.icon;
                      return (
                        <button
                          key={al.id}
                          type="button"
                          onClick={() =>
                            onUpdateText(selectedText.id, { align: al.id })
                          }
                          className={`p-1.5 rounded cursor-pointer ${
                            selectedText.align === al.id
                              ? 'bg-[#00E5DF] text-zinc-950'
                              : 'text-zinc-400 hover:text-white'
                          }`}
                        >
                          <AlIcon className="w-3.5 h-3.5" />
                        </button>
                      );
                    })}
                  </div>

                  <label className="inline-flex items-center gap-1.5 text-xs font-bold text-[#00E5DF] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={Boolean(selectedText.highlightWords)}
                      onChange={(e) =>
                        onUpdateText(selectedText.id, {
                          highlightWords: e.target.checked,
                          wordTimings: buildWordTimingsForPhrase(
                            selectedText.text,
                            selectedText.duration
                          ),
                        })
                      }
                      className="accent-[#00E5DF] w-4 h-4"
                    />
                    <span>تلوين الكلمات مع النطق</span>
                  </label>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= 4. KEYLESS CAPCUT AUTO CAPTIONS & TRANSLATION TAB ================= */}
        {activeTab === 'captions' && (
          <div className="space-y-4">
            {/* Primary CapCut Auto Captions Card — ZERO API KEY REQUIRED! */}
            <div className="rounded-2xl bg-gradient-to-br from-[#192229] via-[#171922] to-[#14161D] border border-[#00E5DF]/40 p-3.5 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#00E5DF] shrink-0" />
                  <span className="text-xs sm:text-sm font-black text-white">
                    الترجمة التلقائية بالذكاء الاصطناعي (غير محدودة ومجانية!)
                  </span>
                </div>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shrink-0">
                  بلا حدود ∞ {captionRunCount > 0 ? `(${captionRunCount})` : ''}
                </span>
              </div>

              <p className="text-[11px] text-zinc-300 leading-relaxed">
                استخرج الكلام وترجمه{' '}
                <strong className="text-[#00E5DF]">
                  بعدد غير محدود من المرات وعلى جميع الفيديوهات والمقاطع
                </strong>{' '}
                مجاناً بالكامل وبدون أي مفتاح API أو حد للاستخدام.
              </p>

              {/* Scope & Multi-Run Mode Controls */}
              <div className="grid grid-cols-2 gap-2">
                <select
                  data-testid="caption-scope-select"
                  value={captionScope}
                  onChange={(e) =>
                    setCaptionScope(e.target.value as 'all' | 'clip')
                  }
                  className="rounded-xl bg-black border border-zinc-700 px-2.5 py-1.5 text-[11px] font-bold text-zinc-200"
                >
                  <option value="all">النطاق: كامل الفيديو (كل المقاطع)</option>
                  <option value="clip">النطاق: المقطع المحدد فقط</option>
                </select>

                <select
                  data-testid="caption-mode-select"
                  value={appendCaptionsMode ? 'append' : 'replace'}
                  onChange={(e) =>
                    setAppendCaptionsMode(e.target.value === 'append')
                  }
                  className="rounded-xl bg-black border border-zinc-700 px-2.5 py-1.5 text-[11px] font-bold text-zinc-200"
                >
                  <option value="replace">الوضع: استبدال وتحديث الترجمة</option>
                  <option value="append">الوضع: إضافة فوق الترجمات الحالية +</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <label className="space-y-1 block">
                  <span className="text-[10px] font-bold text-zinc-400">
                    لغة الصوت المنطوق في الفيديو
                  </span>
                  <select
                    value={spokenLang}
                    onChange={(e) => setSpokenLang(e.target.value)}
                    className="w-full rounded-xl bg-black border border-zinc-700 px-2.5 py-2 text-xs text-white"
                  >
                    {SPOKEN_SOURCE_LANGUAGES.map((l) => (
                      <option key={l.code} value={l.code}>
                        {l.label}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="space-y-1 block">
                  <span className="text-[10px] font-bold text-zinc-400">
                    ترجمة تلقائية إلى لغة أخرى
                  </span>
                  <select
                    value={targetLang}
                    onChange={(e) => setTargetLang(e.target.value)}
                    className="w-full rounded-xl bg-black border border-zinc-700 px-2.5 py-2 text-xs text-white"
                  >
                    {SUPPORTED_TRANSLATION_LANGUAGES.map((l) => (
                      <option key={l.code} value={l.code}>
                        {l.label}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              {/* CapCut Pro Bilingual Captions Option */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={bilingualMode}
                    onChange={(e) => setBilingualMode(e.target.checked)}
                    className="accent-[#00E5DF] w-4 h-4"
                  />
                  <span className="text-xs font-bold text-zinc-200">
                    ترجمة مزدوجة (عرض اللغتين معاً مثل CapCut Pro)
                  </span>
                </label>

                <select
                  value={captionStyleId}
                  onChange={(e) =>
                    setCaptionStyleId(e.target.value as TextStylePresetId)
                  }
                  className="rounded-lg bg-black border border-zinc-700 px-2 py-1 text-[11px] font-bold text-[#00E5DF]"
                >
                  {TEXT_STYLE_PRESETS.map((p) => (
                    <option key={p.id} value={p.id}>
                      نمط: {p.nameAr}
                    </option>
                  ))}
                </select>
              </div>

              {isRunningAi && (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] font-bold text-[#00E5DF]">
                    <span>{aiStatusMsg}</span>
                    <span>{aiProgressPct}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-black overflow-hidden">
                    <div
                      style={{ width: `${aiProgressPct}%` }}
                      className="h-full bg-[#00E5DF] transition-all duration-200"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  data-testid="run-keyless-whisper-btn"
                  disabled={isRunningAi}
                  onClick={handleRunKeylessAutoCaptions}
                  className="sm:col-span-2 py-3 px-4 rounded-xl bg-[#00E5DF] hover:brightness-110 text-zinc-950 font-black text-xs shadow-lg transition cursor-pointer disabled:opacity-50"
                >
                  {isRunningAi
                    ? 'جاري استخراج الكلام...'
                    : 'إنشاء الترجمة التلقائية الآن ✨'}
                </button>

                <button
                  type="button"
                  onClick={toggleLiveSpeechDictation}
                  className={`py-3 px-3 rounded-xl font-bold text-xs inline-flex items-center justify-center gap-1.5 border transition cursor-pointer ${
                    isDictatingLive
                      ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
                      : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border-zinc-700'
                  }`}
                >
                  <Mic className="w-3.5 h-3.5 text-[#00E5DF]" />
                  <span>{isDictatingLive ? 'إيقاف الإملاء' : 'إملاء صوتي حي'}</span>
                </button>
              </div>
            </div>

            {/* 2. Instant One-Click Zero-Key Translation for ANY Existing Captions / Texts on Timeline! */}
            <div className="rounded-2xl bg-[#1B1D24] border border-zinc-800 p-3 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-extrabold text-white">
                <Languages className="w-4 h-4 text-[#00E5DF]" />
                <span>ترجمة فورية للنصوص والترجمات الحالية (بدون مفتاح!)</span>
              </div>
              <div className="flex gap-2">
                <select
                  data-testid="instant-translate-lang-select"
                  value={quickTranslateLang}
                  onChange={(e) => setQuickTranslateLang(e.target.value)}
                  className="flex-1 rounded-xl bg-black border border-zinc-700 px-2.5 py-2 text-xs text-white"
                >
                  {SUPPORTED_TRANSLATION_LANGUAGES.filter(
                    (l) => l.code !== 'none'
                  ).map((l) => (
                    <option key={l.code} value={l.code}>
                      ترجمة إلى: {l.label}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  data-testid="instant-translate-btn"
                  disabled={isTranslatingExisting || texts.length === 0}
                  onClick={handleInstantTranslateExisting}
                  className="px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-black text-xs transition cursor-pointer disabled:opacity-40"
                >
                  {isTranslatingExisting ? 'جاري الترجمة...' : 'ترجم الآن'}
                </button>
              </div>
            </div>

            {/* 3. Offline Instant Script-to-Synced-Captions + SRT Import/Export */}
            <div className="rounded-2xl bg-[#1B1D24] border border-zinc-800 p-3 space-y-2.5">
              <span className="text-xs font-bold text-zinc-300 block">
                تحويل نص مكتوب إلى كاريوكي متزامن أو ملفات SRT (يعمل بدون إنترنت):
              </span>
              <textarea
                rows={2}
                value={manualScript}
                onChange={(e) => setManualScript(e.target.value)}
                className="w-full rounded-xl bg-black border border-zinc-700 p-2.5 text-xs text-white outline-none"
              />
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  data-testid="generate-local-captions-btn"
                  onClick={() => {
                    const generated = generateSubtitlesFromScript(
                      manualScript,
                      Math.max(2, totalDuration),
                      5,
                      captionStyleId
                    );
                    if (generated.length > 0) {
                      onReplaceAllSubtitles(generated);
                      onNotify(
                        `تم توزيع ومزامنة ${generated.length} جملة مع تلوين الكلمات!`,
                        'success'
                      );
                    }
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-[#00E5DF] border border-zinc-700 text-xs font-bold cursor-pointer"
                >
                  توليد ومزامنة الكلمات فوراً
                </button>

                <button
                  type="button"
                  onClick={() => srtInputRef.current?.click()}
                  className="py-2 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-semibold text-zinc-200 cursor-pointer"
                >
                  استيراد SRT
                </button>

                {texts.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      const srt = exportSubtitlesToSrt(texts);
                      const blob = new Blob([srt], {
                        type: 'text/plain;charset=utf-8',
                      });
                      const a = document.createElement('a');
                      a.href = URL.createObjectURL(blob);
                      a.download = 'laqta-captions.srt';
                      a.click();
                    }}
                    className="inline-flex items-center gap-1 py-2 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-semibold text-[#00E5DF] cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>SRT</span>
                  </button>
                )}
              </div>
            </div>

            {/* Editable Captions List */}
            {texts.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-zinc-300 block">
                  تحرير جمل الترجمة يدوياً ({texts.length}):
                </span>
                {texts.map((sub) => (
                  <div
                    key={sub.id}
                    onClick={() => {
                      onSelectText(sub.id);
                      onSeek(sub.startTime + 0.05);
                    }}
                    className="p-2 rounded-xl bg-[#1B1D24] border border-zinc-800 hover:border-[#00E5DF]/50 space-y-1 cursor-pointer"
                  >
                    <div className="flex justify-between text-[10px] font-mono text-[#00E5DF]">
                      <span>
                        {sub.startTime.toFixed(1)}s →{' '}
                        {(sub.startTime + sub.duration).toFixed(1)}s
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteTextById(sub.id);
                        }}
                        className="text-zinc-500 hover:text-rose-400 cursor-pointer"
                      >
                        حذف
                      </button>
                    </div>
                    <textarea
                      rows={sub.text.includes('\n') ? 2 : 1}
                      value={sub.text}
                      onChange={(e) =>
                        onUpdateText(sub.id, {
                          text: e.target.value,
                          wordTimings: buildWordTimingsForPhrase(
                            e.target.value,
                            sub.duration
                          ),
                        })
                      }
                      className="w-full bg-black border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white resize-none"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= 5. CAPCUT & ISLAMIC INTERACTIVE STICKERS TAB (64 ملصق وشارة) ================= */}
        {activeTab === 'stickers' && (
          <div className="space-y-3.5">
            {/* Sticker Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
              {STICKER_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setStickerCat(cat.id)}
                  className={`px-3 py-1 rounded-full text-[11px] font-bold shrink-0 transition cursor-pointer ${
                    stickerCat === cat.id
                      ? 'bg-[#00E5DF] text-zinc-950 font-black'
                      : 'bg-[#1B1D24] text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Calligraphic Islamic & Social Badge Stickers */}
            {(stickerCat === 'all' ||
              stickerCat === 'islamic' ||
              stickerCat === 'social') && (
              <div className="space-y-2">
                <span className="text-xs font-bold text-zinc-200 block">
                  شارات قرآنية وإسلامية وتفاعلية متحركة (اسحبها لأي مكان على الفيديو):
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {CAPCUT_STICKER_ITEMS.filter(
                    (s) =>
                      (s.category === 'islamic' || s.category === 'social') &&
                      (stickerCat === 'all' || s.category === stickerCat)
                  ).map((st) => (
                    <button
                      key={st.id}
                      type="button"
                      data-testid={`sticker-${st.id}`}
                      onClick={() => onAddSticker(st)}
                      style={{
                        backgroundColor: st.bgColor || '#1B1D24',
                        color: st.color || '#FFFFFF',
                        fontFamily: st.fontFamily || 'Cairo',
                      }}
                      className="py-2.5 px-3 rounded-xl font-black text-xs border border-white/10 shadow hover:scale-[1.02] transition cursor-pointer truncate"
                    >
                      {st.text}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Expressive Spiritual Emojis & Markers */}
            {(stickerCat === 'all' ||
              stickerCat === 'emoji' ||
              stickerCat === 'markers') && (
              <div className="space-y-2">
                <span className="text-xs font-bold text-zinc-200 block">
                  رموز روحانية وإيموجي وأسهم متحركة:
                </span>
                <div className="grid grid-cols-4 sm:grid-cols-8 lg:grid-cols-6 gap-2">
                  {CAPCUT_STICKER_ITEMS.filter(
                    (s) =>
                      (s.category === 'emoji' || s.category === 'markers') &&
                      (stickerCat === 'all' || s.category === stickerCat)
                  ).map((st) => (
                    <button
                      key={st.id}
                      type="button"
                      data-testid={`sticker-${st.id}`}
                      onClick={() => onAddSticker(st)}
                      className="py-2.5 rounded-xl bg-[#1B1D24] hover:bg-zinc-800 border border-zinc-800 text-2xl transition cursor-pointer"
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= 6. CAPCUT PICTURE-IN-PICTURE OVERLAY (PIP) TAB ================= */}
        {activeTab === 'overlay' && (
          <div className="space-y-4">
            <button
              type="button"
              onClick={() => overlayInputRef.current?.click()}
              className="w-full py-3 rounded-xl bg-[#00E5DF] text-zinc-950 font-black text-xs inline-flex items-center justify-center gap-2 shadow hover:brightness-110 transition cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>+ إضافة تراكب جديد (صورة / شعار / فيديو PIP)</span>
            </button>

            {assets.filter((a) => a.type !== 'audio').length > 0 && (
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-zinc-300 block">
                  أو أضف من وسائط المشروع كطبقة عائمة فوق الفيديو:
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {assets
                    .filter((a) => a.type !== 'audio')
                    .map((asset) => (
                      <button
                        key={asset.id}
                        type="button"
                        onClick={() => onAddAssetToTimeline(asset, true)}
                        className="rounded-xl bg-[#1B1D24] border border-zinc-800 hover:border-[#00E5DF] overflow-hidden p-1.5 text-center space-y-1 cursor-pointer"
                      >
                        {asset.thumbnailDataUrl && (
                          <img
                            src={asset.thumbnailDataUrl}
                            alt={asset.name}
                            className="h-14 w-full object-cover rounded-lg"
                          />
                        )}
                        <span className="text-[10px] font-bold text-white block truncate">
                          + PIP {asset.name}
                        </span>
                      </button>
                    ))}
                </div>
              </div>
            )}

            {overlays.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {overlays.map((ov, i) => (
                  <button
                    key={ov.id}
                    type="button"
                    onClick={() => onSelectOverlay(ov.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                      selectedOverlay?.id === ov.id
                        ? 'bg-[#00E5DF] text-zinc-950'
                        : 'bg-[#1B1D24] border border-zinc-800 text-zinc-300'
                    }`}
                  >
                    {i + 1}. 🖼️ {ov.name}
                  </button>
                ))}
              </div>
            )}

            {selectedOverlay && (
              <div className="bg-[#1B1D24] p-3.5 rounded-2xl border border-indigo-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-300 truncate">
                    🖼️ خصائص التراكب: {selectedOverlay.name}
                  </span>
                  <button
                    type="button"
                    onClick={() => onDeleteOverlayById(selectedOverlay.id)}
                    className="p-1.5 rounded-lg bg-rose-500/20 text-rose-300 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Mask Shape: Sharp / Rounded / Circle Cam */}
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { label: 'مستطيل حاد', r: 0 },
                    { label: 'حواف ناعمة', r: 22 },
                    { label: 'كاميرا دائرية ⭕', r: 999 },
                  ].map((sh) => (
                    <button
                      key={sh.label}
                      type="button"
                      onClick={() =>
                        onUpdateOverlay(selectedOverlay.id, {
                          borderRadius: sh.r,
                        })
                      }
                      className={`py-1.5 rounded-lg text-[11px] font-bold cursor-pointer ${
                        selectedOverlay.borderRadius === sh.r
                          ? 'bg-[#00E5DF] text-zinc-950'
                          : 'bg-zinc-900 text-zinc-300'
                      }`}
                    >
                      {sh.label}
                    </button>
                  ))}
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-zinc-300">حجم التراكب</span>
                    <span className="font-mono text-[#00E5DF]">
                      {selectedOverlay.scale}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={15}
                    max={90}
                    value={selectedOverlay.scale}
                    onChange={(e) =>
                      onUpdateOverlay(selectedOverlay.id, {
                        scale: parseInt(e.target.value, 10),
                      })
                    }
                    className="w-full laqta-slider"
                  />

                  <div className="flex justify-between pt-1">
                    <span className="text-zinc-300">الشفافية</span>
                    <span className="font-mono text-[#00E5DF]">
                      {selectedOverlay.opacity}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={15}
                    max={100}
                    value={selectedOverlay.opacity}
                    onChange={(e) =>
                      onUpdateOverlay(selectedOverlay.id, {
                        opacity: parseInt(e.target.value, 10),
                      })
                    }
                    className="w-full laqta-slider"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= 7. CAPCUT VIDEO EFFECTS TAB (19 مؤثر بصري حقيقي) ================= */}
        {activeTab === 'effects' && (
          <div className="space-y-3.5">
            {/* Effect Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
              {VIDEO_EFFECT_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setEffectCat(cat.id)}
                  className={`px-3 py-1 rounded-full text-[11px] font-bold shrink-0 transition cursor-pointer ${
                    effectCat === cat.id
                      ? 'bg-[#00E5DF] text-zinc-950 font-black'
                      : 'bg-[#1B1D24] text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 gap-2">
              {VIDEO_EFFECT_PRESETS.filter(
                (fx) => effectCat === 'all' || fx.category === effectCat
              ).map((fx) => (
                <button
                  key={fx.id}
                  type="button"
                  data-testid={`effect-${fx.id}`}
                  onClick={() => onAddVideoEffect(fx.id, fx.nameAr)}
                  className="p-2.5 rounded-xl bg-[#1B1D24] border border-zinc-800 hover:border-purple-400 text-right transition cursor-pointer group"
                >
                  <div
                    className={`h-12 rounded-lg bg-gradient-to-br ${fx.gradient} mb-2 p-2 flex items-end justify-between`}
                  >
                    <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-black/65 text-white">
                      {fx.badge}
                    </span>
                    <Plus className="w-4 h-4 text-white opacity-90 group-hover:scale-125 transition" />
                  </div>
                  <div className="text-xs font-extrabold text-white truncate">
                    {fx.nameAr}
                  </div>
                  <div className="text-[10px] text-zinc-400">
                    {fx.categoryAr}
                  </div>
                </button>
              ))}
            </div>

            {effects.length > 0 && (
              <div className="bg-[#1B1D24] p-3 rounded-2xl border border-purple-500/40 space-y-2.5">
                <span className="text-xs font-bold text-purple-300 block">
                  المؤثرات المطبقة على الفيديو ({effects.length}):
                </span>
                {effects.map((ef) => (
                  <div
                    key={ef.id}
                    onClick={() => onSelectEffect(ef.id)}
                    className={`p-2.5 rounded-xl border space-y-2 cursor-pointer ${
                      selectedEffect?.id === ef.id
                        ? 'bg-purple-950/50 border-purple-400'
                        : 'bg-black border-zinc-800'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">✨ {ef.name}</span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteEffectById(ef.id);
                        }}
                        className="text-zinc-400 hover:text-rose-400 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 text-[11px]">
                      <span className="text-zinc-400">الشدة:</span>
                      <input
                        type="range"
                        min={15}
                        max={100}
                        value={ef.intensity}
                        onChange={(e) =>
                          onUpdateVideoEffect(ef.id, {
                            intensity: parseInt(e.target.value, 10),
                          })
                        }
                        className="flex-1 laqta-slider"
                      />
                      <span className="font-mono text-purple-300">
                        {ef.intensity}%
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px]">
                      <span className="text-zinc-400">المدة:</span>
                      <input
                        type="range"
                        min={0.5}
                        max={Math.max(3, totalDuration || 6)}
                        step={0.1}
                        value={ef.duration}
                        onChange={(e) =>
                          onUpdateVideoEffect(ef.id, {
                            duration: parseFloat(e.target.value),
                          })
                        }
                        className="flex-1 laqta-slider"
                      />
                      <span className="font-mono text-purple-300">
                        {ef.duration.toFixed(1)}s
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= 8. TRANSITIONS TAB (18 انتقال احترافي) ================= */}
        {activeTab === 'transitions' && (
          <div className="space-y-3.5">
            {clips.length < 2 ? (
              <div className="rounded-2xl bg-[#1B1D24] border border-zinc-800 p-4 text-center space-y-2">
                <p className="text-xs font-bold text-amber-200">
                  يتطلب الانتقال وجود مقطعين متتاليين على الأقل
                </p>
                <p className="text-[11px] text-zinc-400">
                  قسّم المقطع الحالي بزر <strong>«تقسيم»</strong> أو أضف مقطعاً
                  ثانياً لتفعيل انتقالات CapCut الـ 18!
                </p>
              </div>
            ) : (
              secondOrSelectedClipForTrans && (
                <>
                  <div className="flex items-center justify-between bg-[#1B1D24] px-3 py-2 rounded-xl border border-zinc-800">
                    <span className="text-xs font-bold text-zinc-200 truncate">
                      الانتقال قبل: {secondOrSelectedClipForTrans.name}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        onPreviewTransition(secondOrSelectedClipForTrans.id)
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#00E5DF]/20 text-[#00E5DF] text-xs font-bold cursor-pointer shrink-0"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>معاينة الانتقال</span>
                    </button>
                  </div>

                  {/* Transition Category Filter Pills */}
                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
                    {TRANSITION_CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setTransCat(cat.id)}
                        className={`px-3 py-1 rounded-full text-[11px] font-bold shrink-0 transition cursor-pointer ${
                          transCat === cat.id
                            ? 'bg-[#00E5DF] text-zinc-950 font-black'
                            : 'bg-[#1B1D24] text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {TRANSITION_PRESETS.filter(
                      (tr) => transCat === 'all' || tr.category === transCat
                    ).map((tr) => {
                      const active =
                        secondOrSelectedClipForTrans.transitionIn.type === tr.id;
                      return (
                        <button
                          key={tr.id}
                          type="button"
                          data-testid={`transition-${tr.id}`}
                          onClick={() => {
                            onUpdateClip(secondOrSelectedClipForTrans.id, {
                              transitionIn: {
                                type: tr.id,
                                duration:
                                  secondOrSelectedClipForTrans.transitionIn
                                    .duration || 0.7,
                              },
                            });
                          }}
                          className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                            active
                              ? 'border-[#00E5DF] bg-[#00E5DF]/15 text-white shadow-md'
                              : 'border-zinc-800 bg-[#1B1D24] text-zinc-300 hover:border-zinc-600'
                          }`}
                        >
                          <div className="text-lg font-black text-[#00E5DF] mb-0.5">
                            {tr.iconSymbol}
                          </div>
                          <div className="text-xs font-bold truncate">
                            {tr.nameAr}
                          </div>
                          <div className="text-[9px] text-zinc-400 truncate mt-0.5">
                            {tr.descAr}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {secondOrSelectedClipForTrans.transitionIn.type !== 'none' && (
                    <div className="bg-[#1B1D24] p-3 rounded-xl border border-zinc-800 space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-zinc-200">
                          مدة الانتقال
                        </span>
                        <span className="font-mono text-[#00E5DF]">
                          {secondOrSelectedClipForTrans.transitionIn.duration.toFixed(
                            1
                          )}
                          s
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0.2}
                        max={2.5}
                        step={0.1}
                        value={
                          secondOrSelectedClipForTrans.transitionIn.duration
                        }
                        onChange={(e) =>
                          onUpdateClip(secondOrSelectedClipForTrans.id, {
                            transitionIn: {
                              ...secondOrSelectedClipForTrans.transitionIn,
                              duration: parseFloat(e.target.value),
                            },
                          })
                        }
                        className="w-full laqta-slider"
                      />
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() =>
                      onApplyTransitionToAll(
                        secondOrSelectedClipForTrans.transitionIn.type,
                        secondOrSelectedClipForTrans.transitionIn.duration
                      )
                    }
                    className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-[#00E5DF] cursor-pointer"
                  >
                    تطبيق الانتقال على جميع المقاطع
                  </button>
                </>
              )
            )}
          </div>
        )}

        {/* ================= 9. FILTERS TAB WITH DEDICATED ICONS (18 فلتر احترافي + أيقونة لكل فلتر) ================= */}
        {activeTab === 'filters' && (
          <div className="space-y-3.5">
            {!activeClipForEdit ? (
              <p className="text-xs text-zinc-400 text-center py-6">
                أضف مقطعاً لتطبيق فلاتر CapCut السينمائية عليه.
              </p>
            ) : (
              <>
                {/* Filter Category Bar */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
                  {FILTER_CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setFilterCat(cat.id)}
                      className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-[11px] font-bold shrink-0 transition cursor-pointer ${
                        filterCat === cat.id
                          ? 'bg-[#00E5DF] text-zinc-950 font-black'
                          : 'bg-[#1B1D24] text-zinc-300 border border-zinc-800 hover:border-zinc-600'
                      }`}
                    >
                      {cat.id === 'all' && (
                        <CapCutFilterToolbarIcon className="w-3 h-3" />
                      )}
                      <span>{cat.label}</span>
                    </button>
                  ))}
                </div>

                {/* 18 Filter Cards — Every card displays its dedicated visual Filter Icon + Swatch! */}
                <div className="grid grid-cols-3 gap-2">
                  {FILTER_PRESETS.filter(
                    (f) => filterCat === 'all' || f.category === filterCat
                  ).map((preset) => {
                    const isSelected =
                      activeClipForEdit.adjustments.filter === preset.id;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        data-testid={`filter-${preset.id}`}
                        onClick={() =>
                          onUpdateClipAdjustments(activeClipForEdit.id, {
                            filter: preset.id,
                          })
                        }
                        className={`p-2 rounded-xl border text-center transition cursor-pointer group ${
                          isSelected
                            ? 'border-[#00E5DF] bg-[#00E5DF]/15 ring-1 ring-[#00E5DF]/50'
                            : 'border-zinc-800 bg-[#1B1D24] hover:border-zinc-600'
                        }`}
                      >
                        <div
                          className={`h-14 rounded-lg bg-gradient-to-br ${preset.previewGradient} mb-1.5 relative flex flex-col items-center justify-between p-1.5 overflow-hidden`}
                        >
                          {/* Dedicated Filter Visual Icon Badge */}
                          <div
                            data-testid={`filter-icon-${preset.id}`}
                            className={`w-7 h-7 rounded-full flex items-center justify-center backdrop-blur-sm transition group-hover:scale-110 ${
                              isSelected
                                ? 'bg-[#00E5DF] text-zinc-950 shadow'
                                : 'bg-black/50 text-white border border-white/20'
                            }`}
                          >
                            <FilterPresetIcon
                              iconKey={preset.iconKey}
                              className="w-3.5 h-3.5"
                            />
                          </div>

                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-black/65 text-white truncate max-w-full">
                            {preset.badge}
                          </span>
                        </div>

                        <div className="flex items-center justify-center gap-1">
                          <FilterPresetIcon
                            iconKey={preset.iconKey}
                            className={`w-3 h-3 shrink-0 ${
                              isSelected ? 'text-[#00E5DF]' : 'text-zinc-400'
                            }`}
                          />
                          <span className="text-xs font-bold text-white truncate">
                            {preset.nameAr}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {activeClipForEdit.adjustments.filter !== 'none' && (
                  <div className="bg-[#1B1D24] p-3 rounded-xl border border-zinc-800 space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-zinc-200 inline-flex items-center gap-1.5">
                        <CapCutFilterToolbarIcon className="w-3.5 h-3.5 text-[#00E5DF]" />
                        <span>شدة الفلتر</span>
                      </span>
                      <span className="font-mono text-[#00E5DF]">
                        {activeClipForEdit.adjustments.filterIntensity}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={activeClipForEdit.adjustments.filterIntensity}
                      onChange={(e) =>
                        onUpdateClipAdjustments(activeClipForEdit.id, {
                          filterIntensity: parseInt(e.target.value, 10),
                        })
                      }
                      className="w-full laqta-slider"
                    />
                  </div>
                )}

                <button
                  type="button"
                  onClick={() =>
                    onApplyAdjustmentsToAll(activeClipForEdit.adjustments)
                  }
                  className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-[#00E5DF] inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCheck className="w-4 h-4" />
                  <span>تطبيق الفلتر على جميع المقاطع</span>
                </button>
              </>
            )}
          </div>
        )}

        {/* ================= 10. COLOR ADJUSTMENTS & SHARPNESS TAB ================= */}
        {activeTab === 'adjust' && (
          <div className="space-y-3">
            {!activeClipForEdit ? (
              <p className="text-xs text-zinc-400 text-center py-6">
                حدد مقطع فيديو أو صورة لضبط الإضاءة والألوان والحدة.
              </p>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-200">
                    ضبط الألوان والحدة (CapCut Adjust)
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateClipAdjustments(activeClipForEdit.id, {
                        ...DEFAULT_ADJUSTMENTS,
                        filter: activeClipForEdit.adjustments.filter,
                        filterIntensity:
                          activeClipForEdit.adjustments.filterIntensity,
                      })
                    }
                    className="inline-flex items-center gap-1 text-[11px] text-zinc-400 hover:text-white cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>إعادة تعيين</span>
                  </button>
                </div>

                {(
                  [
                    { key: 'brightness', label: 'السطوع', min: -100, max: 100 },
                    { key: 'contrast', label: 'التباين', min: -100, max: 100 },
                    { key: 'saturation', label: 'التشبع', min: -100, max: 100 },
                    {
                      key: 'temperature',
                      label: 'درجة الحرارة',
                      min: -100,
                      max: 100,
                    },
                    {
                      key: 'sharpness',
                      label: 'توضيح الحدة (Sharpen)',
                      min: 0,
                      max: 100,
                    },
                  ] as {
                    key: keyof ColorAdjustments;
                    label: string;
                    min: number;
                    max: number;
                  }[]
                ).map((item) => {
                  const val = activeClipForEdit.adjustments[item.key] as number;
                  return (
                    <div
                      key={item.key}
                      className="bg-[#1B1D24] px-3 py-2.5 rounded-xl border border-zinc-800 space-y-1.5"
                    >
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-zinc-200">
                          {item.label}
                        </span>
                        <span className="font-mono text-[#00E5DF]">{val}</span>
                      </div>
                      <input
                        type="range"
                        data-testid={`slider-${item.key}`}
                        min={item.min}
                        max={item.max}
                        value={val}
                        onChange={(e) =>
                          onUpdateClipAdjustments(activeClipForEdit.id, {
                            [item.key]: parseInt(e.target.value, 10),
                          })
                        }
                        className="w-full laqta-slider"
                      />
                    </div>
                  );
                })}
              </>
            )}
          </div>
        )}

        {/* ================= 11. RATIO, FIT & CANVAS BACKGROUND TAB ================= */}
        {activeTab === 'canvas' && (
          <div className="space-y-4">
            <div className="space-y-2">
              <span className="text-xs font-bold text-zinc-200 block">
                نسبة الأبعاد (Format / Ratio):
              </span>
              <div className="grid grid-cols-4 gap-2">
                {ASPECT_RATIO_OPTIONS.map((ar) => (
                  <button
                    key={ar.id}
                    type="button"
                    onClick={() => onChangeAspectRatio(ar.id)}
                    className={`py-2.5 px-2 rounded-xl border text-center cursor-pointer ${
                      aspectRatio === ar.id
                        ? 'border-[#00E5DF] bg-[#00E5DF]/15 text-white font-black'
                        : 'border-zinc-800 bg-[#1B1D24] text-zinc-300'
                    }`}
                  >
                    <div className="text-xs font-bold">{ar.label}</div>
                    <div className="text-[10px] text-zinc-400">{ar.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            {activeClipForEdit && (
              <div className="space-y-2">
                <span className="text-xs font-bold text-zinc-200 block">
                  ملء وضبابية الخلفية:
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'blur-fill', label: 'ضبابية الفيديو (Blur)' },
                      { id: 'cover', label: 'تكبير كامل (Cover)' },
                      { id: 'contain', label: 'لون الخلفية' },
                    ] as { id: FitMode; label: string }[]
                  ).map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() =>
                        onUpdateClip(activeClipForEdit.id, { fitMode: m.id })
                      }
                      className={`py-2 px-2 rounded-xl text-xs font-bold border cursor-pointer ${
                        activeClipForEdit.fitMode === m.id
                          ? 'border-[#00E5DF] bg-[#00E5DF]/15 text-[#00E5DF]'
                          : 'border-zinc-800 bg-[#1B1D24] text-zinc-300'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-2">
              <span className="text-xs font-bold text-zinc-200 block">
                لون الخلفية (Canvas Color):
              </span>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                {CANVAS_BG_SWATCHES.map((sw) => (
                  <button
                    key={sw.id}
                    type="button"
                    onClick={() => onChangeBgColor(sw.color)}
                    className={`p-2 rounded-xl border text-center space-y-1 cursor-pointer ${
                      bgColor.toLowerCase() === sw.color.toLowerCase()
                        ? 'border-[#00E5DF]'
                        : 'border-zinc-800 bg-[#1B1D24]'
                    }`}
                  >
                    <div
                      style={{ backgroundColor: sw.color }}
                      className="h-6 rounded-md border border-zinc-700"
                    />
                    <span className="text-[9px] text-zinc-300 block truncate">
                      {sw.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= 12. MEDIA LIBRARY TAB ================= */}
        {activeTab === 'media' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => mediaInputRef.current?.click()}
                className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#00E5DF] text-zinc-950 font-black text-xs shadow hover:brightness-110 transition cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>+ استيراد فيديو / صور / صوت</span>
              </button>

              <button
                type="button"
                onClick={() => onGenerateSampleClip('neon-city')}
                className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-[#1B1D24] hover:bg-zinc-800 text-amber-200 border border-zinc-800 font-bold text-xs transition cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>+ لقطة MP4 تجريبية</span>
              </button>
            </div>

            {/* Free Built-in Real HD Nature & Mosque Footage Library */}
            <div className="space-y-2">
              <span className="text-xs font-extrabold text-emerald-300 block">
                🏞️ فيديوهات طبيعة ومساجد حقيقية جاهزة (للريلز 9:16 والطويل 16:9):
              </span>
              <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto pr-0.5">
                {REAL_NATURE_STOCK_VIDEOS.map((spec) => (
                  <div
                    key={spec.id}
                    className="rounded-xl bg-[#161922] border border-zinc-800 hover:border-emerald-400/60 overflow-hidden flex flex-col"
                  >
                    <div className="h-20 bg-zinc-900 relative overflow-hidden">
                      <img
                        src={spec.thumbnailUrl}
                        alt={spec.nameAr}
                        loading="lazy"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-1 right-1 text-[9px] font-black px-1.5 py-0.2 rounded bg-black/75 text-amber-300">
                        {spec.orientation === 'landscape' ? '16:9 طويل' : '9:16 ريلز'}
                      </span>
                      <span className="absolute bottom-1 left-1 text-[9px] font-mono px-1 py-0.2 rounded bg-black/75 text-white">
                        {spec.durationHint}s HD
                      </span>
                    </div>
                    <div className="p-2 flex items-center justify-between gap-1">
                      <span className="text-[10px] font-bold text-zinc-200 truncate">
                        {spec.nameAr}
                      </span>
                      <button
                        type="button"
                        disabled={isBusy}
                        data-testid={`add-nature-clip-${spec.id}`}
                        onClick={() => onAddStockNatureVideo(spec)}
                        className="px-2 py-1 rounded-lg bg-emerald-400 hover:brightness-110 text-zinc-950 font-black text-[10px] shrink-0 cursor-pointer disabled:opacity-50"
                      >
                        + أضف
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {assets.length > 0 && (
              <div className="grid grid-cols-2 gap-2.5">
                {assets.map((asset) => (
                  <div
                    key={asset.id}
                    className="rounded-xl bg-[#1B1D24] border border-zinc-800 hover:border-[#00E5DF]/60 overflow-hidden flex flex-col"
                  >
                    <div className="h-24 bg-zinc-900 relative overflow-hidden flex items-center justify-center">
                      {asset.thumbnailDataUrl ? (
                        <img
                          src={asset.thumbnailDataUrl}
                          alt={asset.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Music className="w-6 h-6 text-[#00E5DF]" />
                      )}
                      <span className="absolute bottom-1.5 left-1.5 text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/80 text-white">
                        {asset.duration.toFixed(1)}s
                      </span>
                    </div>
                    <div className="p-2 flex items-center justify-between gap-1.5">
                      <span className="text-[11px] font-semibold text-zinc-200 truncate">
                        {asset.name}
                      </span>
                      <button
                        type="button"
                        onClick={() => onAddAssetToTimeline(asset, false)}
                        className="px-2.5 py-1 rounded-lg bg-[#00E5DF] text-zinc-950 font-black text-[11px] shrink-0 cursor-pointer"
                      >
                        + أضف
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
