import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Maximize2,
  Minimize2,
  Pause,
  Play,
  Redo2,
  Undo2,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { getResolutionDimensions } from '../constants/presets';
import {
  computeClipSlots,
  DrawableMedia,
  renderCompositeFrame,
  resolveTimelineAtTime,
} from '../engine/compositor';
import {
  AspectRatio,
  AudioClip,
  MediaAsset,
  OverlayClip,
  TextOverlay,
  VideoClip,
  VideoEffectClip,
} from '../types/editor';

interface VideoPreviewPlayerProps {
  assets: MediaAsset[];
  clips: VideoClip[];
  texts: TextOverlay[];
  effects: VideoEffectClip[];
  overlays: OverlayClip[];
  audioClips: AudioClip[];
  aspectRatio: AspectRatio;
  bgColor: string;
  currentTime: number;
  totalDuration: number;
  isPlaying: boolean;
  canUndo: boolean;
  canRedo: boolean;
  selectedTextId: string | null;
  selectedOverlayId: string | null;
  onUndo: () => void;
  onRedo: () => void;
  onTimeUpdate: (time: number) => void;
  onTogglePlay: () => void;
  onStopAtEnd: () => void;
  onSelectText: (id: string | null) => void;
  onMoveText: (id: string, x: number, y: number) => void;
  onSelectOverlay: (id: string | null) => void;
  onMoveOverlay: (id: string, x: number, y: number) => void;
  canvasRefExternal?: React.MutableRefObject<HTMLCanvasElement | null>;
}

export function formatTimePrecise(sec: number): string {
  const safe = Math.max(0, sec);
  const mins = Math.floor(safe / 60);
  const secs = Math.floor(safe % 60);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

/**
 * Safely seeks an HTMLVideoElement without canceling in-flight hardware seeks
 * (which causes forward/backward jumping on mobile MediaCodec decoders).
 */
function safeSeekVideoOnce(videoEl: HTMLVideoElement, targetTime: number): void {
  const clamped = Math.max(0, targetTime);
  if (videoEl.seeking) {
    (videoEl as HTMLVideoElement & { __pendingTarget?: number }).__pendingTarget =
      clamped;
    return;
  }
  try {
    videoEl.currentTime = clamped;
  } catch {
    // Metadata may still be loading; loadedmetadata listener will apply pending seek
    (videoEl as HTMLVideoElement & { __pendingTarget?: number }).__pendingTarget =
      clamped;
  }
}

export const VideoPreviewPlayer: React.FC<VideoPreviewPlayerProps> = ({
  assets,
  clips,
  texts,
  effects,
  overlays,
  audioClips,
  aspectRatio,
  bgColor,
  currentTime,
  totalDuration,
  isPlaying,
  canUndo,
  canRedo,
  selectedTextId,
  selectedOverlayId,
  onUndo,
  onRedo,
  onTimeUpdate,
  onTogglePlay,
  onStopAtEnd,
  onSelectText,
  onMoveText,
  onSelectOverlay,
  onMoveOverlay,
  canvasRefExternal,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [previewMutedMaster, setPreviewMutedMaster] = useState(false);
  const [renderTick, setRenderTick] = useState(0);

  const videoPriRef = useRef<HTMLVideoElement | null>(null);
  const videoSecRef = useRef<HTMLVideoElement | null>(null);
  const overlayVideoMapRef = useRef<Map<string, HTMLVideoElement>>(new Map());
  const imageCacheRef = useRef<Map<string, HTMLImageElement>>(new Map());
  const audioPlayersRef = useRef<Map<string, HTMLAudioElement>>(new Map());

  // Tracking refs for rock-solid zero-jump playback & scrubbing
  const currentTimeRef = useRef<number>(currentTime);
  const lastLoopEmittedTimeRef = useRef<number>(currentTime);
  const externalSeekRequestRef = useRef<number | null>(null);
  const lastPausedSeekKeyRef = useRef<string>('');
  const lastSecSeekKeyRef = useRef<string>('');

  const dragTargetRef = useRef<{
    kind: 'text' | 'overlay';
    id: string;
    startPointerX: number;
    startPointerY: number;
    origX: number;
    origY: number;
  } | null>(null);

  const assetMap = useMemo(
    () => new Map(assets.map((a) => [a.id, a])),
    [assets]
  );

  const previewDims = useMemo(() => {
    const full = getResolutionDimensions(aspectRatio, '720p');
    return {
      width: Math.round((full.width * 0.65) / 2) * 2,
      height: Math.round((full.height * 0.65) / 2) * 2,
    };
  }, [aspectRatio]);

  // Preload image assets
  useEffect(() => {
    assets.forEach((a) => {
      if (a.type === 'image' && a.url && !imageCacheRef.current.has(a.id)) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => setRenderTick((n) => n + 1);
        img.src = a.url;
        imageCacheRef.current.set(a.id, img);
      }
    });
  }, [assets]);

  // Wire queued-seek listeners onto real DOM-mounted hidden <video> elements
  // (Mounting in DOM prevents Android WebView / Blink from suspending background video decoding!)
  useEffect(() => {
    const attachListeners = (
      v: (HTMLVideoElement & { __pendingTarget?: number }) | null
    ) => {
      if (!v) return () => {};
      const applyPendingAndRedraw = () => {
        if (v.__pendingTarget !== undefined && !v.seeking) {
          const next = v.__pendingTarget;
          v.__pendingTarget = undefined;
          try {
            v.currentTime = next;
          } catch {
            // ignore
          }
        }
        setRenderTick((n) => n + 1);
      };
      v.addEventListener('loadedmetadata', applyPendingAndRedraw);
      v.addEventListener('loadeddata', applyPendingAndRedraw);
      v.addEventListener('seeked', applyPendingAndRedraw);
      return () => {
        v.removeEventListener('loadedmetadata', applyPendingAndRedraw);
        v.removeEventListener('loadeddata', applyPendingAndRedraw);
        v.removeEventListener('seeked', applyPendingAndRedraw);
      };
    };

    const cleanPri = attachListeners(videoPriRef.current);
    const cleanSec = attachListeners(videoSecRef.current);

    return () => {
      cleanPri();
      cleanSec();
      videoPriRef.current?.pause();
      videoSecRef.current?.pause();
      overlayVideoMapRef.current.forEach((v) => {
        v.pause();
        v.removeAttribute('src');
      });
      overlayVideoMapRef.current.clear();
      audioPlayersRef.current.forEach((aud) => {
        aud.pause();
        aud.removeAttribute('src');
      });
      audioPlayersRef.current.clear();
    };
  }, []);

  // Sync secondary transition video, PIP overlays, and background audio tracks WITHOUT ever touching primary playing video clock!
  const syncAuxiliaryTracks = useCallback(
    (timeSec: number, playing: boolean) => {
      const slots = computeClipSlots(clips);
      const resolved = resolveTimelineAtTime(slots, timeSec);

      // Secondary outgoing clip channel (only active during transitions, always muted)
      const vSec = videoSecRef.current;
      if (vSec) {
        if (resolved.secondary && resolved.secondary.clip.type === 'video') {
          const secAsset = assetMap.get(resolved.secondary.clip.assetId);
          if (secAsset?.url) {
            if (vSec.getAttribute('data-asset-id') !== secAsset.id) {
              vSec.src = secAsset.url;
              vSec.setAttribute('data-asset-id', secAsset.id);
              vSec.load();
            }
            const secKey = `${resolved.secondary.clip.id}:${resolved.secondary.sourceTime.toFixed(2)}`;
            if (lastSecSeekKeyRef.current !== secKey) {
              lastSecSeekKeyRef.current = secKey;
              safeSeekVideoOnce(vSec, resolved.secondary.sourceTime);
            }
          }
        } else if (!vSec.paused) {
          vSec.pause();
        }
      }

      // Sync PIP video overlays without fighting active playback
      for (const ov of overlays) {
        if (ov.type !== 'video') continue;
        const asset = assetMap.get(ov.assetId);
        if (!asset?.url) continue;

        let ovVid = overlayVideoMapRef.current.get(ov.id);
        if (!ovVid) {
          ovVid = document.createElement('video');
          ovVid.playsInline = true;
          ovVid.muted = true;
          ovVid.preload = 'auto';
          ovVid.src = asset.url;
          ovVid.addEventListener('seeked', () => setRenderTick((n) => n + 1));
          ovVid.addEventListener('loadeddata', () => setRenderTick((n) => n + 1));
          overlayVideoMapRef.current.set(ov.id, ovVid);
        }

        const active =
          timeSec >= ov.startTime && timeSec <= ov.startTime + ov.duration;
        if (!active) {
          if (!ovVid.paused) ovVid.pause();
          continue;
        }
        const targetT = Math.max(0, ov.trimStart + (timeSec - ov.startTime));
        if (!playing) {
          if (Math.abs(ovVid.currentTime - targetT) > 0.08) {
            safeSeekVideoOnce(ovVid, targetT);
          }
          if (!ovVid.paused) ovVid.pause();
        } else {
          if (ovVid.paused) {
            if (Math.abs(ovVid.currentTime - targetT) > 0.25) {
              safeSeekVideoOnce(ovVid, targetT);
            }
            if (ovVid.readyState >= 2) ovVid.play().catch(() => {});
          }
        }
      }

      // Sync dedicated audio tracks cleanly (seek ONCE on start or large jump > 0.6s, never re-seek continuously!)
      const activeAudioIds = new Set<string>();
      for (const aClip of audioClips) {
        activeAudioIds.add(aClip.id);
        const asset = assetMap.get(aClip.assetId);
        if (!asset?.url) continue;

        let aud = audioPlayersRef.current.get(aClip.id);
        if (!aud) {
          aud = new Audio(asset.url);
          aud.preload = 'auto';
          audioPlayersRef.current.set(aClip.id, aud);
        }

        const inRange =
          timeSec >= aClip.startTime &&
          timeSec < aClip.startTime + aClip.duration;

        if (!playing || !inRange || aClip.muted || previewMutedMaster) {
          if (!aud.paused) aud.pause();
          continue;
        }

        const localAudioTime = aClip.trimStart + (timeSec - aClip.startTime);
        aud.volume = Math.max(0, Math.min(1, aClip.volume / 100));
        if (aud.paused) {
          if (Math.abs(aud.currentTime - localAudioTime) > 0.15) {
            try {
              aud.currentTime = Math.max(0, localAudioTime);
            } catch {
              // ignore
            }
          }
          aud.play().catch(() => {});
        } else if (Math.abs(aud.currentTime - localAudioTime) > 0.75) {
          try {
            aud.currentTime = Math.max(0, localAudioTime);
          } catch {
            // ignore
          }
        }
      }

      for (const [id, aud] of audioPlayersRef.current.entries()) {
        if (!activeAudioIds.has(id)) {
          aud.pause();
          aud.removeAttribute('src');
          audioPlayersRef.current.delete(id);
        }
      }
    },
    [assetMap, audioClips, clips, overlays, previewMutedMaster]
  );

  const drawCurrentPreviewFrame = useCallback(
    (timeSec: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const slots = computeClipSlots(clips);
      const resolved = resolveTimelineAtTime(slots, timeSec);

      renderCompositeFrame({
        ctx,
        width: canvas.width,
        height: canvas.height,
        clips,
        texts,
        effects,
        overlays,
        bgColor,
        timeSec,
        selectedTextId,
        selectedOverlayId,
        getMediaFrame: (clip, sTime): DrawableMedia | null => {
          if (clip.type === 'image') {
            return imageCacheRef.current.get(clip.assetId) || null;
          }
          if (
            resolved.secondary &&
            clip.id === resolved.secondary.clip.id &&
            Math.abs(sTime - resolved.secondary.sourceTime) < 0.02
          ) {
            return videoSecRef.current && videoSecRef.current.readyState >= 2
              ? videoSecRef.current
              : null;
          }
          return videoPriRef.current && videoPriRef.current.readyState >= 2
            ? videoPriRef.current
            : null;
        },
        getOverlayFrame: (ov): DrawableMedia | null => {
          if (ov.type === 'image') {
            return imageCacheRef.current.get(ov.assetId) || null;
          }
          const v = overlayVideoMapRef.current.get(ov.id);
          return v && v.readyState >= 2 ? v : null;
        },
      });
    },
    [bgColor, clips, effects, overlays, selectedOverlayId, selectedTextId, texts]
  );

  // Keep live references for the uninterrupted RAF loop so React re-renders NEVER tear down playback!
  const latestStateRef = useRef({
    clips,
    assetMap,
    totalDuration,
    previewMutedMaster,
    syncAuxiliaryTracks,
    drawCurrentPreviewFrame,
    onTimeUpdate,
    onStopAtEnd,
  });
  latestStateRef.current = {
    clips,
    assetMap,
    totalDuration,
    previewMutedMaster,
    syncAuxiliaryTracks,
    drawCurrentPreviewFrame,
    onTimeUpdate,
    onStopAtEnd,
  };

  // Detect external user seeks (timeline ruler scrub, Undo/Redo, clicking caption item) vs internal playback ticks
  useEffect(() => {
    if (!isPlaying) {
      currentTimeRef.current = currentTime;
      lastLoopEmittedTimeRef.current = currentTime;
      return;
    }

    if (Math.abs(currentTime - lastLoopEmittedTimeRef.current) > 0.06) {
      // Genuine external user jump while playing!
      currentTimeRef.current = currentTime;
      lastLoopEmittedTimeRef.current = currentTime;
      externalSeekRequestRef.current = currentTime;
    }
  }, [currentTime, isPlaying]);

  // Synchronize paused frame ONLY when paused and ONLY when target time/clip actually changed!
  useEffect(() => {
    if (isPlaying) return;

    const vPri = videoPriRef.current;
    const slots = computeClipSlots(clips);
    const resolved = resolveTimelineAtTime(slots, currentTime);

    if (vPri) {
      if (!vPri.paused) vPri.pause();

      if (resolved.primary && resolved.primary.clip.type === 'video') {
        const asset = assetMap.get(resolved.primary.clip.assetId);
        if (asset?.url) {
          if (vPri.getAttribute('data-asset-id') !== asset.id) {
            vPri.src = asset.url;
            vPri.setAttribute('data-asset-id', asset.id);
            vPri.load();
            lastPausedSeekKeyRef.current = '';
          }
          const seekKey = `${resolved.primary.clip.id}:${asset.id}:${resolved.primary.sourceTime.toFixed(3)}`;
          if (lastPausedSeekKeyRef.current !== seekKey) {
            lastPausedSeekKeyRef.current = seekKey;
            safeSeekVideoOnce(vPri, resolved.primary.sourceTime);
          }
        }
      }
    }

    syncAuxiliaryTracks(currentTime, false);
    drawCurrentPreviewFrame(currentTime);
  }, [
    isPlaying,
    currentTime,
    clips,
    assetMap,
    syncAuxiliaryTracks,
    drawCurrentPreviewFrame,
  ]);

  // Also redraw paused canvas when non-time visual edits happen (filters, text, stickers, image load, seeked)
  useEffect(() => {
    if (!isPlaying) {
      drawCurrentPreviewFrame(currentTimeRef.current);
    }
  }, [drawCurrentPreviewFrame, isPlaying, renderTick]);

  // =========================================================================
  // NATURAL HARDWARE-DRIVEN PLAYBACK LOOP (Depends ONLY on `[isPlaying]`!)
  // Plays imported videos at 100% smooth native speed with ZERO auto-seeking!
  // =========================================================================
  useEffect(() => {
    if (!isPlaying) return;

    let rafId = 0;
    let lastWallStamp = performance.now();
    let activePlayingClipId: string | null = null;
    let lastRawVideoTime = -1;
    let videoStalledMs = 0;
    let forcedMutedByAutoplayPolicy = false;

    // Reset paused seek cache so pausing later seeks cleanly if needed
    lastPausedSeekKeyRef.current = '';

    const tryPlayWithAutoplayFallback = (vPri: HTMLVideoElement) => {
      vPri.play().catch(() => {
        forcedMutedByAutoplayPolicy = true;
        vPri.muted = true;
        vPri.play().catch(() => {});
      });
    };

    const prepareAndStartClip = (
      vPri: HTMLVideoElement,
      clip: VideoClip,
      assetUrl: string,
      assetId: string,
      startSourceTime: number,
      mutedMaster: boolean
    ) => {
      if (vPri.getAttribute('data-asset-id') !== assetId) {
        vPri.src = assetUrl;
        vPri.setAttribute('data-asset-id', assetId);
        vPri.load();
      }
      const rate = clip.speed || 1;
      if (Math.abs(vPri.playbackRate - rate) > 0.01) {
        vPri.playbackRate = rate;
      }
      const shouldMute =
        forcedMutedByAutoplayPolicy ||
        mutedMaster ||
        clip.muted ||
        clip.volume <= 0;
      vPri.muted = shouldMute;
      if (!shouldMute) {
        vPri.volume = Math.max(0, Math.min(1, clip.volume / 100));
      }

      // Seek ONCE on clip start only if not already positioned right there
      if (Math.abs(vPri.currentTime - startSourceTime) > 0.07) {
        safeSeekVideoOnce(vPri, startSourceTime);
      }

      tryPlayWithAutoplayFallback(vPri);
      activePlayingClipId = clip.id;
      lastRawVideoTime = vPri.currentTime;
      videoStalledMs = 0;
    };

    const loop = (now: number) => {
      const {
        clips: curClips,
        assetMap: curAssetMap,
        totalDuration: curTotalDur,
        previewMutedMaster: mutedMaster,
        syncAuxiliaryTracks: syncAux,
        drawCurrentPreviewFrame: drawFrame,
        onTimeUpdate: emitTime,
        onStopAtEnd: stopAtEnd,
      } = latestStateRef.current;

      const dt = Math.min(0.06, Math.max(0, (now - lastWallStamp) / 1000));
      lastWallStamp = now;

      if (curTotalDur <= 0) {
        stopAtEnd();
        return;
      }

      // Handle explicit user scrub during active playback
      if (externalSeekRequestRef.current !== null) {
        currentTimeRef.current = externalSeekRequestRef.current;
        externalSeekRequestRef.current = null;
        activePlayingClipId = null;
      }

      const slots = computeClipSlots(curClips);
      const vPri = videoPriRef.current;
      let nextTime = currentTimeRef.current;

      // Locate active clip slot
      let slotIdx = slots.findIndex(
        (s) => nextTime >= s.startTime && nextTime < s.endTime
      );
      if (slotIdx === -1 && slots.length > 0) {
        slotIdx = nextTime <= 0 ? 0 : slots.length - 1;
      }

      const slot = slotIdx >= 0 ? slots[slotIdx] : null;

      if (slot && slot.clip.type === 'video' && vPri) {
        const asset = curAssetMap.get(slot.clip.assetId);
        const speed = slot.clip.speed || 1;
        const expectedSourceStart =
          slot.clip.trimStart + Math.max(0, nextTime - slot.startTime) * speed;

        if (activePlayingClipId !== slot.clip.id && asset?.url) {
          prepareAndStartClip(
            vPri,
            slot.clip,
            asset.url,
            asset.id,
            expectedSourceStart,
            mutedMaster
          );
        } else {
          // Keep live volume/mute/speed responsive if user toggles them while playing (WITHOUT touching currentTime!)
          if (Math.abs(vPri.playbackRate - speed) > 0.01) {
            vPri.playbackRate = speed;
          }
          const shouldMute =
            forcedMutedByAutoplayPolicy ||
            mutedMaster ||
            slot.clip.muted ||
            slot.clip.volume <= 0;
          if (vPri.muted !== shouldMute) vPri.muted = shouldMute;
          if (!shouldMute) {
            const targetVol = Math.max(0, Math.min(1, slot.clip.volume / 100));
            if (Math.abs(vPri.volume - targetVol) > 0.02) vPri.volume = targetVol;
          }
          if (vPri.paused && !vPri.ended && vPri.readyState >= 2) {
            tryPlayWithAutoplayFallback(vPri);
          }
        }

        // Read natural hardware video clock directly whenever native video is actively advancing!
        const rawVt = vPri.currentTime;
        if (Math.abs(rawVt - lastRawVideoTime) > 0.0005) {
          // Native hardware decoder is advancing naturally — ZERO writes to vPri.currentTime!
          lastRawVideoTime = rawVt;
          videoStalledMs = 0;
          const hwTimelinePos =
            slot.startTime + (rawVt - slot.clip.trimStart) / speed;
          nextTime = Math.max(nextTime, hwTimelinePos);
        } else {
          videoStalledMs += dt * 1000;
          // Wait 180ms for decoder initial frame; if environment has no audio output clock (e.g. headless shell),
          // advance smoothly and monotonically via wall clock without ever jumping backward!
          if (videoStalledMs > 180) {
            nextTime += dt;
            const fallbackSourceT =
              slot.clip.trimStart + (nextTime - slot.startTime) * speed;
            if (!vPri.seeking && Math.abs(vPri.currentTime - fallbackSourceT) > 0.15) {
              safeSeekVideoOnce(vPri, fallbackSourceT);
            }
          }
        }

        // Check if current video clip reached its trimmed end or natural file end
        if (nextTime >= slot.endTime - 0.012 || vPri.ended) {
          if (slotIdx < slots.length - 1) {
            // Advance seamlessly into next clip on timeline!
            nextTime = slots[slotIdx + 1].startTime + 0.001;
            activePlayingClipId = null;
          } else {
            // End of entire project reached cleanly!
            vPri.pause();
            syncAux(curTotalDur, false);
            drawFrame(Math.max(0, curTotalDur - 0.01));
            currentTimeRef.current = 0;
            lastLoopEmittedTimeRef.current = 0;
            emitTime(0);
            stopAtEnd();
            return;
          }
        }
      } else {
        // Still image clip or text/audio-only project: smooth monotonic wall-clock
        if (vPri && !vPri.paused) vPri.pause();
        activePlayingClipId = slot ? slot.clip.id : null;
        nextTime += dt;

        if (nextTime >= curTotalDur) {
          syncAux(curTotalDur, false);
          drawFrame(Math.max(0, curTotalDur - 0.01));
          currentTimeRef.current = 0;
          lastLoopEmittedTimeRef.current = 0;
          emitTime(0);
          stopAtEnd();
          return;
        }
      }

      currentTimeRef.current = nextTime;
      syncAux(nextTime, true);
      drawFrame(nextTime);
      lastLoopEmittedTimeRef.current = nextTime;
      emitTime(nextTime);

      rafId = requestAnimationFrame(loop);
    };

    rafId = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(rafId);
      if (videoPriRef.current && !videoPriRef.current.paused) {
        videoPriRef.current.pause();
      }
    };
  }, [isPlaying]);

  // Direct touch/mouse drag for both Text/Stickers AND Picture-in-Picture Overlays
  const handleCanvasPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickXPct = ((e.clientX - rect.left) / rect.width) * 100;
    const clickYPct = ((e.clientY - rect.top) / rect.height) * 100;

    const visibleTexts = [...texts]
      .reverse()
      .filter(
        (t) =>
          currentTime >= t.startTime && currentTime <= t.startTime + t.duration
      );
    const hitText = visibleTexts.find(
      (t) => Math.abs(t.x - clickXPct) < 28 && Math.abs(t.y - clickYPct) < 12
    );

    if (hitText) {
      e.currentTarget.setPointerCapture(e.pointerId);
      onSelectText(hitText.id);
      dragTargetRef.current = {
        kind: 'text',
        id: hitText.id,
        startPointerX: e.clientX,
        startPointerY: e.clientY,
        origX: hitText.x,
        origY: hitText.y,
      };
      return;
    }

    const visibleOverlays = [...overlays]
      .reverse()
      .filter(
        (ov) =>
          currentTime >= ov.startTime &&
          currentTime <= ov.startTime + ov.duration
      );
    const hitOv = visibleOverlays.find(
      (ov) =>
        Math.abs(ov.x - clickXPct) < ov.scale * 0.55 &&
        Math.abs(ov.y - clickYPct) < ov.scale * 0.55
    );

    if (hitOv) {
      e.currentTarget.setPointerCapture(e.pointerId);
      onSelectOverlay(hitOv.id);
      dragTargetRef.current = {
        kind: 'overlay',
        id: hitOv.id,
        startPointerX: e.clientX,
        startPointerY: e.clientY,
        origX: hitOv.x,
        origY: hitOv.y,
      };
      return;
    }

    onSelectText(null);
    onSelectOverlay(null);
  };

  const handleCanvasPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const drag = dragTargetRef.current;
    const canvas = canvasRef.current;
    if (!drag || !canvas) return;
    const rect = canvas.getBoundingClientRect();
    const dxPct = ((e.clientX - drag.startPointerX) / rect.width) * 100;
    const dyPct = ((e.clientY - drag.startPointerY) / rect.height) * 100;
    const nextX = Math.max(6, Math.min(94, Math.round(drag.origX + dxPct)));
    const nextY = Math.max(6, Math.min(94, Math.round(drag.origY + dyPct)));
    if (drag.kind === 'text') {
      onMoveText(drag.id, nextX, nextY);
    } else {
      onMoveOverlay(drag.id, nextX, nextY);
    }
  };

  const handleCanvasPointerUp = () => {
    dragTargetRef.current = null;
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current
        .requestFullscreen?.()
        .then(() => setIsFullscreen(true))
        .catch(() => {});
    } else {
      document
        .exitFullscreen?.()
        .then(() => setIsFullscreen(false))
        .catch(() => {});
    }
  };

  return (
    <div
      ref={containerRef}
      className="flex flex-col justify-between w-full h-full bg-[#000000] select-none relative"
    >
      {/* Hidden DOM-mounted hardware media decoders so Android WebView / Chrome never suspend playback */}
      <video
        ref={videoPriRef}
        playsInline
        preload="auto"
        crossOrigin="anonymous"
        aria-hidden="true"
        className="fixed -left-[9999px] top-0 w-px h-px opacity-0 pointer-events-none"
      />
      <video
        ref={videoSecRef}
        muted
        playsInline
        preload="auto"
        crossOrigin="anonymous"
        aria-hidden="true"
        className="fixed -left-[9999px] top-0 w-px h-px opacity-0 pointer-events-none"
      />
      {/* Pure Uncluttered CapCut Black Stage */}
      <div className="relative flex-1 w-full flex items-center justify-center min-h-[160px] p-1.5 sm:p-2 overflow-hidden">
        {clips.length === 0 && texts.length === 0 && overlays.length === 0 ? (
          <div className="text-center space-y-1.5 px-6 py-5 rounded-2xl border border-zinc-800 bg-[#111216]">
            <p className="text-xs sm:text-sm font-bold text-zinc-200">
              مساحة الفيديو جاهزة للمونتاج
            </p>
            <p className="text-[11px] text-zinc-500">
              اضغط زر <strong className="text-white">[ + ]</strong> لإضافة فيديو أو
              صورة من هاتفك
            </p>
          </div>
        ) : (
          <canvas
            ref={(el) => {
              canvasRef.current = el;
              if (canvasRefExternal) canvasRefExternal.current = el;
            }}
            width={previewDims.width}
            height={previewDims.height}
            data-testid="preview-canvas"
            onPointerDown={handleCanvasPointerDown}
            onPointerMove={handleCanvasPointerMove}
            onPointerUp={handleCanvasPointerUp}
            style={{
              aspectRatio: `${previewDims.width} / ${previewDims.height}`,
            }}
            className="max-h-full max-w-full bg-black touch-none cursor-grab active:cursor-grabbing shadow-2xl"
          />
        )}
      </div>

      {/* Authentic CapCut Transport Strip directly under Stage */}
      <div className="h-10 px-3 bg-[#090A0D] border-t border-zinc-900 flex items-center justify-between gap-2 shrink-0">
        <div
          dir="ltr"
          data-testid="preview-timecode"
          className="font-mono text-[11px] sm:text-xs font-semibold tabular-nums flex items-center gap-1"
        >
          <span className="text-white">{formatTimePrecise(currentTime)}</span>
          <span className="text-zinc-600">/</span>
          <span className="text-zinc-500">
            {formatTimePrecise(totalDuration)}
          </span>
        </div>

        <button
          type="button"
          data-testid="play-pause-btn"
          title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
          onClick={onTogglePlay}
          disabled={totalDuration <= 0}
          className="w-8 h-8 rounded-full hover:bg-zinc-800 text-white flex items-center justify-center transition active:scale-90 cursor-pointer disabled:opacity-35"
        >
          {isPlaying ? (
            <Pause className="w-5 h-5 fill-current" />
          ) : (
            <Play className="w-5 h-5 fill-current -translate-x-0.5" />
          )}
        </button>

        <div className="flex items-center gap-1">
          <button
            type="button"
            data-testid="undo-btn"
            disabled={!canUndo}
            onClick={onUndo}
            title="تراجع"
            className="p-1.5 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800 disabled:opacity-30 cursor-pointer"
          >
            <Undo2 className="w-4 h-4" />
          </button>

          <button
            type="button"
            data-testid="redo-btn"
            disabled={!canRedo}
            onClick={onRedo}
            title="إعادة"
            className="p-1.5 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800 disabled:opacity-30 cursor-pointer"
          >
            <Redo2 className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => setPreviewMutedMaster((m) => !m)}
            title="كتم صوت المعاينة"
            className="p-1.5 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800 cursor-pointer"
          >
            {previewMutedMaster ? (
              <VolumeX className="w-4 h-4 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </button>

          <button
            type="button"
            onClick={toggleFullscreen}
            title="ملء الشاشة"
            className="p-1.5 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800 cursor-pointer"
          >
            {isFullscreen ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
