import { AudioClip, MediaAsset, VideoClip } from '../types/editor';
import { computeClipSlots } from './compositor';

const decodedBufferCache = new Map<string, AudioBuffer>();

export async function decodeMediaAudio(
  asset: MediaAsset
): Promise<AudioBuffer | null> {
  if (asset.type === 'image') return null;
  const cached = decodedBufferCache.get(asset.id);
  if (cached) return cached;

  try {
    let arrayBuffer: ArrayBuffer;
    if (asset.blob) {
      arrayBuffer = await asset.blob.arrayBuffer();
    } else if (asset.url) {
      const resp = await fetch(asset.url);
      arrayBuffer = await resp.arrayBuffer();
    } else {
      return null;
    }

    // Avoid blowing memory on low-RAM phones (e.g. Samsung A04) for huge files > 160MB
    if (arrayBuffer.byteLength > 160 * 1024 * 1024) {
      console.warn('Skipping full in-memory decodeAudioData for very large file');
      return null;
    }

    // Use OfflineAudioContext so decoding NEVER suspends or hits browser hardware AudioContext limits across unlimited runs!
    const offlineDecoder = new OfflineAudioContext(1, 1, 44100);
    const audioBuffer = await offlineDecoder.decodeAudioData(
      arrayBuffer.slice(0)
    );
    decodedBufferCache.set(asset.id, audioBuffer);
    return audioBuffer;
  } catch {
    // Video might be silent / contain no audio track — perfectly normal!
    return null;
  }
}

export function extractWaveformPeaks(
  audioBuffer: AudioBuffer,
  bucketCount = 80
): number[] {
  const rawData = audioBuffer.getChannelData(0);
  const blockSize = Math.max(1, Math.floor(rawData.length / bucketCount));
  const peaks: number[] = [];

  for (let i = 0; i < bucketCount; i++) {
    const start = i * blockSize;
    let max = 0;
    const end = Math.min(rawData.length, start + blockSize);
    for (let j = start; j < end; j += Math.max(1, Math.floor(blockSize / 64))) {
      const abs = Math.abs(rawData[j]);
      if (abs > max) max = abs;
    }
    peaks.push(Math.min(1, Math.max(0.06, max)));
  }

  return peaks;
}

export async function mixProjectAudioBuffer(params: {
  assets: MediaAsset[];
  clips: VideoClip[];
  audioClips: AudioClip[];
  totalDuration: number;
  sampleRate?: number;
  numberOfChannels?: number;
}): Promise<AudioBuffer | null> {
  const {
    assets,
    clips,
    audioClips,
    totalDuration,
    sampleRate = 48000,
    numberOfChannels = 2,
  } = params;

  if (totalDuration <= 0.05) return null;

  const assetMap = new Map(assets.map((a) => [a.id, a]));
  const frameLength = Math.max(1024, Math.ceil(totalDuration * sampleRate));

  const offlineCtx = new OfflineAudioContext(
    numberOfChannels,
    frameLength,
    sampleRate
  );

  let hasAnySoundSource = false;

  // 1. Schedule unmuted primary video clips
  const slots = computeClipSlots(clips);
  for (const slot of slots) {
    const { clip, startTime } = slot;
    if (clip.type !== 'video' || clip.muted || clip.volume <= 0) continue;
    const asset = assetMap.get(clip.assetId);
    if (!asset) continue;

    const buffer = await decodeMediaAudio(asset);
    if (!buffer) continue;

    const source = offlineCtx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = clip.speed || 1;

    const gainNode = offlineCtx.createGain();
    const vol = Math.max(0, Math.min(2, clip.volume / 100));

    // Smooth 15ms micro-fades at clip boundaries to prevent click artifacts
    const clipEnd = startTime + clip.duration;
    const micro = Math.min(0.02, clip.duration * 0.2);
    gainNode.gain.setValueAtTime(0, startTime);
    gainNode.gain.linearRampToValueAtTime(vol, startTime + micro);
    gainNode.gain.setValueAtTime(vol, Math.max(startTime + micro, clipEnd - micro));
    gainNode.gain.linearRampToValueAtTime(0, clipEnd);

    source.connect(gainNode);
    gainNode.connect(offlineCtx.destination);

    const maxOffset = Math.max(0, buffer.duration - 0.01);
    const offset = Math.min(clip.trimStart, maxOffset);
    const sourcePlayDur = Math.max(
      0.02,
      Math.min(clip.duration * (clip.speed || 1), buffer.duration - offset)
    );

    source.start(startTime, offset, sourcePlayDur);
    hasAnySoundSource = true;
  }

  // 2. Schedule dedicated Audio Track clips (Music, Voiceover, SFX)
  for (const aClip of audioClips) {
    if (aClip.muted || aClip.volume <= 0) continue;
    if (aClip.startTime >= totalDuration) continue;

    const asset = assetMap.get(aClip.assetId);
    if (!asset) continue;

    const buffer = await decodeMediaAudio(asset);
    if (!buffer) continue;

    const effectiveDur = Math.min(
      aClip.duration,
      totalDuration - aClip.startTime,
      Math.max(0.02, buffer.duration - aClip.trimStart)
    );
    if (effectiveDur <= 0.02) continue;

    const source = offlineCtx.createBufferSource();
    source.buffer = buffer;

    const gainNode = offlineCtx.createGain();
    const vol = Math.max(0, Math.min(2, aClip.volume / 100));
    const t0 = Math.max(0, aClip.startTime);
    const tEnd = t0 + effectiveDur;
    const fIn = Math.min(Math.max(0.015, aClip.fadeIn || 0.015), effectiveDur * 0.45);
    const fOut = Math.min(
      Math.max(0.015, aClip.fadeOut || 0.015),
      effectiveDur * 0.45
    );

    gainNode.gain.setValueAtTime(0, t0);
    gainNode.gain.linearRampToValueAtTime(vol, t0 + fIn);
    gainNode.gain.setValueAtTime(vol, Math.max(t0 + fIn, tEnd - fOut));
    gainNode.gain.linearRampToValueAtTime(0, tEnd);

    source.connect(gainNode);
    gainNode.connect(offlineCtx.destination);

    source.start(t0, Math.min(aClip.trimStart, buffer.duration - 0.01), effectiveDur);
    hasAnySoundSource = true;
  }

  if (!hasAnySoundSource) {
    // Still return a clean silent stereo AudioBuffer so exported MP4 files always have a valid audio stream if desired
    return offlineCtx.startRendering();
  }

  return offlineCtx.startRendering();
}

export function audioBufferToWavBlob(audioBuffer: AudioBuffer): Blob {
  const numChannels = audioBuffer.numberOfChannels;
  const sampleRate = audioBuffer.sampleRate;
  const numSamples = audioBuffer.length;
  const bytesPerSample = 2; // 16-bit PCM
  const blockAlign = numChannels * bytesPerSample;
  const dataSize = numSamples * blockAlign;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  const channels: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(audioBuffer.getChannelData(c));
  }

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    for (let c = 0; c < numChannels; c++) {
      const s = Math.max(-1, Math.min(1, channels[c][i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      offset += 2;
    }
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

export type BuiltInSoundPreset =
  | 'nature-rain'
  | 'nature-ocean'
  | 'nature-wind'
  | 'nature-stream'
  | 'lofi-beat'
  | 'cinematic-pad'
  | 'warm-acoustic'
  | 'whoosh-sfx'
  | 'riser-sfx'
  | 'impact-sfx'
  | 'shutter-sfx'
  | 'ding-sfx';

export const BUILT_IN_SOUNDS: {
  id: BuiltInSoundPreset;
  nameAr: string;
  category: 'music' | 'sfx';
  duration: number;
  desc: string;
}[] = [
  {
    id: 'nature-rain',
    nameAr: 'صوت مطر طبيعي هادئ 🌧️ (بدون موسيقى)',
    category: 'sfx',
    duration: 12.0,
    desc: 'صوت قطرات مطر طبيعية صافية للخشوع والتلاوات والخواطر',
  },
  {
    id: 'nature-ocean',
    nameAr: 'أمواج البحر الهادئة 🌊 (بدون موسيقى)',
    category: 'sfx',
    duration: 12.0,
    desc: 'هدير أمواج الشاطئ المتناغم للاسترخاء والطبيعة',
  },
  {
    id: 'nature-stream',
    nameAr: 'خرير جدول الماء والشلال 🏞️ (بدون موسيقى)',
    category: 'sfx',
    duration: 12.0,
    desc: 'جريان مياه عذبة في الغابة بدون أي آلات موسيقية',
  },
  {
    id: 'nature-wind',
    nameAr: 'نسيم الجبال والصحراء 🍃 (بدون موسيقى)',
    category: 'sfx',
    duration: 12.0,
    desc: 'صوت الهواء الهادئ للمشاهد الجبلية والصحراوية',
  },
  {
    id: 'lofi-beat',
    nameAr: 'إيقاع هادئ (Lo-Fi Studio)',
    category: 'music',
    duration: 10.0,
    desc: 'خلفية هادئة للمونتاج اليومي والفلوقات',
  },
  {
    id: 'cinematic-pad',
    nameAr: 'أجواء سينمائية (Epic Ambient)',
    category: 'music',
    duration: 10.0,
    desc: 'تناغم عميق للمشاهد الوثائقية والسينمائية',
  },
  {
    id: 'warm-acoustic',
    nameAr: 'نغم دافئ هادئ (Warm Calm)',
    category: 'music',
    duration: 10.0,
    desc: 'خلفية ناعمة للذكريات والسفر والقصص',
  },
  {
    id: 'whoosh-sfx',
    nameAr: 'انتقال هوائي سريع (Whoosh)',
    category: 'sfx',
    duration: 0.85,
    desc: 'مؤثر مثالي مع انتقالات الانزلاق والتكبير',
  },
  {
    id: 'riser-sfx',
    nameAr: 'تصاعد تشويقي (Cinematic Riser)',
    category: 'sfx',
    duration: 1.8,
    desc: 'تمهيد صوتي متصاعد قبل ظهور المشهد الرئيسي',
  },
  {
    id: 'impact-sfx',
    nameAr: 'ضربة درامية (Cinema Boom)',
    category: 'sfx',
    duration: 1.4,
    desc: 'ضربة صوتية عميقة لإبراز العناوين المهمة',
  },
  {
    id: 'shutter-sfx',
    nameAr: 'غالق الكاميرا (Camera Shutter)',
    category: 'sfx',
    duration: 0.45,
    desc: 'صوت التقاط صورة فوتوغرافية لتجميد الإطار والذكريات',
  },
  {
    id: 'ding-sfx',
    nameAr: 'رنين كريستالي (Pop Ding)',
    category: 'sfx',
    duration: 0.75,
    desc: 'رنين مشرق لظهور النصوص والشارات التفاعلية',
  },
];

export async function generateBuiltInSoundAsset(
  presetId: BuiltInSoundPreset
): Promise<MediaAsset> {
  const meta =
    BUILT_IN_SOUNDS.find((s) => s.id === presetId) || BUILT_IN_SOUNDS[0];
  const sampleRate = 44100;
  const length = Math.floor(meta.duration * sampleRate);
  const offline = new OfflineAudioContext(2, length, sampleRate);

  if (presetId === 'lofi-beat') {
    // Warm electric piano chords + gentle soft kick & hi-hat groove
    const chords = [
      [261.63, 329.63, 392.0, 493.88], // Cmaj7
      [220.0, 261.63, 329.63, 392.0],  // Am7
      [174.61, 220.0, 261.63, 349.23], // Fmaj7
      [196.0, 246.94, 293.66, 392.0],  // G6
    ];
    chords.forEach((notes, barIdx) => {
      const start = barIdx * 2.0;
      notes.forEach((freq) => {
        const osc = offline.createOscillator();
        const gain = offline.createGain();
        osc.type = 'triangle';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.001, start);
        gain.gain.linearRampToValueAtTime(0.085, start + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.018, start + 1.95);
        osc.connect(gain);
        gain.connect(offline.destination);
        osc.start(start);
        osc.stop(start + 1.98);
      });
    });
    // Soft kick every 0.5s
    for (let beat = 0; beat < 16; beat++) {
      const t = beat * 0.5;
      if (beat % 2 === 0) {
        const kick = offline.createOscillator();
        const kg = offline.createGain();
        kick.frequency.setValueAtTime(135, t);
        kick.frequency.exponentialRampToValueAtTime(42, t + 0.14);
        kg.gain.setValueAtTime(0.28, t);
        kg.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
        kick.connect(kg);
        kg.connect(offline.destination);
        kick.start(t);
        kick.stop(t + 0.22);
      }
    }
  } else if (presetId === 'cinematic-pad') {
    const freqs = [110, 164.81, 220, 277.18, 329.63];
    freqs.forEach((f, idx) => {
      const osc = offline.createOscillator();
      const gain = offline.createGain();
      osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(f * 0.996, 0);
      osc.frequency.linearRampToValueAtTime(f * 1.004, meta.duration);
      gain.gain.setValueAtTime(0.001, 0);
      gain.gain.linearRampToValueAtTime(0.11, 1.8);
      gain.gain.setValueAtTime(0.11, meta.duration - 1.6);
      gain.gain.linearRampToValueAtTime(0.001, meta.duration);
      osc.connect(gain);
      gain.connect(offline.destination);
      osc.start(0);
      osc.stop(meta.duration);
    });
  } else if (presetId === 'whoosh-sfx') {
    const noiseBuf = offline.createBuffer(1, length, sampleRate);
    const ch = noiseBuf.getChannelData(0);
    for (let i = 0; i < length; i++) ch[i] = Math.random() * 2 - 1;
    const src = offline.createBufferSource();
    src.buffer = noiseBuf;
    const filter = offline.createBiquadFilter();
    filter.type = 'bandpass';
    filter.Q.value = 2.4;
    filter.frequency.setValueAtTime(180, 0);
    filter.frequency.exponentialRampToValueAtTime(2400, 0.38);
    filter.frequency.exponentialRampToValueAtTime(220, meta.duration);
    const gain = offline.createGain();
    gain.gain.setValueAtTime(0.01, 0);
    gain.gain.linearRampToValueAtTime(0.65, 0.35);
    gain.gain.exponentialRampToValueAtTime(0.001, meta.duration);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(offline.destination);
    src.start(0);
  } else if (
    presetId === 'nature-rain' ||
    presetId === 'nature-ocean' ||
    presetId === 'nature-stream' ||
    presetId === 'nature-wind'
  ) {
    // Pure zero-music natural acoustic soundscapes synthesized via filtered pink/brown noise + LFO modulation
    const noiseBuf = offline.createBuffer(2, length, sampleRate);
    for (let chIdx = 0; chIdx < 2; chIdx++) {
      const ch = noiseBuf.getChannelData(chIdx);
      let lastOut = 0;
      for (let i = 0; i < length; i++) {
        const white = Math.random() * 2 - 1;
        lastOut = (lastOut + 0.03 * white) / 1.03; // smooth brown/pink natural spectrum
        const env =
          presetId === 'nature-ocean'
            ? 0.35 + 0.65 * Math.pow(0.5 + 0.5 * Math.sin((i / sampleRate) * Math.PI * 0.45), 1.6)
            : presetId === 'nature-wind'
              ? 0.45 + 0.45 * Math.sin((i / sampleRate) * Math.PI * 0.3)
              : 0.85;
        ch[i] =
          (presetId === 'nature-rain' || presetId === 'nature-stream'
            ? lastOut * 2.2 + white * 0.08
            : lastOut * 2.8) * env;
      }
    }
    const src = offline.createBufferSource();
    src.buffer = noiseBuf;
    const filter = offline.createBiquadFilter();
    filter.type = presetId === 'nature-wind' ? 'lowpass' : 'bandpass';
    filter.frequency.value =
      presetId === 'nature-rain'
        ? 1150
        : presetId === 'nature-stream'
          ? 780
          : presetId === 'nature-ocean'
            ? 420
            : 320;
    filter.Q.value = 0.7;
    const gain = offline.createGain();
    gain.gain.setValueAtTime(0.01, 0);
    gain.gain.linearRampToValueAtTime(0.55, 0.6);
    gain.gain.setValueAtTime(0.55, meta.duration - 0.6);
    gain.gain.linearRampToValueAtTime(0.01, meta.duration);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(offline.destination);
    src.start(0);
  } else if (presetId === 'warm-acoustic') {
    const notes = [196.0, 246.94, 293.66, 369.99, 440.0];
    notes.forEach((f, idx) => {
      for (let rep = 0; rep < 3; rep++) {
        const t0 = rep * 3.2 + idx * 0.18;
        if (t0 >= meta.duration - 0.4) continue;
        const osc = offline.createOscillator();
        const gain = offline.createGain();
        osc.type = 'sine';
        osc.frequency.value = f;
        gain.gain.setValueAtTime(0.001, t0);
        gain.gain.linearRampToValueAtTime(0.11, t0 + 0.06);
        gain.gain.exponentialRampToValueAtTime(0.002, Math.min(meta.duration, t0 + 2.8));
        osc.connect(gain);
        gain.connect(offline.destination);
        osc.start(t0);
        osc.stop(Math.min(meta.duration, t0 + 2.85));
      }
    });
  } else if (presetId === 'riser-sfx') {
    const osc = offline.createOscillator();
    const gain = offline.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(95, 0);
    osc.frequency.exponentialRampToValueAtTime(920, meta.duration);
    const lp = offline.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(220, 0);
    lp.frequency.exponentialRampToValueAtTime(3400, meta.duration);
    gain.gain.setValueAtTime(0.01, 0);
    gain.gain.exponentialRampToValueAtTime(0.45, meta.duration - 0.05);
    gain.gain.linearRampToValueAtTime(0.001, meta.duration);
    osc.connect(lp);
    lp.connect(gain);
    gain.connect(offline.destination);
    osc.start(0);
    osc.stop(meta.duration);
  } else if (presetId === 'shutter-sfx') {
    const clickBuf = offline.createBuffer(1, length, sampleRate);
    const c = clickBuf.getChannelData(0);
    for (let i = 0; i < length; i++) {
      const t = i / sampleRate;
      const burst1 = t < 0.03 ? Math.exp(-t * 140) : 0;
      const burst2 = t >= 0.075 && t < 0.12 ? Math.exp(-(t - 0.075) * 120) : 0;
      c[i] = (Math.random() * 2 - 1) * (burst1 + burst2) * 0.85;
    }
    const src = offline.createBufferSource();
    src.buffer = clickBuf;
    src.connect(offline.destination);
    src.start(0);
  } else if (presetId === 'impact-sfx') {
    const osc = offline.createOscillator();
    const gain = offline.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, 0);
    osc.frequency.exponentialRampToValueAtTime(34, 0.45);
    osc.frequency.exponentialRampToValueAtTime(24, meta.duration);
    gain.gain.setValueAtTime(0.8, 0);
    gain.gain.exponentialRampToValueAtTime(0.001, meta.duration);
    osc.connect(gain);
    gain.connect(offline.destination);
    osc.start(0);
    osc.stop(meta.duration);
  } else {
    // ding-sfx
    [880, 1318.5, 1760].forEach((f, idx) => {
      const osc = offline.createOscillator();
      const gain = offline.createGain();
      osc.type = 'sine';
      osc.frequency.value = f;
      gain.gain.setValueAtTime(0.32 / (idx + 1), 0);
      gain.gain.exponentialRampToValueAtTime(0.001, meta.duration);
      osc.connect(gain);
      gain.connect(offline.destination);
      osc.start(0);
      osc.stop(meta.duration);
    });
  }

  const rendered = await offline.startRendering();
  const wavBlob = audioBufferToWavBlob(rendered);
  const url = URL.createObjectURL(wavBlob);
  const id = `builtin_${presetId}_${Date.now()}`;
  decodedBufferCache.set(id, rendered);

  return {
    id,
    name: meta.nameAr,
    type: 'audio',
    mimeType: 'audio/wav',
    sizeBytes: wavBlob.size,
    duration: rendered.duration,
    url,
    blob: wavBlob,
    waveformPeaks: extractWaveformPeaks(rendered, 64),
    createdAt: Date.now(),
  };
}
