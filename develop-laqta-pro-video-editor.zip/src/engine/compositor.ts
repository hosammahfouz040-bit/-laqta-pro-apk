import { FILTER_PRESETS } from '../constants/presets';
import {
  ColorAdjustments,
  OverlayClip,
  TextOverlay,
  TransitionType,
  VideoClip,
  VideoEffectClip,
} from '../types/editor';

export type DrawableMedia =
  | HTMLVideoElement
  | HTMLImageElement
  | HTMLCanvasElement
  | OffscreenCanvas
  | ImageBitmap;

export interface ClipTimelineSlot {
  clip: VideoClip;
  index: number;
  startTime: number;
  endTime: number;
}

export interface FrameSourceRequest {
  clip: VideoClip;
  sourceTime: number;
}

export type FrameProvider = (
  clip: VideoClip,
  sourceTime: number
) => DrawableMedia | null;

export type OverlayMediaProvider = (
  overlay: OverlayClip,
  sourceTime: number
) => DrawableMedia | null;

class ReusableCanvasPool {
  private map = new Map<string, HTMLCanvasElement>();

  getCanvas(key: string, width: number, height: number): HTMLCanvasElement {
    let canvas = this.map.get(key);
    if (!canvas) {
      canvas = document.createElement('canvas');
      this.map.set(key, canvas);
    }
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    return canvas;
  }
}

const pool = new ReusableCanvasPool();

export function computeClipSlots(clips: VideoClip[]): ClipTimelineSlot[] {
  const slots: ClipTimelineSlot[] = [];
  let cursor = 0;
  for (let i = 0; i < clips.length; i++) {
    const dur = Math.max(0.1, clips[i].duration);
    slots.push({
      clip: clips[i],
      index: i,
      startTime: cursor,
      endTime: cursor + dur,
    });
    cursor += dur;
  }
  return slots;
}

export function computeProjectDuration(
  clips: VideoClip[],
  texts: TextOverlay[] = [],
  audioClips: { startTime: number; duration: number }[] = []
): number {
  const clipsDur = clips.reduce((acc, c) => acc + Math.max(0.1, c.duration), 0);
  if (clipsDur > 0) {
    return clipsDur;
  }
  const textMax = texts.reduce((m, t) => Math.max(m, t.startTime + t.duration), 0);
  const audioMax = audioClips.reduce(
    (m, a) => Math.max(m, a.startTime + a.duration),
    0
  );
  return Math.max(clipsDur, textMax, audioMax);
}

export interface ResolvedClipState {
  primary: FrameSourceRequest | null;
  secondary?: FrameSourceRequest | null;
  activeSlotIndex?: number;
  transitionType?: TransitionType;
  transitionProgress?: number;
}

/**
 * Resolves exact timeline state with strictly continuous 1:1 source timestamps
 * so primary video playback never jumps forward or backward even across transitions!
 */
export function resolveTimelineAtTime(
  slots: ClipTimelineSlot[],
  timeSec: number
): ResolvedClipState {
  if (slots.length === 0) {
    return { primary: null };
  }

  const totalDur = slots[slots.length - 1].endTime;
  const clampedTime = Math.max(0, Math.min(timeSec, Math.max(0, totalDur - 0.001)));

  let activeIdx = slots.length - 1;
  for (let i = 0; i < slots.length; i++) {
    if (clampedTime >= slots[i].startTime && clampedTime < slots[i].endTime) {
      activeIdx = i;
      break;
    }
  }

  const activeSlot = slots[activeIdx];
  const localTime = Math.max(0, clampedTime - activeSlot.startTime);
  const primarySourceTime = clampSourceTime(
    activeSlot.clip,
    activeSlot.clip.trimStart + localTime * (activeSlot.clip.speed || 1)
  );

  if (activeIdx > 0) {
    const prevSlot = slots[activeIdx - 1];
    const trans = activeSlot.clip.transitionIn;
    if (trans && trans.type !== 'none' && trans.duration > 0.05) {
      const maxTrans = Math.min(
        trans.duration,
        activeSlot.clip.duration * 0.75
      );
      if (localTime <= maxTrans && maxTrans > 0.04) {
        const progress = Math.max(0, Math.min(1, localTime / maxTrans));
        const prevEndSource = clampSourceTime(
          prevSlot.clip,
          prevSlot.clip.trimStart +
            Math.max(0, prevSlot.clip.duration - 0.04) *
              (prevSlot.clip.speed || 1)
        );

        return {
          secondary: { clip: prevSlot.clip, sourceTime: prevEndSource },
          primary: { clip: activeSlot.clip, sourceTime: primarySourceTime },
          activeSlotIndex: activeIdx,
          transitionType: trans.type,
          transitionProgress: progress,
        };
      }
    }
  }

  return {
    primary: { clip: activeSlot.clip, sourceTime: primarySourceTime },
    activeSlotIndex: activeIdx,
  };
}

function clampSourceTime(clip: VideoClip, rawTime: number): number {
  if (clip.type === 'image') return Math.max(0, rawTime);
  const maxT = Math.max(0, (clip.sourceDuration || clip.duration) - 0.02);
  return Math.max(0, Math.min(rawTime, maxT));
}

function getDrawableSize(media: DrawableMedia): { w: number; h: number } {
  if (media instanceof HTMLVideoElement) {
    return { w: media.videoWidth || 1280, h: media.videoHeight || 720 };
  }
  if (media instanceof HTMLImageElement) {
    return { w: media.naturalWidth || 1280, h: media.naturalHeight || 720 };
  }
  return { w: media.width || 1280, h: media.height || 720 };
}

function buildCssFilterString(adj: ColorAdjustments): string {
  const preset =
    FILTER_PRESETS.find((f) => f.id === adj.filter) || FILTER_PRESETS[0];
  const intensity =
    adj.filter === 'none' ? 0 : Math.max(0, Math.min(1, adj.filterIntensity / 100));

  const bright = Math.max(
    0.15,
    1 + adj.brightness / 100 + preset.brightness * intensity
  );
  const contrast = Math.max(
    0.15,
    1 + adj.contrast / 100 + preset.contrast * intensity
  );
  const sat = Math.max(
    0,
    (1 + adj.saturation / 100) * (1 + preset.saturation * intensity)
  );
  const sepia = Math.max(0, Math.min(1, preset.sepia * intensity));
  const hueDeg = (preset.hueRotateDeg || 0) * intensity;

  const parts: string[] = [];
  if (Math.abs(bright - 1) > 0.005) parts.push(`brightness(${bright.toFixed(3)})`);
  if (Math.abs(contrast - 1) > 0.005) parts.push(`contrast(${contrast.toFixed(3)})`);
  if (Math.abs(sat - 1) > 0.005) parts.push(`saturate(${sat.toFixed(3)})`);
  if (sepia > 0.005) parts.push(`sepia(${sepia.toFixed(3)})`);
  if (Math.abs(hueDeg) > 0.5) parts.push(`hue-rotate(${hueDeg.toFixed(1)}deg)`);
  return parts.length > 0 ? parts.join(' ') : 'none';
}

function scaleRgbaAlpha(rgba: string, factor: number): string {
  return rgba.replace(/([\d.]+)\s*\)$/, (_, a) => {
    const next = Math.max(0, Math.min(1, parseFloat(a) * factor));
    return `${next.toFixed(3)})`;
  });
}

function applyPostToneAndSharpness(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  adj: ColorAdjustments
): void {
  const preset =
    FILTER_PRESETS.find((f) => f.id === adj.filter) || FILTER_PRESETS[0];
  const intensity =
    adj.filter === 'none' ? 0 : Math.max(0, Math.min(1, adj.filterIntensity / 100));

  const tempNorm = adj.temperature / 100;
  const netWarmth = tempNorm + ((preset.tempR - preset.tempB) / 90) * intensity;

  if (Math.abs(netWarmth) > 0.02) {
    ctx.save();
    ctx.globalCompositeOperation = 'soft-light';
    if (netWarmth > 0) {
      ctx.fillStyle = `rgba(255, 166, 58, ${Math.min(0.48, netWarmth * 0.42).toFixed(3)})`;
    } else {
      ctx.fillStyle = `rgba(56, 178, 255, ${Math.min(0.48, -netWarmth * 0.42).toFixed(3)})`;
    }
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  // Green channel tint support for Matrix / Emerald / Miami filters
  if (Math.abs(preset.tempG) > 10 && intensity > 0.05) {
    ctx.save();
    ctx.globalCompositeOperation = 'soft-light';
    ctx.fillStyle =
      preset.tempG > 0
        ? `rgba(16, 225, 130, ${((preset.tempG / 120) * intensity).toFixed(3)})`
        : `rgba(232, 60, 210, ${((-preset.tempG / 120) * intensity).toFixed(3)})`;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  if (intensity > 0.05 && preset.tintTop && preset.tintBottom) {
    ctx.save();
    ctx.globalCompositeOperation = 'overlay';
    const grad = ctx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, scaleRgbaAlpha(preset.tintTop, intensity));
    grad.addColorStop(1, scaleRgbaAlpha(preset.tintBottom, intensity));
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  if (adj.sharpness > 0.5 && width > 4 && height > 4) {
    const sharpCanvas = pool.getCanvas(
      'sharp_blur_tmp',
      Math.max(2, width >> 2),
      Math.max(2, height >> 2)
    );
    const sctx = sharpCanvas.getContext('2d')!;
    sctx.drawImage(ctx.canvas, 0, 0, sharpCanvas.width, sharpCanvas.height);

    const amount = Math.min(0.85, adj.sharpness / 100);
    ctx.save();
    ctx.globalAlpha = amount * 0.55;
    ctx.globalCompositeOperation = 'hard-light';
    ctx.drawImage(ctx.canvas, 0, 0, width, height);
    ctx.globalCompositeOperation = 'difference';
    ctx.globalAlpha = amount * 0.22;
    ctx.drawImage(sharpCanvas, 0, 0, width, height);
    ctx.restore();
  }

  const vignetteStrength = preset.vignette * intensity;
  if (vignetteStrength > 0.01) {
    const cx = width / 2;
    const cy = height / 2;
    const outerR = Math.hypot(cx, cy);
    const grad = ctx.createRadialGradient(cx, cy, outerR * 0.4, cx, cy, outerR);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, `rgba(0,0,0,${vignetteStrength.toFixed(3)})`);
    ctx.save();
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }
}

function renderSingleClipToCanvas(
  bufferKey: string,
  req: FrameSourceRequest,
  media: DrawableMedia | null,
  width: number,
  height: number,
  bgColor: string
): HTMLCanvasElement {
  const buf = pool.getCanvas(bufferKey, width, height);
  const bctx = buf.getContext('2d')!;

  bctx.save();
  bctx.fillStyle = bgColor || '#000000';
  bctx.fillRect(0, 0, width, height);

  if (media) {
    const raw = getDrawableSize(media);
    const isRotated90 = req.clip.rotation === 90 || req.clip.rotation === 270;
    const effW = isRotated90 ? raw.h : raw.w;
    const effH = isRotated90 ? raw.w : raw.h;

    const filterCss = buildCssFilterString(req.clip.adjustments);
    if ('filter' in bctx) {
      bctx.filter = filterCss;
    }

    const canvasRatio = width / height;
    const mediaRatio = effW / effH;
    if (
      req.clip.fitMode === 'blur-fill' &&
      Math.abs(canvasRatio - mediaRatio) > 0.04
    ) {
      bctx.save();
      const coverScale = Math.max(width / effW, height / effH) * 1.12;
      bctx.globalAlpha = 0.42;
      const tiny = pool.getCanvas(bufferKey + '_blur', 48, 48);
      const tctx = tiny.getContext('2d')!;
      tctx.drawImage(media, 0, 0, 48, 48);
      bctx.translate(width / 2, height / 2);
      if (req.clip.flipH) bctx.scale(-1, 1);
      if (req.clip.rotation) bctx.rotate((req.clip.rotation * Math.PI) / 180);
      bctx.drawImage(
        tiny,
        (-raw.w * coverScale) / 2,
        (-raw.h * coverScale) / 2,
        raw.w * coverScale,
        raw.h * coverScale
      );
      bctx.restore();
    }

    let scale =
      req.clip.fitMode === 'cover'
        ? Math.max(width / effW, height / effH)
        : Math.min(width / effW, height / effH);

    if (req.clip.type === 'image' && req.clip.kenBurns) {
      const progress = Math.min(
        1,
        req.sourceTime / Math.max(0.5, req.clip.duration)
      );
      scale *= 1 + 0.1 * progress;
    }

    bctx.save();
    bctx.translate(width / 2, height / 2);
    if (req.clip.flipH) bctx.scale(-1, 1);
    if (req.clip.rotation) bctx.rotate((req.clip.rotation * Math.PI) / 180);
    bctx.drawImage(
      media,
      (-raw.w * scale) / 2,
      (-raw.h * scale) / 2,
      raw.w * scale,
      raw.h * scale
    );
    bctx.restore();

    if ('filter' in bctx) {
      bctx.filter = 'none';
    }
  }

  bctx.restore();

  applyPostToneAndSharpness(bctx, width, height, req.clip.adjustments);

  return buf;
}

function easeInOutCubic(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function seededRand(seed: number): number {
  const x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
}

/**
 * Renders all 30 CapCut Transitions identically in real-time preview AND in MP4 export!
 */
function renderTransitionComposite(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  canvasA: HTMLCanvasElement,
  canvasB: HTMLCanvasElement,
  type: TransitionType,
  rawProgress: number,
  timeSec: number
): void {
  const p = Math.max(0, Math.min(1, rawProgress));
  const e = easeInOutCubic(p);

  ctx.save();
  switch (type) {
    case 'fade': {
      ctx.globalAlpha = 1;
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, 0, width, height);
      break;
    }

    case 'black-fade': {
      const base = p < 0.5 ? canvasA : canvasB;
      ctx.drawImage(base, 0, 0, width, height);
      const darkness = Math.pow(1 - Math.abs(p - 0.5) * 2, 1.35);
      ctx.fillStyle = `rgba(0, 0, 0, ${Math.min(0.99, darkness).toFixed(3)})`;
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'white-fade': {
      const base = p < 0.5 ? canvasA : canvasB;
      ctx.drawImage(base, 0, 0, width, height);
      const whiteness = Math.sin(p * Math.PI);
      ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(0.92, whiteness * 0.9).toFixed(3)})`;
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'flash': {
      const base = p < 0.5 ? canvasA : canvasB;
      ctx.drawImage(base, 0, 0, width, height);
      const flashIntensity = Math.pow(1 - Math.abs(p - 0.5) * 2, 1.8);
      ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(0.96, flashIntensity).toFixed(3)})`;
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'color-burn': {
      const base = p < 0.5 ? canvasA : canvasB;
      ctx.drawImage(base, 0, 0, width, height);
      const burn = Math.sin(p * Math.PI);
      const grad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        width * 0.05,
        width / 2,
        height / 2,
        Math.hypot(width, height) * 0.7
      );
      grad.addColorStop(0, `rgba(255, 240, 170, ${(burn * 0.95).toFixed(3)})`);
      grad.addColorStop(0.5, `rgba(251, 113, 36, ${(burn * 0.85).toFixed(3)})`);
      grad.addColorStop(1, `rgba(225, 29, 72, ${(burn * 0.6).toFixed(3)})`);
      ctx.globalCompositeOperation = 'screen';
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'blur-dissolve': {
      const blurA = pool.getCanvas('trans_blur_a', 56, 56);
      const blurB = pool.getCanvas('trans_blur_b', 56, 56);
      blurA.getContext('2d')!.drawImage(canvasA, 0, 0, 56, 56);
      blurB.getContext('2d')!.drawImage(canvasB, 0, 0, 56, 56);
      const midBlur = Math.sin(p * Math.PI);
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.globalAlpha = midBlur * 0.85;
      ctx.drawImage(blurA, 0, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.globalAlpha = midBlur * 0.65;
      ctx.drawImage(blurB, 0, 0, width, height);
      break;
    }

    case 'slide': {
      const offset = width * e;
      ctx.drawImage(canvasA, -offset, 0, width, height);
      ctx.drawImage(canvasB, width - offset, 0, width, height);
      break;
    }

    case 'slide-right': {
      const offset = width * e;
      ctx.drawImage(canvasA, offset, 0, width, height);
      ctx.drawImage(canvasB, -width + offset, 0, width, height);
      break;
    }

    case 'slide-up': {
      const offsetY = height * e;
      ctx.drawImage(canvasA, 0, -offsetY, width, height);
      ctx.drawImage(canvasB, 0, height - offsetY, width, height);
      break;
    }

    case 'slide-down': {
      const offsetY = height * e;
      ctx.drawImage(canvasA, 0, offsetY, width, height);
      ctx.drawImage(canvasB, 0, -height + offsetY, width, height);
      break;
    }

    case 'diagonal-slide': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const dx = width * (1 - e);
      const dy = height * (1 - e);
      ctx.drawImage(canvasB, dx, dy, width, height);
      break;
    }

    case 'film-roll': {
      const offsetY = height * e;
      ctx.drawImage(canvasA, 0, -offsetY, width, height);
      ctx.drawImage(canvasB, 0, height - offsetY, width, height);
      const seamY = height - offsetY;
      ctx.fillStyle = '#09090B';
      ctx.fillRect(0, seamY - 12, width, 24);
      ctx.fillStyle = '#F8FAFC';
      for (let sx = 12; sx < width; sx += 28) {
        ctx.fillRect(sx, seamY - 5, 14, 10);
      }
      break;
    }

    case 'wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const wipeX = width * (1 - e);
      ctx.save();
      ctx.beginPath();
      ctx.rect(wipeX, 0, width - wipeX, height);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      ctx.fillStyle = 'rgba(0, 229, 223, 0.7)';
      ctx.fillRect(wipeX - 2, 0, 4, height);
      break;
    }

    case 'wipe-up': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const wipeY = height * (1 - e);
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, wipeY, width, height - wipeY);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      ctx.fillStyle = 'rgba(0, 229, 223, 0.7)';
      ctx.fillRect(0, wipeY - 2, width, 4);
      break;
    }

    case 'split-open': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const openW = width * e;
      const openX = (width - openW) / 2;
      ctx.save();
      ctx.beginPath();
      ctx.rect(openX, 0, openW, height);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'split-vertical': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const openH = height * e;
      const openY = (height - openH) / 2;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, openY, width, openH);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'islamic-arch-wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const aw = width * (0.2 + e * 1.15);
      const ah = height * (0.25 + e * 1.15);
      const cx = width / 2;
      const bottomY = height / 2 + ah / 2;
      const archSpringY = bottomY - ah * 0.58;
      const apexY = bottomY - ah;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx - aw / 2, bottomY);
      ctx.lineTo(cx - aw / 2, archSpringY);
      ctx.quadraticCurveTo(cx - aw * 0.42, apexY + ah * 0.12, cx, apexY);
      ctx.quadraticCurveTo(cx + aw * 0.42, apexY + ah * 0.12, cx + aw / 2, archSpringY);
      ctx.lineTo(cx + aw / 2, bottomY);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'octagram-star': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const maxR = Math.hypot(width, height) * e * 0.72;
      const cx = width / 2;
      const cy = height / 2;
      ctx.save();
      ctx.beginPath();
      // 8-pointed Islamic star (two overlapping squares rotated 45 deg)
      for (let rot = 0; rot < 2; rot++) {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate((rot * Math.PI) / 4);
        ctx.rect(-maxR, -maxR, maxR * 2, maxR * 2);
        ctx.restore();
      }
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'golden-dissolve': {
      ctx.globalAlpha = 1;
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, 0, width, height);
      const glow = Math.sin(p * Math.PI);
      ctx.globalAlpha = glow * 0.52;
      ctx.fillStyle = '#FEF08A';
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'soft-mist-fade': {
      ctx.globalAlpha = 1;
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, 0, width, height);
      const mist = Math.sin(p * Math.PI) * 0.35;
      ctx.globalAlpha = mist;
      ctx.fillStyle = '#E2E8F0';
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'wave-wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const baseY = height * (1 - e);
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(0, height);
      for (let x = 0; x <= width; x += 12) {
        const wy = baseY + Math.sin((x / width) * Math.PI * 3 + p * 6) * 26;
        ctx.lineTo(x, wy);
      }
      ctx.lineTo(width, height);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'light-sweep': {
      ctx.globalAlpha = 1;
      ctx.drawImage(canvasA, 0, 0, width, height);
      const sweepX = -width * 0.4 + width * 1.8 * e;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, Math.max(0, sweepX), height);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      const grad = ctx.createLinearGradient(sweepX - 70, 0, sweepX + 70, 0);
      grad.addColorStop(0, 'rgba(255,255,255,0)');
      grad.addColorStop(0.5, 'rgba(255,250,210,0.85)');
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(sweepX - 70, 0, 140, height);
      break;
    }

    case 'corner-reveal': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const diag = (width + height) * e;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(width, 0);
      ctx.lineTo(width - diag, 0);
      ctx.lineTo(width, diag);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'cross-zoom': {
      const zOut = 1 + e * 1.6;
      ctx.save();
      ctx.globalAlpha = 1 - e;
      ctx.translate(width / 2, height / 2);
      ctx.scale(zOut, zOut);
      ctx.drawImage(canvasA, -width / 2, -height / 2, width, height);
      ctx.restore();

      const zIn = 2.1 - 1.1 * e;
      ctx.save();
      ctx.globalAlpha = e;
      ctx.translate(width / 2, height / 2);
      ctx.scale(zIn, zIn);
      ctx.drawImage(canvasB, -width / 2, -height / 2, width, height);
      ctx.restore();
      break;
    }

    case 'curtain-open': {
      ctx.drawImage(canvasB, 0, 0, width, height);
      const half = width / 2;
      const shift = half * e;
      ctx.drawImage(canvasA, 0, 0, half, height, -shift, 0, half, height);
      ctx.drawImage(canvasA, half, 0, half, height, half + shift, 0, half, height);
      break;
    }

    case 'double-doors': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const half = width / 2;
      const inShift = half * (1 - e);
      ctx.drawImage(canvasB, 0, 0, half, height, -inShift, 0, half, height);
      ctx.drawImage(canvasB, half, 0, half, height, half + inShift, 0, half, height);
      break;
    }

    case 'iris-rectangle': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const rw = width * e;
      const rh = height * e;
      ctx.save();
      ctx.beginPath();
      ctx.rect((width - rw) / 2, (height - rh) / 2, rw, rh);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'spiral-spin': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.save();
      ctx.globalAlpha = e;
      ctx.translate(width / 2, height / 2);
      ctx.rotate((1 - e) * Math.PI * 1.75);
      ctx.scale(e, e);
      ctx.drawImage(canvasB, -width / 2, -height / 2, width, height);
      ctx.restore();
      break;
    }

    case 'nature-breeze': {
      const drift = width * 0.28 * e;
      ctx.globalAlpha = 1;
      ctx.drawImage(canvasA, -drift, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, width * 0.22 * (1 - e), 0, width, height);
      break;
    }

    case 'horizon-rise': {
      const rise = height * 0.35 * (1 - e);
      ctx.drawImage(canvasA, 0, -height * 0.15 * e, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, rise, width, height);
      ctx.globalAlpha = Math.sin(p * Math.PI) * 0.36;
      ctx.fillStyle = '#FDE68A';
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'water-drop-ripple': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const maxR = Math.hypot(width / 2, height / 2);
      const rNow = Math.max(4, maxR * e);
      ctx.save();
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, rNow, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      ctx.save();
      ctx.strokeStyle = `rgba(125, 211, 252, ${(0.7 * (1 - p)).toFixed(2)})`;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, rNow, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      break;
    }

    case 'arch-double-doors': {
      ctx.drawImage(canvasB, 0, 0, width, height);
      const half = width / 2;
      const move = half * e;
      ctx.drawImage(canvasA, 0, 0, half, height, -move, 0, half, height);
      ctx.drawImage(canvasA, half, 0, half, height, half + move, 0, half, height);
      ctx.fillStyle = `rgba(250, 204, 21, ${(0.85 * (1 - p)).toFixed(2)})`;
      ctx.fillRect(half - move - 2, 0, 4, height);
      ctx.fillRect(half + move - 2, 0, 4, height);
      break;
    }

    case 'page-curl': {
      ctx.drawImage(canvasB, 0, 0, width, height);
      const remainW = width * (1 - e);
      if (remainW > 2) {
        ctx.drawImage(canvasA, 0, 0, remainW, height, 0, 0, remainW, height);
        const curlW = Math.min(48, remainW * 0.25);
        const curlGrad = ctx.createLinearGradient(
          remainW - curlW,
          0,
          remainW + 12,
          0
        );
        curlGrad.addColorStop(0, 'rgba(0,0,0,0)');
        curlGrad.addColorStop(0.75, 'rgba(255,250,235,0.45)');
        curlGrad.addColorStop(1, 'rgba(0,0,0,0.55)');
        ctx.fillStyle = curlGrad;
        ctx.fillRect(remainW - curlW, 0, curlW + 12, height);
      }
      break;
    }

    case 'starlight-flash': {
      const base = p < 0.5 ? canvasA : canvasB;
      ctx.drawImage(base, 0, 0, width, height);
      const peak = Math.sin(p * Math.PI);
      const starGrad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        4,
        width / 2,
        height / 2,
        Math.hypot(width, height) * 0.55
      );
      starGrad.addColorStop(0, `rgba(255, 255, 255, ${(0.95 * peak).toFixed(2)})`);
      starGrad.addColorStop(0.45, `rgba(254, 240, 138, ${(0.55 * peak).toFixed(2)})`);
      starGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = starGrad;
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'cinematic-dip-white': {
      const base = p < 0.5 ? canvasA : canvasB;
      ctx.drawImage(base, 0, 0, width, height);
      const dip = Math.pow(Math.sin(p * Math.PI), 1.3);
      ctx.fillStyle = `rgba(248, 250, 252, ${dip.toFixed(3)})`;
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'luma-soft-wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const edgeX = width * e;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, edgeX, height);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      const feather = ctx.createLinearGradient(edgeX - 45, 0, edgeX + 45, 0);
      feather.addColorStop(0, 'rgba(255,255,255,0)');
      feather.addColorStop(0.5, 'rgba(255,255,255,0.22)');
      feather.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = feather;
      ctx.fillRect(edgeX - 45, 0, 90, height);
      break;
    }

    case 'three-panel-slide': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const panelH = height / 3;
      for (let i = 0; i < 3; i++) {
        const localP = Math.max(0, Math.min(1, e * 1.3 - i * 0.15));
        const dir = i % 2 === 0 ? 1 : -1;
        const dx = dir * width * (1 - localP);
        ctx.drawImage(
          canvasB,
          0,
          i * panelH,
          width,
          panelH,
          dx,
          i * panelH,
          width,
          panelH
        );
      }
      break;
    }

    case 'zoom-rotate-smooth': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.save();
      ctx.globalAlpha = e;
      ctx.translate(width / 2, height / 2);
      ctx.rotate(-(1 - e) * 0.35);
      const sc = 0.78 + 0.22 * e;
      ctx.scale(sc, sc);
      ctx.drawImage(canvasB, -width / 2, -height / 2, width, height);
      ctx.restore();
      break;
    }

    case 'vertical-curtain': {
      ctx.drawImage(canvasB, 0, 0, width, height);
      const hh = height / 2;
      const moveY = hh * e;
      ctx.drawImage(canvasA, 0, 0, width, hh, 0, -moveY, width, hh);
      ctx.drawImage(canvasA, 0, hh, width, hh, 0, hh + moveY, width, hh);
      break;
    }

    case 'diagonal-split': {
      ctx.drawImage(canvasB, 0, 0, width, height);
      const shift = width * e;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(width, 0);
      ctx.lineTo(0, height);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasA, -shift, -shift * 0.5, width, height);
      ctx.restore();

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(width, 0);
      ctx.lineTo(width, height);
      ctx.lineTo(0, height);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasA, shift, shift * 0.5, width, height);
      ctx.restore();
      break;
    }

    case 'hexagon-iris': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const rHex = Math.hypot(width / 2, height / 2) * e * 1.1;
      const cx = width / 2;
      const cy = height / 2;
      ctx.save();
      ctx.beginPath();
      for (let s = 0; s < 6; s++) {
        const ang = (s * Math.PI) / 3;
        const px = cx + Math.cos(ang) * rHex;
        const py = cy + Math.sin(ang) * rHex;
        if (s === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'cross-wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const armW = width * e;
      const armH = height * e;
      ctx.save();
      ctx.beginPath();
      ctx.rect((width - armW) / 2, 0, armW, height);
      ctx.rect(0, (height - armH) / 2, width, armH);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'crescent-moon-wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const rArc = Math.hypot(width, height) * e * 1.15;
      ctx.save();
      ctx.beginPath();
      ctx.arc(width * 0.85, height * 0.15, Math.max(4, rArc), 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'emerald-mist': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.globalAlpha = Math.sin(p * Math.PI) * 0.42;
      ctx.fillStyle = '#064E3B';
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'sunbeam-sweep': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const beamX = width * e;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, beamX, height);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      const g = ctx.createLinearGradient(beamX - 60, 0, beamX + 60, 0);
      g.addColorStop(0, 'rgba(253,224,71,0)');
      g.addColorStop(0.5, 'rgba(253,224,71,0.75)');
      g.addColorStop(1, 'rgba(253,224,71,0)');
      ctx.fillStyle = g;
      ctx.fillRect(beamX - 60, 0, 120, height);
      break;
    }

    case 'sand-breeze': {
      const dx = width * 0.32 * e;
      ctx.drawImage(canvasA, dx, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, -width * 0.25 * (1 - e), 0, width, height);
      ctx.globalAlpha = Math.sin(p * Math.PI) * 0.28;
      ctx.fillStyle = '#F59E0B';
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'warm-glow-fade': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.globalAlpha = Math.sin(p * Math.PI) * 0.45;
      ctx.fillStyle = '#FDBA74';
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'cool-shimmer-fade': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.globalAlpha = Math.sin(p * Math.PI) * 0.42;
      ctx.fillStyle = '#BAE6FD';
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'velvet-dark-dip': {
      const base = p < 0.5 ? canvasA : canvasB;
      ctx.drawImage(base, 0, 0, width, height);
      ctx.fillStyle = `rgba(9, 11, 20, ${Math.pow(Math.sin(p * Math.PI), 1.2).toFixed(3)})`;
      ctx.fillRect(0, 0, width, height);
      break;
    }

    case 'four-slice-slide': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const sliceH = height / 4;
      for (let i = 0; i < 4; i++) {
        const lp = Math.max(0, Math.min(1, e * 1.25 - i * 0.08));
        const dx = (i % 2 === 0 ? 1 : -1) * width * (1 - lp);
        ctx.drawImage(canvasB, 0, i * sliceH, width, sliceH, dx, i * sliceH, width, sliceH);
      }
      break;
    }

    case 'whip-pan-blur': {
      const offset = width * e;
      ctx.drawImage(canvasA, -offset, 0, width, height);
      ctx.drawImage(canvasB, width - offset, 0, width, height);
      ctx.globalAlpha = Math.sin(p * Math.PI) * 0.35;
      ctx.drawImage(canvasB, width - offset - 28, 0, width, height);
      break;
    }

    case 'accordion-fold': {
      const wA = Math.max(1, width * (1 - e));
      const wB = Math.max(1, width * e);
      ctx.drawImage(canvasA, 0, 0, width, height, 0, 0, wA, height);
      ctx.drawImage(canvasB, 0, 0, width, height, wA, 0, wB, height);
      break;
    }

    case 'double-ring-iris': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const maxR = Math.hypot(width / 2, height / 2);
      ctx.save();
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, maxR * e, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      ctx.strokeStyle = `rgba(255,255,255,${(0.6 * (1 - p)).toFixed(2)})`;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, maxR * e * 0.72, 0, Math.PI * 2);
      ctx.stroke();
      break;
    }

    case 'octagon-iris': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const rOct = Math.hypot(width / 2, height / 2) * e * 1.08;
      ctx.save();
      ctx.beginPath();
      for (let s = 0; s < 8; s++) {
        const ang = (s * Math.PI) / 4;
        const px = width / 2 + Math.cos(ang) * rOct;
        const py = height / 2 + Math.sin(ang) * rOct;
        if (s === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'diagonal-grid-wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const cols = 6;
      const rows = 8;
      const cw = width / cols;
      const ch = height / rows;
      ctx.save();
      ctx.beginPath();
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const delay = ((r + c) / (rows + cols)) * 0.45;
          const cp = Math.max(0, Math.min(1, (e * 1.45) - delay));
          if (cp > 0) ctx.rect(c * cw, r * ch, cw * cp, ch * cp);
        }
      }
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'venetian-diagonal': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const count = 9;
      const band = (width + height) / count;
      ctx.save();
      ctx.beginPath();
      for (let i = 0; i < count; i++) {
        const pos = i * band - height;
        ctx.moveTo(pos, 0);
        ctx.lineTo(pos + band * e, 0);
        ctx.lineTo(pos + height + band * e, height);
        ctx.lineTo(pos + height, height);
        ctx.closePath();
      }
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'prism-shift-trans': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const shift = Math.sin(p * Math.PI) * width * 0.06;
      ctx.globalAlpha = e;
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.35 * Math.sin(p * Math.PI);
      ctx.drawImage(canvasB, shift, 0, width, height);
      ctx.drawImage(canvasA, -shift, 0, width, height);
      ctx.restore();
      break;
    }

    case 'scanline-wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const sy = height * e;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, width, sy);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      ctx.fillStyle = '#00E5DF';
      ctx.fillRect(0, sy - 2, width, 4);
      break;
    }

    case 'circle-iris': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const maxRadius = Math.hypot(width / 2, height / 2);
      ctx.save();
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, Math.max(2, maxRadius * e), 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'diamond-open': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const rx = width * e * 1.1;
      const ry = height * e * 1.1;
      const cx = width / 2;
      const cy = height / 2;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, cy - ry);
      ctx.lineTo(cx + rx, cy);
      ctx.lineTo(cx, cy + ry);
      ctx.lineTo(cx - rx, cy);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'clock-radial': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const maxR = Math.hypot(width, height);
      const cx = width / 2;
      const cy = height / 2;
      const startAngle = -Math.PI / 2;
      const endAngle = startAngle + Math.PI * 2 * e;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, maxR, startAngle, endAngle);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'blinds': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const blindCount = 8;
      const stripeH = height / blindCount;
      ctx.save();
      ctx.beginPath();
      for (let i = 0; i < blindCount; i++) {
        ctx.rect(0, i * stripeH, width, stripeH * e);
      }
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'vertical-bars': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const cols = 7;
      const colW = width / cols;
      ctx.save();
      ctx.beginPath();
      for (let c = 0; c < cols; c++) {
        ctx.rect(c * colW, 0, colW * e, height);
      }
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'checkerboard-wipe': {
      ctx.drawImage(canvasA, 0, 0, width, height);
      const cols = 6;
      const rows = 8;
      const cw = width / cols;
      const ch = height / rows;
      ctx.save();
      ctx.beginPath();
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const stagger = ((r + c) % 2) * 0.16;
          const cellP = Math.max(0, Math.min(1, (e * 1.18) - stagger));
          if (cellP > 0) {
            ctx.rect(
              c * cw + (cw * (1 - cellP)) / 2,
              r * ch + (ch * (1 - cellP)) / 2,
              cw * cellP,
              ch * cellP
            );
          }
        }
      }
      ctx.clip();
      ctx.drawImage(canvasB, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'zoom-in': {
      const scaleA = 1 + e * 1.15;
      ctx.save();
      ctx.globalAlpha = 1 - e * 0.85;
      ctx.translate(width / 2, height / 2);
      ctx.scale(scaleA, scaleA);
      ctx.drawImage(canvasA, -width / 2, -height / 2, width, height);
      ctx.restore();

      const scaleB = 0.65 + 0.35 * e;
      ctx.save();
      ctx.globalAlpha = e;
      ctx.translate(width / 2, height / 2);
      ctx.scale(scaleB, scaleB);
      ctx.drawImage(canvasB, -width / 2, -height / 2, width, height);
      ctx.restore();
      break;
    }

    case 'zoom-out': {
      ctx.drawImage(canvasB, 0, 0, width, height);
      const scaleA = Math.max(0.2, 1 - e * 0.72);
      ctx.save();
      ctx.globalAlpha = 1 - e;
      ctx.translate(width / 2, height / 2);
      ctx.scale(scaleA, scaleA);
      ctx.drawImage(canvasA, -width / 2, -height / 2, width, height);
      ctx.restore();
      break;
    }

    case 'rotate': {
      ctx.save();
      ctx.globalAlpha = 1 - e;
      ctx.translate(width / 2, height / 2);
      ctx.rotate(e * Math.PI * 0.55);
      ctx.scale(1 - e * 0.4, 1 - e * 0.4);
      ctx.drawImage(canvasA, -width / 2, -height / 2, width, height);
      ctx.restore();

      ctx.save();
      ctx.globalAlpha = e;
      ctx.translate(width / 2, height / 2);
      ctx.rotate(-(1 - e) * Math.PI * 0.55);
      ctx.scale(0.6 + e * 0.4, 0.6 + e * 0.4);
      ctx.drawImage(canvasB, -width / 2, -height / 2, width, height);
      ctx.restore();
      break;
    }

    case 'spin-zoom': {
      ctx.save();
      ctx.globalAlpha = 1 - e;
      ctx.translate(width / 2, height / 2);
      ctx.rotate(e * Math.PI * 1.15);
      ctx.scale(1 + e * 0.9, 1 + e * 0.9);
      ctx.drawImage(canvasA, -width / 2, -height / 2, width, height);
      ctx.restore();

      ctx.save();
      ctx.globalAlpha = e;
      ctx.translate(width / 2, height / 2);
      ctx.rotate(-(1 - e) * Math.PI * 1.15);
      ctx.scale(0.35 + e * 0.65, 0.35 + e * 0.65);
      ctx.drawImage(canvasB, -width / 2, -height / 2, width, height);
      ctx.restore();
      break;
    }

    case 'flip-3d': {
      ctx.fillStyle = '#050608';
      ctx.fillRect(0, 0, width, height);
      const isSecondHalf = p >= 0.5;
      const card = isSecondHalf ? canvasB : canvasA;
      const scaleX = Math.max(0.04, Math.abs(Math.cos(p * Math.PI)));
      ctx.save();
      ctx.translate(width / 2, height / 2);
      ctx.scale(scaleX, 0.92 + 0.08 * scaleX);
      ctx.drawImage(card, -width / 2, -height / 2, width, height);
      ctx.restore();
      break;
    }

    case 'pixelate-trans': {
      const base = p < 0.5 ? canvasA : canvasB;
      const pixelPeak = Math.sin(p * Math.PI);
      const grid = Math.max(12, Math.round(90 - 74 * pixelPeak));
      const tiny = pool.getCanvas('trans_pix', grid, Math.max(12, Math.round((height / width) * grid)));
      const tctx = tiny.getContext('2d')!;
      tctx.imageSmoothingEnabled = false;
      tctx.drawImage(base, 0, 0, tiny.width, tiny.height);
      ctx.save();
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(tiny, 0, 0, width, height);
      ctx.restore();
      break;
    }

    case 'glitch': {
      const base = p < 0.5 ? canvasA : canvasB;
      const alt = p < 0.5 ? canvasB : canvasA;
      ctx.drawImage(base, 0, 0, width, height);

      const glitchPower = Math.sin(p * Math.PI);
      const sliceCount = 12;
      const seedBase = Math.floor(timeSec * 30);

      for (let s = 0; s < sliceCount; s++) {
        const r1 = seededRand(seedBase + s * 7.13);
        const r2 = seededRand(seedBase + s * 3.71);
        const r3 = seededRand(seedBase + s * 11.9);
        const sliceY = Math.floor(r1 * height);
        const sliceH = Math.max(6, Math.floor(r2 * (height / 7) * glitchPower));
        const shiftX = (r3 - 0.5) * width * 0.24 * glitchPower;

        const sourceSlice = r2 > 0.45 ? alt : base;
        ctx.drawImage(
          sourceSlice,
          0,
          sliceY,
          width,
          sliceH,
          shiftX,
          sliceY,
          width,
          sliceH
        );
      }

      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.28 * glitchPower;
      ctx.drawImage(alt, width * 0.025 * glitchPower, 0, width, height);
      ctx.fillStyle = `rgba(0, 229, 255, ${(0.14 * glitchPower).toFixed(3)})`;
      ctx.fillRect(-width * 0.02 * glitchPower, 0, width, height);
      ctx.restore();
      break;
    }

    default:
      ctx.drawImage(canvasB, 0, 0, width, height);
  }
  ctx.restore();
}

export function renderPictureInPictureOverlays(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  overlays: OverlayClip[],
  timeSec: number,
  getOverlayMedia?: OverlayMediaProvider,
  selectedOverlayId?: string | null
): void {
  if (!overlays || overlays.length === 0 || !getOverlayMedia) return;

  for (const ov of overlays) {
    if (timeSec < ov.startTime || timeSec > ov.startTime + Math.max(0.05, ov.duration)) {
      continue;
    }
    const localSourceT = ov.trimStart + (timeSec - ov.startTime);
    const media = getOverlayMedia(ov, Math.max(0, localSourceT));
    if (!media) continue;

    const raw = getDrawableSize(media);
    const targetW = Math.max(40, (ov.scale / 100) * width);
    const targetH = Math.max(40, (raw.h / Math.max(1, raw.w)) * targetW);
    const cx = (ov.x / 100) * width;
    const cy = (ov.y / 100) * height;

    ctx.save();
    ctx.globalAlpha = Math.max(0.05, Math.min(1, (ov.opacity ?? 100) / 100));
    ctx.translate(cx, cy);

    const isCircle = ov.borderRadius >= 500;
    const drawW = isCircle ? Math.min(targetW, targetH) : targetW;
    const drawH = isCircle ? drawW : targetH;

    ctx.save();
    if (isCircle) {
      ctx.beginPath();
      ctx.arc(0, 0, drawW / 2, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
    } else if (ov.borderRadius > 0) {
      drawRoundedRect(ctx, -drawW / 2, -drawH / 2, drawW, drawH, ov.borderRadius);
      ctx.clip();
    }

    const coverScale = Math.max(drawW / raw.w, drawH / raw.h);
    ctx.drawImage(
      media,
      (-raw.w * coverScale) / 2,
      (-raw.h * coverScale) / 2,
      raw.w * coverScale,
      raw.h * coverScale
    );
    ctx.restore();

    if (selectedOverlayId && selectedOverlayId === ov.id) {
      ctx.strokeStyle = '#00E5DF';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 4]);
      drawRoundedRect(
        ctx,
        -drawW / 2 - 4,
        -drawH / 2 - 4,
        drawW + 8,
        drawH + 8,
        isCircle ? drawW : Math.max(8, ov.borderRadius)
      );
      ctx.stroke();
    } else if (isCircle) {
      ctx.strokeStyle = 'rgba(255,255,255,0.85)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, drawW / 2, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.restore();
  }
}

function drawFourPointStar(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  outerR: number,
  color: string,
  alpha: number
): void {
  const innerR = outerR * 0.22;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  ctx.beginPath();
  for (let i = 0; i < 8; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const angle = (i * Math.PI) / 4;
    const px = cx + Math.cos(angle) * r;
    const py = cy + Math.sin(angle) * r;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/**
 * Renders all 33 Real CapCut Purple-Track Video Effects identically in live preview & MP4 export!
 */
export function renderActiveVideoEffects(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  effects: VideoEffectClip[],
  timeSec: number
): void {
  if (!effects || effects.length === 0) return;

  const activeEffects = effects.filter(
    (ef) => timeSec >= ef.startTime && timeSec <= ef.startTime + ef.duration
  );
  if (activeEffects.length === 0) return;

  const snap = pool.getCanvas('fx_stage_copy', width, height);
  const sctx = snap.getContext('2d')!;

  for (const fx of activeEffects) {
    const power = Math.max(0.1, Math.min(1, (fx.intensity ?? 80) / 100));
    const localT = timeSec - fx.startTime;

    switch (fx.effectType) {
      case 'islamic-arch': {
        // Ornate Golden Islamic Pointed Mihrab Arch Border + Hanging Star Lantern
        const pad = Math.round(Math.min(width, height) * 0.045);
        const cx = width / 2;
        const topApex = pad * 1.1;
        const archShoulder = height * 0.24;
        const bottomY = height - pad;

        ctx.save();
        // Subtle dark vignette outside arch corners for regal focus
        const outerGrad = ctx.createRadialGradient(
          cx,
          height * 0.5,
          Math.min(width, height) * 0.32,
          cx,
          height * 0.5,
          Math.hypot(width, height) * 0.65
        );
        outerGrad.addColorStop(0, 'rgba(0,0,0,0)');
        outerGrad.addColorStop(1, `rgba(2, 6, 23, ${(0.55 * power).toFixed(2)})`);
        ctx.fillStyle = outerGrad;
        ctx.fillRect(0, 0, width, height);

        const strokeArchPath = (inset: number, lineW: number, color: string) => {
          ctx.beginPath();
          ctx.moveTo(pad + inset, bottomY - inset);
          ctx.lineTo(pad + inset, archShoulder);
          ctx.quadraticCurveTo(
            pad + inset + width * 0.04,
            topApex + inset + height * 0.05,
            cx,
            topApex + inset
          );
          ctx.quadraticCurveTo(
            width - pad - inset - width * 0.04,
            topApex + inset + height * 0.05,
            width - pad - inset,
            archShoulder
          );
          ctx.lineTo(width - pad - inset, bottomY - inset);
          ctx.closePath();
          ctx.strokeStyle = color;
          ctx.lineWidth = lineW;
          ctx.stroke();
        };

        strokeArchPath(0, Math.max(3, width * 0.006), `rgba(250, 204, 21, ${(0.92 * power).toFixed(2)})`);
        strokeArchPath(Math.round(pad * 0.35), 1.5, `rgba(254, 240, 138, ${(0.65 * power).toFixed(2)})`);

        // Gently swaying golden lantern star suspended from Mihrab apex
        const sway = Math.sin(localT * 1.6) * (width * 0.015);
        const lx = cx + sway;
        const ly = topApex + height * 0.065;
        ctx.strokeStyle = `rgba(253, 224, 71, ${(0.75 * power).toFixed(2)})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(cx, topApex);
        ctx.lineTo(lx, ly);
        ctx.stroke();
        drawFourPointStar(ctx, lx, ly + 8, Math.max(10, width * 0.025), '#FDE047', 0.9 * power);
        ctx.restore();
        break;
      }

      case 'quran-frame': {
        // Double-line Ornate Golden Mushaf Border with Corner Medallions
        const m = Math.round(Math.min(width, height) * 0.042);
        ctx.save();
        ctx.strokeStyle = `rgba(250, 204, 21, ${(0.88 * power).toFixed(2)})`;
        ctx.lineWidth = Math.max(2.5, width * 0.005);
        drawRoundedRect(ctx, m, m, width - m * 2, height - m * 2, 16);
        ctx.stroke();

        ctx.strokeStyle = `rgba(254, 249, 195, ${(0.6 * power).toFixed(2)})`;
        ctx.lineWidth = 1.4;
        drawRoundedRect(
          ctx,
          m + 7,
          m + 7,
          width - (m + 7) * 2,
          height - (m + 7) * 2,
          12
        );
        ctx.stroke();

        // 4 Golden 8-point rosette stars at corners
        const corners = [
          [m + 3, m + 3],
          [width - m - 3, m + 3],
          [m + 3, height - m - 3],
          [width - m - 3, height - m - 3],
        ];
        for (const [cx, cy] of corners) {
          drawFourPointStar(ctx, cx, cy, Math.max(9, width * 0.02), '#FACC15', 0.92 * power);
        }
        ctx.restore();
        break;
      }

      case 'crescent-lanterns': {
        // Glowing Golden Crescent + Hanging Star Strings along top sky
        ctx.save();
        for (let i = 0; i < 5; i++) {
          const x = width * (0.12 + i * 0.19) + Math.sin(localT * 1.8 + i) * 5;
          const drop = height * (0.07 + (i % 2) * 0.045);
          ctx.strokeStyle = `rgba(253, 224, 71, ${(0.6 * power).toFixed(2)})`;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, drop);
          ctx.stroke();
          drawFourPointStar(
            ctx,
            x,
            drop + 6,
            (10 + (i % 2) * 5) * power,
            '#FEF08A',
            0.88 * power
          );
        }
        ctx.restore();
        break;
      }

      case 'celestial-rays': {
        // Soft descending volumetric rays of light from top center
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        for (let r = 0; r < 4; r++) {
          const spread = width * (0.15 + r * 0.22) + Math.sin(localT + r) * 25;
          const grad = ctx.createLinearGradient(width * 0.5, 0, spread, height * 0.85);
          grad.addColorStop(0, `rgba(254, 249, 195, ${(0.22 * power).toFixed(3)})`);
          grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.moveTo(width * 0.42, 0);
          ctx.lineTo(width * 0.58, 0);
          ctx.lineTo(spread + width * 0.18, height);
          ctx.lineTo(spread - width * 0.18, height);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'bokeh-orbs': {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        for (let b = 0; b < 14; b++) {
          const bx = (seededRand(b * 11.7) * width + Math.sin(localT * 0.9 + b) * 30 + width) % width;
          const by = height - ((seededRand(b * 23.1) * height + localT * 28) % height);
          const rad = (18 + (b % 4) * 16) * power;
          const orb = ctx.createRadialGradient(bx, by, 2, bx, by, rad);
          orb.addColorStop(0, `rgba(253, 224, 71, ${(0.32 * power).toFixed(3)})`);
          orb.addColorStop(1, 'rgba(251, 146, 60, 0)');
          ctx.fillStyle = orb;
          ctx.beginPath();
          ctx.arc(bx, by, rad, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'morning-mist': {
        const mistGrad = ctx.createLinearGradient(0, height * 0.45, 0, height);
        mistGrad.addColorStop(0, 'rgba(226, 232, 240, 0)');
        mistGrad.addColorStop(1, `rgba(226, 232, 240, ${(0.36 * power).toFixed(3)})`);
        ctx.save();
        ctx.fillStyle = mistGrad;
        ctx.fillRect(0, height * 0.45, width, height * 0.55);
        ctx.restore();
        break;
      }

      case 'water-ripple': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const startY = Math.floor(height * 0.68);
        for (let y = startY; y < height; y += 4) {
          const dx = Math.sin((y - startY) * 0.14 - localT * 7) * 9 * power;
          ctx.drawImage(snap, 0, y, width, 4, dx, y, width, 4);
        }
        break;
      }

      case 'slow-zoom-in': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const prog = Math.min(1, localT / Math.max(0.5, fx.duration));
        const sc = 1 + 0.14 * power * prog;
        ctx.save();
        ctx.translate(width / 2, height / 2);
        ctx.scale(sc, sc);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'gold-shimmer': {
        const sx = ((localT * 0.65) % 1.6) * width - width * 0.3;
        const grad = ctx.createLinearGradient(sx - 90, 0, sx + 90, height * 0.5);
        grad.addColorStop(0, 'rgba(253, 224, 71, 0)');
        grad.addColorStop(0.5, `rgba(254, 240, 138, ${(0.34 * power).toFixed(3)})`);
        grad.addColorStop(1, 'rgba(253, 224, 71, 0)');
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'edge-glow-cyan': {
        const pulse = 0.65 + 0.35 * Math.sin(localT * 4);
        const eg = ctx.createRadialGradient(
          width / 2,
          height / 2,
          Math.min(width, height) * 0.34,
          width / 2,
          height / 2,
          Math.hypot(width / 2, height / 2)
        );
        eg.addColorStop(0, 'rgba(0, 229, 223, 0)');
        eg.addColorStop(1, `rgba(0, 229, 223, ${(0.45 * power * pulse).toFixed(3)})`);
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = eg;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'cinema-scope-gold': {
        const barH = Math.round(height * 0.11 * power);
        ctx.save();
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, width, barH);
        ctx.fillRect(0, height - barH, width, barH);
        ctx.fillStyle = '#FACC15';
        ctx.fillRect(0, barH - 2, width, 2);
        ctx.fillRect(0, height - barH, width, 2);
        ctx.restore();
        break;
      }

      case 'polaroid-frame': {
        const pSide = Math.round(width * 0.05);
        const pBottom = Math.round(height * 0.13);
        ctx.save();
        ctx.fillStyle = '#F8FAFC';
        ctx.fillRect(0, 0, width, pSide);
        ctx.fillRect(0, 0, pSide, height);
        ctx.fillRect(width - pSide, 0, pSide, height);
        ctx.fillRect(0, height - pBottom, width, pBottom);
        ctx.restore();
        break;
      }

      case 'split-diagonal': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(width, 0);
        ctx.lineTo(0, height);
        ctx.lineTo(width, height);
        ctx.closePath();
        ctx.clip();
        ctx.translate(width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(snap, 0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'recitation-waveform': {
        // Live symmetric audio equalizer bars gracefully animating along bottom above reciter badge
        const bars = 28;
        const totalW = width * 0.56;
        const startX = (width - totalW) / 2;
        const stepX = totalW / bars;
        const baseY = height * 0.81;
        ctx.save();
        for (let b = 0; b < bars; b++) {
          const centerDist = 1 - Math.abs(b - bars / 2) / (bars / 2);
          const wave =
            0.25 +
            0.75 *
              Math.abs(
                Math.sin(localT * 6.5 + b * 0.55) *
                  Math.cos(localT * 3.1 - b * 0.3)
              );
          const barH = Math.max(4, height * 0.055 * wave * centerDist * power);
          ctx.fillStyle = `rgba(250, 204, 21, ${(0.82 * power).toFixed(2)})`;
          drawRoundedRect(
            ctx,
            startX + b * stepX,
            baseY - barH / 2,
            Math.max(3, stepX * 0.58),
            barH,
            3
          );
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'ornate-corners': {
        const m = Math.round(Math.min(width, height) * 0.045);
        const arm = Math.round(Math.min(width, height) * 0.09);
        ctx.save();
        ctx.strokeStyle = `rgba(250, 204, 21, ${(0.88 * power).toFixed(2)})`;
        ctx.lineWidth = Math.max(2.5, Math.min(width, height) * 0.005);
        const drawCorner = (cx: number, cy: number, sx: number, sy: number) => {
          ctx.beginPath();
          ctx.moveTo(cx, cy + sy * arm);
          ctx.lineTo(cx, cy);
          ctx.lineTo(cx + sx * arm, cy);
          ctx.stroke();
          drawFourPointStar(
            ctx,
            cx + sx * 10,
            cy + sy * 10,
            Math.max(8, Math.min(width, height) * 0.018),
            '#FDE047',
            0.9 * power
          );
        };
        drawCorner(m, m, 1, 1);
        drawCorner(width - m, m, -1, 1);
        drawCorner(m, height - m, 1, -1);
        drawCorner(width - m, height - m, -1, -1);
        ctx.restore();
        break;
      }

      case 'aurora-lights': {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        for (let band = 0; band < 3; band++) {
          const yCenter =
            height * (0.18 + band * 0.1) +
            Math.sin(localT * 1.4 + band) * height * 0.04;
          const grad = ctx.createLinearGradient(0, yCenter - 70, width, yCenter + 90);
          grad.addColorStop(0, `rgba(16, 185, 129, ${(0.24 * power).toFixed(3)})`);
          grad.addColorStop(0.5, `rgba(6, 182, 212, ${(0.28 * power).toFixed(3)})`);
          grad.addColorStop(1, `rgba(139, 92, 246, ${(0.20 * power).toFixed(3)})`);
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.moveTo(0, yCenter);
          for (let x = 0; x <= width; x += 24) {
            ctx.lineTo(
              x,
              yCenter + Math.sin((x / width) * Math.PI * 3 + localT * 2 + band) * 32
            );
          }
          ctx.lineTo(width, yCenter + 95);
          ctx.lineTo(0, yCenter + 95);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'fireflies-forest': {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        for (let f = 0; f < 24; f++) {
          const fxX =
            (seededRand(f * 13.7) * width +
              Math.sin(localT * 1.5 + f) * 34 +
              width) %
            width;
          const fxY =
            (seededRand(f * 29.3) * height +
              Math.cos(localT * 1.2 + f * 1.7) * 28 +
              height) %
            height;
          const blink = 0.25 + 0.75 * Math.pow(Math.max(0, Math.sin(localT * 3 + f)), 2);
          const rad = (6 + (f % 3) * 4) * power;
          const g = ctx.createRadialGradient(fxX, fxY, 1, fxX, fxY, rad);
          g.addColorStop(0, `rgba(217, 249, 157, ${(0.9 * blink * power).toFixed(2)})`);
          g.addColorStop(1, 'rgba(132, 204, 22, 0)');
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(fxX, fxY, rad, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'falling-leaves': {
        ctx.save();
        for (let i = 0; i < 20; i++) {
          const lx =
            (seededRand(i * 9.1) * width +
              Math.sin(localT * 2.1 + i) * 36 +
              width) %
            width;
          const ly =
            (seededRand(i * 17.5) * height + localT * (68 + (i % 4) * 18)) %
            height;
          ctx.save();
          ctx.translate(lx, ly);
          ctx.rotate(localT * 1.8 + i);
          ctx.fillStyle =
            i % 2 === 0
              ? `rgba(245, 158, 11, ${(0.82 * power).toFixed(2)})`
              : `rgba(234, 88, 12, ${(0.78 * power).toFixed(2)})`;
          ctx.beginPath();
          ctx.ellipse(0, 0, 8 * power, 4.5 * power, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
        ctx.restore();
        break;
      }

      case 'sakura-petals': {
        ctx.save();
        for (let i = 0; i < 24; i++) {
          const px =
            (seededRand(i * 7.7) * width +
              Math.sin(localT * 1.9 + i) * 30 +
              width) %
            width;
          const py =
            (seededRand(i * 21.3) * height + localT * (58 + (i % 4) * 15)) %
            height;
          ctx.save();
          ctx.translate(px, py);
          ctx.rotate(localT * 2.2 + i);
          ctx.fillStyle = `rgba(251, 207, 232, ${(0.84 * power).toFixed(2)})`;
          ctx.beginPath();
          ctx.ellipse(0, 0, 7 * power, 4 * power, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
        ctx.restore();
        break;
      }

      case 'drifting-clouds': {
        ctx.save();
        for (let c = 0; c < 4; c++) {
          const cx =
            ((c * width * 0.4 + localT * 32) % (width + 320)) - 160;
          const cy = height * (0.12 + (c % 2) * 0.1);
          const cg = ctx.createRadialGradient(cx, cy, 10, cx, cy, 150);
          cg.addColorStop(0, `rgba(255, 255, 255, ${(0.24 * power).toFixed(3)})`);
          cg.addColorStop(1, 'rgba(255, 255, 255, 0)');
          ctx.fillStyle = cg;
          ctx.fillRect(cx - 160, cy - 90, 320, 180);
        }
        ctx.restore();
        break;
      }

      case 'shooting-stars': {
        ctx.save();
        ctx.strokeStyle = `rgba(255, 255, 255, ${(0.85 * power).toFixed(2)})`;
        ctx.lineWidth = 2;
        for (let s = 0; s < 4; s++) {
          const cycle = (localT * 0.85 + s * 0.37) % 1;
          if (cycle < 0.45) {
            const prog = cycle / 0.45;
            const startX = width * (0.85 - s * 0.18) - prog * width * 0.35;
            const startY = height * (0.08 + s * 0.08) + prog * height * 0.25;
            ctx.globalAlpha = (1 - prog) * power;
            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.lineTo(startX + 46, startY - 32);
            ctx.stroke();
          }
        }
        ctx.restore();
        break;
      }

      case 'sunbeams-corner': {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        const sunGrad = ctx.createRadialGradient(
          width * 0.92,
          height * 0.06,
          10,
          width * 0.92,
          height * 0.06,
          Math.hypot(width, height) * 0.72
        );
        sunGrad.addColorStop(0, `rgba(254, 249, 195, ${(0.48 * power).toFixed(3)})`);
        sunGrad.addColorStop(0.4, `rgba(251, 191, 36, ${(0.22 * power).toFixed(3)})`);
        sunGrad.addColorStop(1, 'rgba(251, 191, 36, 0)');
        ctx.fillStyle = sunGrad;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'ocean-caustics': {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.strokeStyle = `rgba(103, 232, 249, ${(0.22 * power).toFixed(3)})`;
        ctx.lineWidth = 2.5;
        for (let w = 0; w < 8; w++) {
          ctx.beginPath();
          const baseY = (height / 8) * w;
          for (let x = 0; x <= width; x += 20) {
            const wy =
              baseY +
              Math.sin((x / width) * Math.PI * 4 + localT * 2.8 + w) * 16;
            if (x === 0) ctx.moveTo(x, wy);
            else ctx.lineTo(x, wy);
          }
          ctx.stroke();
        }
        ctx.restore();
        break;
      }

      case 'neon-pulse-border': {
        const pad = Math.max(8, Math.round(Math.min(width, height) * 0.028));
        const glowPulse = 0.55 + 0.45 * Math.abs(Math.sin(localT * 5));
        ctx.save();
        ctx.strokeStyle = `rgba(0, 229, 223, ${(glowPulse * power).toFixed(2)})`;
        ctx.lineWidth = Math.max(4, pad * 0.35);
        drawRoundedRect(ctx, pad, pad, width - pad * 2, height - pad * 2, 20);
        ctx.stroke();
        ctx.strokeStyle = `rgba(232, 121, 249, ${(glowPulse * 0.8 * power).toFixed(2)})`;
        ctx.lineWidth = 2;
        drawRoundedRect(
          ctx,
          pad + 6,
          pad + 6,
          width - (pad + 6) * 2,
          height - (pad + 6) * 2,
          16
        );
        ctx.stroke();
        ctx.restore();
        break;
      }

      case 'letterbox-blur': {
        const barH = Math.round(height * 0.1 * power);
        const tinyBlur = pool.getCanvas('fx_lbox_blur', 48, 48);
        tinyBlur.getContext('2d')!.drawImage(ctx.canvas, 0, 0, 48, 48);
        ctx.save();
        ctx.globalAlpha = 0.92;
        ctx.drawImage(tinyBlur, 0, 0, 48, 8, 0, 0, width, barH);
        ctx.drawImage(tinyBlur, 0, 40, 48, 8, 0, height - barH, width, barH);
        ctx.restore();
        break;
      }

      case 'vhs-timestamp': {
        ctx.save();
        ctx.direction = 'ltr';
        ctx.textAlign = 'left';
        const fSz = Math.max(13, Math.round(Math.min(width, height) * 0.032));
        ctx.font = `bold ${fSz}px monospace`;
        ctx.fillStyle = `rgba(254, 240, 138, ${(0.9 * power).toFixed(2)})`;
        ctx.fillText('▶ PLAY', 24, 38);
        ctx.fillText(`OCT 21 1998  ${timeSec.toFixed(1)}s`, 24, height - 26);
        ctx.restore();
        break;
      }

      case 'double-exposure': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const offsetX = Math.sin(localT * 1.6) * width * 0.045 * power;
        ctx.save();
        ctx.globalAlpha = 0.36 * power;
        ctx.translate(width / 2 + offsetX, height / 2);
        ctx.scale(1.09, 1.09);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'circular-audio-halo': {
        const cx = width / 2;
        const cy = height * 0.52;
        const baseR = Math.min(width, height) * 0.34;
        const pulse = 1 + 0.06 * Math.sin(localT * 6) * power;
        ctx.save();
        ctx.strokeStyle = `rgba(250, 204, 21, ${(0.55 * power).toFixed(2)})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(cx, cy, baseR * pulse, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = `rgba(0, 229, 223, ${(0.35 * power).toFixed(2)})`;
        ctx.beginPath();
        ctx.arc(cx, cy, baseR * pulse * 1.08, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
        break;
      }

      case 'golden-arabesque': {
        const bandH = Math.round(height * 0.045);
        ctx.save();
        ctx.fillStyle = `rgba(9, 13, 22, ${(0.65 * power).toFixed(2)})`;
        ctx.fillRect(0, 0, width, bandH);
        ctx.fillRect(0, height - bandH, width, bandH);
        ctx.strokeStyle = `rgba(250, 204, 21, ${(0.88 * power).toFixed(2)})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, bandH);
        ctx.lineTo(width, bandH);
        ctx.moveTo(0, height - bandH);
        ctx.lineTo(width, height - bandH);
        ctx.stroke();
        for (let sx = 24; sx < width; sx += 48) {
          drawFourPointStar(ctx, sx, bandH / 2, 7, '#FDE047', 0.85 * power);
          drawFourPointStar(ctx, sx, height - bandH / 2, 7, '#FDE047', 0.85 * power);
        }
        ctx.restore();
        break;
      }

      case 'desert-mirage': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        for (let y = Math.floor(height * 0.55); y < height; y += 5) {
          const dx = Math.sin(y * 0.1 + localT * 5) * 4.5 * power;
          ctx.drawImage(snap, 0, y, width, 5, dx, y, width, 5);
        }
        break;
      }

      case 'starfield-twinkle': {
        ctx.save();
        for (let s = 0; s < 36; s++) {
          const sx = seededRand(s * 19.3) * width;
          const sy = seededRand(s * 37.1) * height * 0.65;
          const a = 0.2 + 0.8 * Math.pow(Math.abs(Math.sin(localT * 2.5 + s)), 2);
          drawFourPointStar(ctx, sx, sy, (4 + (s % 3) * 3) * power, '#FEF9C3', a * power);
        }
        ctx.restore();
        break;
      }

      case 'dandelion-seeds': {
        ctx.save();
        for (let d = 0; d < 22; d++) {
          const x = (seededRand(d * 11.3) * width + localT * 34 + width) % width;
          const y = height - ((seededRand(d * 23.9) * height + localT * 22 + Math.sin(localT + d) * 18) % height);
          ctx.fillStyle = `rgba(255, 255, 255, ${(0.72 * power).toFixed(2)})`;
          ctx.beginPath();
          ctx.arc(x, y, 2.5 * power, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'gentle-snow-mist': {
        ctx.save();
        ctx.fillStyle = `rgba(226, 232, 240, ${(0.12 * power).toFixed(3)})`;
        ctx.fillRect(0, 0, width, height);
        for (let i = 0; i < 28; i++) {
          const x = (seededRand(i * 7.9) * width + Math.sin(localT + i) * 16 + width) % width;
          const y = (seededRand(i * 15.1) * height + localT * 42) % height;
          ctx.fillStyle = `rgba(255, 255, 255, ${(0.75 * power).toFixed(2)})`;
          ctx.beginPath();
          ctx.arc(x, y, 2.2 * power, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'slow-zoom-out': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const prog = Math.min(1, localT / Math.max(0.5, fx.duration));
        const sc = 1.15 - 0.14 * power * prog;
        ctx.save();
        ctx.translate(width / 2, height / 2);
        ctx.scale(sc, sc);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'pan-drift': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const panX = Math.sin(localT * 0.9) * width * 0.05 * power;
        ctx.save();
        ctx.translate(width / 2 + panX, height / 2);
        ctx.scale(1.12, 1.12);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'hologram-lines': {
        ctx.save();
        ctx.fillStyle = `rgba(6, 182, 212, ${(0.14 * power).toFixed(3)})`;
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = `rgba(0, 229, 223, ${(0.22 * power).toFixed(3)})`;
        for (let y = (localT * 60) % 8; y < height; y += 8) {
          ctx.fillRect(0, y, width, 2);
        }
        ctx.restore();
        break;
      }

      case 'cyber-hud-grid': {
        ctx.save();
        ctx.strokeStyle = `rgba(0, 229, 223, ${(0.2 * power).toFixed(3)})`;
        ctx.lineWidth = 1;
        const step = Math.max(32, Math.round(width / 8));
        for (let x = step; x < width; x += step) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
          ctx.stroke();
        }
        for (let y = step; y < height; y += step) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
          ctx.stroke();
        }
        ctx.restore();
        break;
      }

      case 'warm-flare-glow': {
        const g = ctx.createRadialGradient(0, 0, 10, 0, 0, Math.hypot(width, height) * 0.68);
        g.addColorStop(0, `rgba(255, 237, 213, ${(0.52 * power).toFixed(3)})`);
        g.addColorStop(0.45, `rgba(251, 146, 60, ${(0.24 * power).toFixed(3)})`);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'crystal-diamonds': {
        for (let i = 0; i < 18; i++) {
          const dx = seededRand(i * 23.1) * width;
          const dy = seededRand(i * 17.9) * height;
          const fl = Math.pow(Math.max(0, Math.sin(localT * 4.5 + i * 2.1)), 3);
          if (fl > 0.05) {
            drawFourPointStar(ctx, dx, dy, 16 * fl * power, '#E0F7FA', fl * 0.9);
          }
        }
        break;
      }

      case 'documentary-frame': {
        const m = Math.round(Math.min(width, height) * 0.038);
        ctx.save();
        ctx.strokeStyle = `rgba(255, 255, 255, ${(0.78 * power).toFixed(2)})`;
        ctx.lineWidth = 2;
        ctx.strokeRect(m, m, width - m * 2, height - m * 2);
        ctx.restore();
        break;
      }

      case 'super8-border': {
        const m = Math.round(width * 0.045);
        ctx.save();
        ctx.fillStyle = '#09090B';
        ctx.fillRect(0, 0, m, height);
        ctx.fillRect(width - m, 0, m, height);
        ctx.fillStyle = '#FDE68A';
        for (let y = (localT * 90) % 44; y < height; y += 44) {
          drawRoundedRect(ctx, m * 0.25, y, m * 0.5, 18, 4);
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'sepia-vignette': {
        const g = ctx.createRadialGradient(
          width / 2,
          height / 2,
          Math.min(width, height) * 0.28,
          width / 2,
          height / 2,
          Math.hypot(width / 2, height / 2)
        );
        g.addColorStop(0, 'rgba(120, 53, 15, 0)');
        g.addColorStop(1, `rgba(69, 26, 3, ${(0.65 * power).toFixed(3)})`);
        ctx.save();
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'nine-grid': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const cw = width / 3;
        const ch = height / 3;
        for (let r = 0; r < 3; r++) {
          for (let c = 0; c < 3; c++) {
            ctx.drawImage(snap, c * cw, r * ch, cw, ch);
          }
        }
        break;
      }

      case 'vertical-triptych': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const thirdW = width / 3;
        for (let c = 0; c < 3; c++) {
          ctx.save();
          ctx.beginPath();
          ctx.rect(c * thirdW, 0, thirdW, height);
          ctx.clip();
          ctx.drawImage(snap, width * 0.3, 0, width * 0.4, height, c * thirdW, 0, thirdW, height);
          ctx.restore();
        }
        break;
      }

      case 'quad-mirror': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const hw = width / 2;
        const hh = height / 2;
        ctx.drawImage(snap, 0, 0, hw, hh);
        ctx.save();
        ctx.translate(width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(snap, 0, 0, hw, hh);
        ctx.restore();
        ctx.save();
        ctx.translate(0, height);
        ctx.scale(1, -1);
        ctx.drawImage(snap, 0, 0, hw, hh);
        ctx.restore();
        ctx.save();
        ctx.translate(width, height);
        ctx.scale(-1, -1);
        ctx.drawImage(snap, 0, 0, hw, hh);
        ctx.restore();
        break;
      }

      case 'shake': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const dx = Math.sin(localT * 46) * width * 0.032 * power;
        const dy = Math.cos(localT * 37) * height * 0.024 * power;
        const zoom = 1 + 0.07 * power;
        ctx.save();
        ctx.translate(width / 2 + dx, height / 2 + dy);
        ctx.scale(zoom, zoom);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'earthquake': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const seed = Math.floor(localT * 48);
        const jx = (seededRand(seed * 3.1) - 0.5) * width * 0.095 * power;
        const jy = (seededRand(seed * 7.7) - 0.5) * height * 0.075 * power;
        const rot = (seededRand(seed * 5.3) - 0.5) * 0.06 * power;
        ctx.save();
        ctx.translate(width / 2 + jx, height / 2 + jy);
        ctx.rotate(rot);
        ctx.scale(1.12, 1.12);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'heartbeat-zoom': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const phase = (localT * 1.25) % 1;
        const doubleBeat =
          phase < 0.16
            ? Math.sin((phase / 0.16) * Math.PI)
            : phase > 0.22 && phase < 0.42
              ? Math.sin(((phase - 0.22) / 0.2) * Math.PI) * 0.72
              : 0;
        const scale = 1 + doubleBeat * 0.15 * power;
        ctx.save();
        ctx.translate(width / 2, height / 2);
        ctx.scale(scale, scale);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'floating-wave': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const dx = Math.sin(localT * 2.2) * width * 0.03 * power;
        const dy = Math.cos(localT * 1.7) * height * 0.032 * power;
        ctx.save();
        ctx.translate(width / 2 + dx, height / 2 + dy);
        ctx.scale(1.08, 1.08);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'spin-dizzy': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const angle = Math.sin(localT * 3.6) * 0.16 * power;
        ctx.save();
        ctx.translate(width / 2, height / 2);
        ctx.rotate(angle);
        ctx.scale(1.18, 1.18);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'pendulum': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const angle = Math.sin(localT * Math.PI * 1.6) * 0.09 * power;
        const swingX = Math.sin(localT * Math.PI * 1.6) * width * 0.035 * power;
        ctx.save();
        ctx.translate(width / 2 + swingX, height / 2);
        ctx.rotate(angle);
        ctx.scale(1.12, 1.12);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'zoom-pulse': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const beat = Math.pow(Math.abs(Math.sin(localT * Math.PI * 2.4)), 2.2);
        const scale = 1 + beat * 0.14 * power;
        ctx.save();
        ctx.translate(width / 2, height / 2);
        ctx.scale(scale, scale);
        ctx.drawImage(snap, -width / 2, -height / 2, width, height);
        ctx.restore();
        break;
      }

      case 'rgb-split': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const shift = width * 0.022 * power * (0.6 + 0.4 * Math.sin(localT * 18));
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = 0.45 * power;
        ctx.drawImage(snap, shift, 0, width, height);
        ctx.drawImage(snap, -shift, 2, width, height);
        ctx.fillStyle = `rgba(0, 229, 223, ${(0.1 * power).toFixed(3)})`;
        ctx.fillRect(-shift, 0, width, height);
        ctx.restore();
        break;
      }

      case 'glitch-cyber': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const seedBase = Math.floor(localT * 20);
        for (let i = 0; i < 9; i++) {
          const r1 = seededRand(seedBase + i * 9.1);
          const r2 = seededRand(seedBase + i * 4.3);
          const sy = Math.floor(r1 * height);
          const sh = Math.max(8, Math.floor(r2 * (height / 9)));
          const sx = (seededRand(seedBase + i * 2.7) - 0.5) * width * 0.18 * power;
          ctx.drawImage(snap, 0, sy, width, sh, sx, sy, width, sh);
        }
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = `rgba(232, 121, 249, ${(0.12 * power).toFixed(3)})`;
        ctx.fillRect(4, 0, width, height);
        ctx.restore();
        break;
      }

      case 'matrix-rain': {
        ctx.save();
        ctx.fillStyle = `rgba(0, 30, 12, ${(0.28 * power).toFixed(3)})`;
        ctx.fillRect(0, 0, width, height);
        const fontSz = Math.max(12, Math.round(width * 0.032));
        ctx.font = `bold ${fontSz}px monospace`;
        const cols = 14;
        const colW = width / cols;
        for (let c = 0; c < cols; c++) {
          const speed = 130 + (c % 5) * 55;
          const headY = ((localT * speed + c * 97) % (height + 120)) - 60;
          for (let k = 0; k < 6; k++) {
            const gy = headY - k * fontSz * 1.15;
            if (gy < -fontSz || gy > height + fontSz) continue;
            ctx.fillStyle =
              k === 0
                ? `rgba(220, 255, 235, ${(0.85 * power).toFixed(2)})`
                : `rgba(16, 225, 110, ${((0.65 - k * 0.1) * power).toFixed(2)})`;
            const digit = ((Math.floor(localT * 12) + c + k) % 2).toString();
            ctx.fillText(digit, c * colW + 4, gy);
          }
        }
        ctx.restore();
        break;
      }

      case 'scan-laser': {
        const beamY = ((Math.sin(localT * 2.6) + 1) / 2) * height;
        const grad = ctx.createLinearGradient(0, beamY - 45, 0, beamY + 45);
        grad.addColorStop(0, 'rgba(0, 229, 223, 0)');
        grad.addColorStop(0.5, `rgba(0, 229, 223, ${(0.58 * power).toFixed(3)})`);
        grad.addColorStop(1, 'rgba(0, 229, 223, 0)');
        ctx.save();
        ctx.fillStyle = grad;
        ctx.fillRect(0, beamY - 45, width, 90);
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, beamY - 1.5, width, 3);
        ctx.restore();
        break;
      }

      case 'negative-invert': {
        ctx.save();
        ctx.globalCompositeOperation = 'difference';
        ctx.fillStyle = `rgba(255, 255, 255, ${power.toFixed(3)})`;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'dreamy-glow': {
        const glowTiny = pool.getCanvas('fx_glow_tiny', 64, 64);
        glowTiny.getContext('2d')!.drawImage(ctx.canvas, 0, 0, 64, 64);
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = 0.42 * power;
        ctx.drawImage(glowTiny, 0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'sparkle-stars': {
        for (let i = 0; i < 16; i++) {
          const sx = seededRand(i * 17.3 + 1.1) * width;
          const sy =
            (seededRand(i * 31.7 + 4.5) * height + localT * 38) % height;
          const pulse = Math.pow(
            Math.max(0, Math.sin(localT * 5.2 + i * 1.7)),
            2
          );
          if (pulse > 0.08) {
            const starR = (10 + (i % 4) * 7) * power * pulse;
            const color =
              i % 3 === 0 ? '#FFFFFF' : i % 3 === 1 ? '#FEF08A' : '#67E8F9';
            drawFourPointStar(ctx, sx, sy, starR, color, 0.9 * pulse);
          }
        }
        break;
      }

      case 'golden-dust': {
        ctx.save();
        for (let i = 0; i < 36; i++) {
          const x =
            (seededRand(i * 7.3) * width +
              Math.sin(localT * 1.5 + i) * 24) %
            width;
          const y =
            height -
            ((seededRand(i * 13.9) * height + localT * (45 + (i % 4) * 18)) %
              height);
          const r = (2 + (i % 4) * 1.6) * power;
          ctx.fillStyle =
            i % 2 === 0
              ? `rgba(253, 224, 71, ${(0.82 * power).toFixed(2)})`
              : `rgba(251, 146, 60, ${(0.65 * power).toFixed(2)})`;
          ctx.beginPath();
          ctx.arc(Math.abs(x), y, r, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'snowfall': {
        ctx.save();
        for (let i = 0; i < 40; i++) {
          const x =
            (seededRand(i * 5.7) * width +
              Math.sin(localT * 2 + i) * 18 +
              width) %
            width;
          const y =
            (seededRand(i * 19.3) * height + localT * (65 + (i % 5) * 20)) %
            height;
          const r = (2.2 + (i % 4) * 1.5) * power;
          ctx.fillStyle = `rgba(255, 255, 255, ${(0.85 * power).toFixed(2)})`;
          ctx.beginPath();
          ctx.arc(x, y, r, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        break;
      }

      case 'rain-drops': {
        ctx.save();
        ctx.strokeStyle = `rgba(186, 230, 253, ${(0.48 * power).toFixed(3)})`;
        ctx.lineWidth = 1.6;
        for (let i = 0; i < 45; i++) {
          const rx = (seededRand(i * 9.3) * (width + 80)) - 40;
          const ry =
            (seededRand(i * 21.1) * height + localT * (520 + (i % 3) * 120)) %
            height;
          ctx.beginPath();
          ctx.moveTo(rx, ry);
          ctx.lineTo(rx - 8, ry + 28 * power);
          ctx.stroke();
        }
        ctx.restore();
        break;
      }

      case 'light-leak': {
        const cx1 = width * (0.15 + 0.7 * (0.5 + 0.5 * Math.sin(localT * 1.4)));
        const cy1 = height * (0.2 + 0.3 * Math.cos(localT * 1.1));
        const leakGrad = ctx.createRadialGradient(
          cx1,
          cy1,
          width * 0.05,
          cx1,
          cy1,
          width * 0.85
        );
        leakGrad.addColorStop(0, `rgba(255, 200, 90, ${(0.52 * power).toFixed(3)})`);
        leakGrad.addColorStop(0.45, `rgba(244, 63, 94, ${(0.30 * power).toFixed(3)})`);
        leakGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = leakGrad;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'rainbow-prism': {
        const shift = Math.sin(localT * 1.8) * width * 0.15;
        const prism = ctx.createLinearGradient(shift, 0, width + shift, height);
        prism.addColorStop(0, 'rgba(244, 63, 94, 0)');
        prism.addColorStop(0.28, `rgba(244, 63, 94, ${(0.32 * power).toFixed(3)})`);
        prism.addColorStop(0.45, `rgba(250, 204, 21, ${(0.30 * power).toFixed(3)})`);
        prism.addColorStop(0.62, `rgba(52, 211, 153, ${(0.30 * power).toFixed(3)})`);
        prism.addColorStop(0.78, `rgba(56, 189, 248, ${(0.34 * power).toFixed(3)})`);
        prism.addColorStop(1, 'rgba(168, 85, 247, 0)');
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = prism;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'neon-frame': {
        const pad = Math.max(8, Math.round(Math.min(width, height) * 0.032));
        const pulse = 0.7 + 0.3 * Math.sin(localT * Math.PI * 3);
        ctx.save();
        ctx.strokeStyle = `rgba(0, 229, 223, ${(0.35 * power * pulse).toFixed(3)})`;
        ctx.lineWidth = pad * 0.95;
        drawRoundedRect(ctx, pad, pad, width - pad * 2, height - pad * 2, 24);
        ctx.stroke();

        ctx.strokeStyle =
          Math.sin(localT * 2.5) > 0 ? '#00E5DF' : '#E879F9';
        ctx.lineWidth = Math.max(3, pad * 0.26);
        drawRoundedRect(ctx, pad, pad, width - pad * 2, height - pad * 2, 24);
        ctx.stroke();
        ctx.restore();
        break;
      }

      case 'cinema-bars': {
        const barH = Math.round(height * 0.115 * power);
        ctx.save();
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, width, barH);
        ctx.fillRect(0, height - barH, width, barH);
        ctx.restore();
        break;
      }

      case 'retro-vhs': {
        ctx.save();
        ctx.fillStyle = `rgba(255, 190, 110, ${(0.09 * power).toFixed(3)})`;
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = `rgba(0, 0, 0, ${(0.22 * power).toFixed(3)})`;
        for (let y = 0; y < height; y += 6) {
          ctx.fillRect(0, y, width, 2);
        }
        const trackY = (localT * 180) % height;
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.fillRect(0, trackY, width, 5);
        ctx.restore();
        break;
      }

      case 'film-grain': {
        ctx.save();
        ctx.fillStyle = `rgba(245, 208, 145, ${(0.1 * power).toFixed(3)})`;
        ctx.fillRect(0, 0, width, height);
        const seed = Math.floor(localT * 24);
        ctx.strokeStyle = `rgba(255, 255, 255, ${(0.24 * power).toFixed(3)})`;
        ctx.lineWidth = 1.4;
        for (let s = 0; s < 3; s++) {
          const x = seededRand(seed + s * 13.7) * width;
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x + (seededRand(seed * 2) - 0.5) * 4, height);
          ctx.stroke();
        }
        for (let d = 0; d < 22; d++) {
          const dx = seededRand(seed + d * 5.9) * width;
          const dy = seededRand(seed + d * 11.3) * height;
          ctx.fillStyle =
            d % 2 === 0
              ? `rgba(255,255,255,${(0.32 * power).toFixed(2)})`
              : `rgba(0,0,0,${(0.35 * power).toFixed(2)})`;
          ctx.fillRect(dx, dy, 2.5, 2.5);
        }
        ctx.restore();
        break;
      }

      case 'viewfinder-rec': {
        const m = Math.round(Math.min(width, height) * 0.06);
        const len = Math.round(Math.min(width, height) * 0.075);
        ctx.save();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.88)';
        ctx.lineWidth = Math.max(2.5, Math.min(width, height) * 0.005);
        ctx.beginPath();
        ctx.moveTo(m, m + len);
        ctx.lineTo(m, m);
        ctx.lineTo(m + len, m);

        ctx.moveTo(width - m - len, m);
        ctx.lineTo(width - m, m);
        ctx.lineTo(width - m, m + len);

        ctx.moveTo(m, height - m - len);
        ctx.lineTo(m, height - m);
        ctx.lineTo(m + len, height - m);

        ctx.moveTo(width - m - len, height - m);
        ctx.lineTo(width - m, height - m);
        ctx.lineTo(width - m, height - m - len);
        ctx.stroke();

        const cx = width / 2;
        const cy = height / 2;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(cx - 14, cy);
        ctx.lineTo(cx + 14, cy);
        ctx.moveTo(cx, cy - 14);
        ctx.lineTo(cx, cy + 14);
        ctx.stroke();

        if (Math.sin(localT * Math.PI * 3) > -0.3) {
          ctx.fillStyle = '#EF4444';
          ctx.beginPath();
          ctx.arc(m + 18, m + 22, 7, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.direction = 'ltr';
        ctx.textAlign = 'left';
        ctx.font = `800 ${Math.max(13, Math.round(Math.min(width, height) * 0.032))}px monospace`;
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText('REC', m + 32, m + 27);
        ctx.restore();
        break;
      }

      case 'cctv-security': {
        ctx.save();
        ctx.globalCompositeOperation = 'color';
        ctx.fillStyle = `rgba(34, 197, 94, ${(0.55 * power).toFixed(2)})`;
        ctx.fillRect(0, 0, width, height);
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
        for (let y = 0; y < height; y += 5) {
          ctx.fillRect(0, y, width, 2);
        }
        ctx.direction = 'ltr';
        ctx.textAlign = 'left';
        ctx.font = `bold ${Math.max(12, Math.round(width * 0.03))}px monospace`;
        ctx.fillStyle = '#86EFAC';
        ctx.fillText(`CAM 01 • ${timeSec.toFixed(1)}s`, 20, 32);
        ctx.restore();
        break;
      }

      case 'halftone-comic': {
        ctx.save();
        ctx.fillStyle = `rgba(0, 0, 0, ${(0.18 * power).toFixed(3)})`;
        const step = 12;
        for (let y = 6; y < height; y += step) {
          for (let x = 6; x < width; x += step) {
            ctx.beginPath();
            ctx.arc(x, y, 2.2 * power, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.restore();
        break;
      }

      case 'three-screen': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const thirdH = height / 3;
        ctx.save();
        for (let pane = 0; pane < 3; pane++) {
          ctx.save();
          ctx.beginPath();
          ctx.rect(0, pane * thirdH, width, thirdH);
          ctx.clip();
          ctx.drawImage(
            snap,
            0,
            height * 0.28,
            width,
            height * 0.44,
            0,
            pane * thirdH,
            width,
            thirdH
          );
          ctx.restore();
          if (pane > 0) {
            ctx.fillStyle = 'rgba(255,255,255,0.55)';
            ctx.fillRect(0, pane * thirdH - 1, width, 2);
          }
        }
        ctx.restore();
        break;
      }

      case 'four-grid': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const hw = width / 2;
        const hh = height / 2;
        ctx.save();
        ctx.drawImage(snap, 0, 0, hw, hh);
        ctx.drawImage(snap, hw, 0, hw, hh);
        ctx.drawImage(snap, 0, hh, hw, hh);
        ctx.drawImage(snap, hw, hh, hw, hh);
        ctx.fillStyle = 'rgba(255,255,255,0.6)';
        ctx.fillRect(hw - 1, 0, 2, height);
        ctx.fillRect(0, hh - 1, width, 2);
        ctx.restore();
        break;
      }

      case 'mirror-split': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        const halfW = width / 2;
        ctx.save();
        ctx.beginPath();
        ctx.rect(halfW, 0, halfW, height);
        ctx.clip();
        ctx.translate(width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(snap, 0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'fisheye-tunnel': {
        sctx.drawImage(ctx.canvas, 0, 0, width, height);
        for (let ring = 3; ring >= 1; ring--) {
          const sc = 1 + ring * 0.1 * power;
          ctx.save();
          ctx.globalAlpha = 0.25 * power;
          ctx.translate(width / 2, height / 2);
          ctx.scale(sc, sc);
          ctx.drawImage(snap, -width / 2, -height / 2, width, height);
          ctx.restore();
        }
        ctx.save();
        ctx.beginPath();
        ctx.arc(width / 2, height / 2, Math.min(width, height) * 0.42, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(snap, 0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'pixel-mosaic': {
        const lowW = Math.max(12, Math.round(width / Math.max(4, Math.round(22 * power))));
        const lowH = Math.max(12, Math.round(height / Math.max(4, Math.round(22 * power))));
        const pix = pool.getCanvas('fx_mosaic', lowW, lowH);
        const pctx = pix.getContext('2d')!;
        pctx.imageSmoothingEnabled = false;
        pctx.drawImage(ctx.canvas, 0, 0, lowW, lowH);
        ctx.save();
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(pix, 0, 0, width, height);
        ctx.restore();
        break;
      }

      case 'strobe': {
        const on = Math.sin(localT * Math.PI * 10) > 0.35;
        if (on) {
          ctx.save();
          ctx.fillStyle = `rgba(255, 255, 255, ${(0.38 * power).toFixed(3)})`;
          ctx.fillRect(0, 0, width, height);
          ctx.restore();
        }
        break;
      }

      case 'vignette-focus': {
        const cx = width / 2;
        const cy = height / 2;
        const outerR = Math.hypot(cx, cy);
        const grad = ctx.createRadialGradient(
          cx,
          cy,
          outerR * 0.25,
          cx,
          cy,
          outerR * 0.95
        );
        grad.addColorStop(0, 'rgba(0,0,0,0)');
        grad.addColorStop(1, `rgba(0,0,0,${(0.72 * power).toFixed(3)})`);
        ctx.save();
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
        break;
      }
    }
  }
}

function isArabicText(text: string): boolean {
  return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/.test(text);
}

function hexToRgba(hex: string, alpha: number): string {
  const clean = (hex || '#000000').replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean.padEnd(6, '0');
  const num = parseInt(full.slice(0, 6), 16);
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r}, ${g}, ${b}, ${Math.max(0, Math.min(1, alpha)).toFixed(3)})`;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
): void {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

function drawStyledGlyphRun(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  fillColor: string,
  item: TextOverlay,
  scaleFactor: number
): void {
  ctx.lineJoin = 'round';
  ctx.miterLimit = 2;

  if (item.shadowBlur > 0) {
    ctx.strokeStyle = hexToRgba(item.shadowColor || '#000000', 0.28);
    ctx.lineWidth =
      (item.strokeWidth + item.shadowBlur * 0.65) * scaleFactor;
    ctx.strokeText(text, x, y + 2 * scaleFactor);
  }

  if (item.strokeWidth > 0) {
    ctx.lineWidth = item.strokeWidth * scaleFactor;
    ctx.strokeStyle = item.strokeColor || '#000000';
    ctx.strokeText(text, x, y);
  }

  ctx.fillStyle = fillColor;
  ctx.fillText(text, x, y);
}

export function renderTextOverlays(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  texts: TextOverlay[],
  timeSec: number,
  selectedTextId?: string | null
): void {
  const minDim = Math.min(width, height);
  const scaleFactor = minDim / 720;

  for (const item of texts) {
    if (
      timeSec < item.startTime ||
      timeSec > item.startTime + Math.max(0.05, item.duration)
    ) {
      continue;
    }

    const localT = timeSec - item.startTime;
    const dur = Math.max(0.1, item.duration);
    let alpha = (item.opacity ?? 100) / 100;
    let animScale = 1;
    let offsetY = 0;
    let visibleText = item.text || '';

    const enterDur = Math.min(0.38, dur * 0.35);
    const exitDur = Math.min(0.28, dur * 0.25);

    switch (item.animation) {
      case 'fade': {
        if (localT < enterDur) alpha *= localT / enterDur;
        else if (localT > dur - exitDur) alpha *= (dur - localT) / exitDur;
        break;
      }
      case 'pop': {
        if (localT < enterDur) {
          const p = localT / enterDur;
          animScale =
            p < 0.7
              ? 0.25 + (p / 0.7) * 0.88
              : 1.13 - ((p - 0.7) / 0.3) * 0.13;
          alpha *= Math.min(1, p * 1.8);
        }
        break;
      }
      case 'slide-up': {
        if (localT < enterDur) {
          const p = easeInOutCubic(localT / enterDur);
          offsetY = (1 - p) * 38 * scaleFactor;
          alpha *= p;
        }
        break;
      }
      case 'typewriter': {
        const chars = Array.from(visibleText);
        const typeWindow = Math.min(
          dur * 0.75,
          Math.max(0.35, chars.length * 0.05)
        );
        const shownCount = Math.max(
          1,
          Math.floor((localT / typeWindow) * chars.length)
        );
        visibleText = chars.slice(0, shownCount).join('');
        break;
      }
      case 'pulse': {
        animScale = 1 + 0.055 * Math.sin(localT * Math.PI * 3.4);
        break;
      }
    }

    if (!visibleText.trim()) continue;

    ctx.save();
    ctx.globalAlpha = Math.max(0, Math.min(1, alpha));

    const rtl = isArabicText(visibleText);
    if ('direction' in ctx) {
      ctx.direction = rtl ? 'rtl' : 'ltr';
    }

    const fontPx = Math.max(14, Math.round(item.fontSize * scaleFactor));
    ctx.font = `${item.fontWeight || 700} ${fontPx}px "${item.fontFamily || 'Cairo'}", "Cairo", sans-serif`;
    ctx.textBaseline = 'middle';

    const maxLineWidth = width * 0.88;
    const rawLines = visibleText.split('\n');
    const wrappedLines: string[] = [];

    for (const rawLine of rawLines) {
      const words = rawLine.split(/\s+/).filter(Boolean);
      if (words.length === 0) {
        wrappedLines.push('');
        continue;
      }
      let current = words[0];
      for (let w = 1; w < words.length; w++) {
        const test = current + ' ' + words[w];
        if (ctx.measureText(test).width <= maxLineWidth) {
          current = test;
        } else {
          wrappedLines.push(current);
          current = words[w];
        }
      }
      wrappedLines.push(current);
    }

    const lineHeight = fontPx * 1.34;
    const blockHeight = wrappedLines.length * lineHeight;
    let maxMeasuredW = 0;
    for (const line of wrappedLines) {
      maxMeasuredW = Math.max(maxMeasuredW, ctx.measureText(line).width);
    }

    const anchorX = (item.x / 100) * width;
    const anchorY = (item.y / 100) * height + offsetY;

    ctx.translate(anchorX, anchorY);
    ctx.scale(animScale, animScale);

    const padX = Math.round(fontPx * 0.45);
    const padY = Math.round(fontPx * 0.26);
    const boxW = maxMeasuredW + padX * 2;
    const boxH = blockHeight + padY * 2;

    let boxX = -boxW / 2;
    if (item.align === 'right') boxX = -boxW + padX;
    else if (item.align === 'left') boxX = -padX;

    const boxY = -boxH / 2;

    if (item.bgOpacity > 0) {
      ctx.save();
      ctx.fillStyle = hexToRgba(item.bgColor || '#000000', item.bgOpacity / 100);
      drawRoundedRect(
        ctx,
        boxX,
        boxY,
        boxW,
        boxH,
        (item.bgRadius ?? 16) * scaleFactor
      );
      ctx.fill();
      ctx.restore();
    }

    const useWordSync =
      item.highlightWords &&
      item.animation !== 'typewriter' &&
      wrappedLines.length <= 3;

    const allWords = visibleText.split(/\s+/).filter(Boolean);
    const timings =
      item.wordTimings && item.wordTimings.length === allWords.length
        ? item.wordTimings
        : allWords.map((word, idx) => {
            const slice = dur / Math.max(1, allWords.length);
            return {
              word,
              start: idx * slice,
              end: (idx + 1) * slice,
            };
          });

    let globalWordCursor = 0;

    for (let li = 0; li < wrappedLines.length; li++) {
      const line = wrappedLines[li];
      const lineY = -blockHeight / 2 + li * lineHeight + lineHeight / 2;
      const lineRtl = isArabicText(line);
      if ('direction' in ctx) {
        ctx.direction = lineRtl ? 'rtl' : 'ltr';
      }

      if (!useWordSync) {
        ctx.textAlign = item.align || 'center';
        drawStyledGlyphRun(
          ctx,
          line,
          0,
          lineY,
          item.color || '#FFFFFF',
          item,
          scaleFactor
        );
      } else {
        const lineWords = line.split(/\s+/).filter(Boolean);
        const spaceW = ctx.measureText(' ').width * 1.15;
        const widths = lineWords.map((w) => ctx.measureText(w).width);
        const totalLineW =
          widths.reduce((a, b) => a + b, 0) +
          Math.max(0, lineWords.length - 1) * spaceW;

        let startEdgeX = -totalLineW / 2;
        if (item.align === 'right') startEdgeX = -totalLineW + padX;
        else if (item.align === 'left') startEdgeX = -padX;

        ctx.textAlign = 'center';
        let cursorX = lineRtl ? startEdgeX + totalLineW : startEdgeX;

        for (let wi = 0; wi < lineWords.length; wi++) {
          const wText = lineWords[wi];
          const wWidth = widths[wi];
          const wordCenterX = lineRtl
            ? cursorX - wWidth / 2
            : cursorX + wWidth / 2;
          const wt = timings[globalWordCursor];
          const isSpoken =
            wt && localT >= wt.start - 0.02 && localT <= wt.end + 0.05;

          ctx.save();
          if (isSpoken) {
            ctx.translate(wordCenterX, lineY);
            ctx.scale(1.12, 1.12);
            ctx.fillStyle = hexToRgba(item.highlightColor || '#00E5DF', 0.28);
            drawRoundedRect(
              ctx,
              -wWidth / 2 - 6 * scaleFactor,
              -fontPx * 0.56,
              wWidth + 12 * scaleFactor,
              fontPx * 1.12,
              10 * scaleFactor
            );
            ctx.fill();

            drawStyledGlyphRun(
              ctx,
              wText,
              0,
              0,
              item.highlightColor || '#00E5DF',
              item,
              scaleFactor
            );
          } else {
            drawStyledGlyphRun(
              ctx,
              wText,
              wordCenterX,
              lineY,
              item.color || '#FFFFFF',
              item,
              scaleFactor
            );
          }
          ctx.restore();

          cursorX += lineRtl ? -(wWidth + spaceW) : wWidth + spaceW;
          globalWordCursor++;
        }
      }
    }

    if (selectedTextId && selectedTextId === item.id) {
      ctx.save();
      ctx.strokeStyle = '#00E5DF';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);
      drawRoundedRect(ctx, boxX - 6, boxY - 6, boxW + 12, boxH + 12, 10);
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
  }
}

export interface CompositeRenderParams {
  ctx: CanvasRenderingContext2D;
  width: number;
  height: number;
  clips: VideoClip[];
  texts: TextOverlay[];
  effects?: VideoEffectClip[];
  overlays?: OverlayClip[];
  bgColor: string;
  timeSec: number;
  getMediaFrame: FrameProvider;
  getOverlayFrame?: OverlayMediaProvider;
  selectedTextId?: string | null;
  selectedOverlayId?: string | null;
}

export function renderCompositeFrame(params: CompositeRenderParams): void {
  const {
    ctx,
    width,
    height,
    clips,
    texts,
    effects = [],
    overlays = [],
    bgColor,
    timeSec,
    getMediaFrame,
    getOverlayFrame,
    selectedTextId,
    selectedOverlayId,
  } = params;

  ctx.save();
  ctx.fillStyle = bgColor || '#000000';
  ctx.fillRect(0, 0, width, height);

  const slots = computeClipSlots(clips);
  const resolved = resolveTimelineAtTime(slots, timeSec);

  if (
    resolved.secondary &&
    resolved.primary &&
    resolved.transitionType &&
    resolved.transitionType !== 'none' &&
    resolved.transitionProgress !== undefined
  ) {
    const mediaA = getMediaFrame(
      resolved.secondary.clip,
      resolved.secondary.sourceTime
    );
    const mediaB = getMediaFrame(
      resolved.primary.clip,
      resolved.primary.sourceTime
    );
    const canvasA = renderSingleClipToCanvas(
      'clipA',
      resolved.secondary,
      mediaA,
      width,
      height,
      bgColor
    );
    const canvasB = renderSingleClipToCanvas(
      'clipB',
      resolved.primary,
      mediaB,
      width,
      height,
      bgColor
    );
    renderTransitionComposite(
      ctx,
      width,
      height,
      canvasA,
      canvasB,
      resolved.transitionType,
      resolved.transitionProgress,
      timeSec
    );
  } else if (resolved.primary) {
    const media = getMediaFrame(
      resolved.primary.clip,
      resolved.primary.sourceTime
    );
    const canvasMain = renderSingleClipToCanvas(
      'clipMain',
      resolved.primary,
      media,
      width,
      height,
      bgColor
    );
    ctx.drawImage(canvasMain, 0, 0, width, height);
  }

  // Layer 2: CapCut Picture-in-Picture Overlays (PIP)
  renderPictureInPictureOverlays(
    ctx,
    width,
    height,
    overlays,
    timeSec,
    getOverlayFrame,
    selectedOverlayId
  );

  // Layer 3: CapCut Video Effects (All 33 real effects)
  renderActiveVideoEffects(ctx, width, height, effects, timeSec);

  // Layer 4: Arabic/LTR Texts, Bilingual Captions, Karaoke Highlights & Animated Stickers
  renderTextOverlays(ctx, width, height, texts, timeSec, selectedTextId);

  ctx.restore();
}
