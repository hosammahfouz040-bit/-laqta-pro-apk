import {
  ALL_FORMATS,
  AudioBufferSource,
  BlobSource,
  BufferTarget,
  CanvasSink,
  CanvasSource,
  canEncodeAudio,
  getFirstEncodableAudioCodec,
  getFirstEncodableVideoCodec,
  Input,
  InputVideoTrack,
  Mp4OutputFormat,
  Output,
  Quality,
  WrappedCanvas,
} from 'mediabunny';
import { registerMp3Encoder } from '@mediabunny/mp3-encoder';
import { getResolutionDimensions } from '../constants/presets';
import {
  AudioClip,
  ExportProgress,
  ExportSettings,
  MediaAsset,
  ProjectData,
  VideoClip,
} from '../types/editor';
import { mixProjectAudioBuffer } from './audioEngine';
import {
  computeClipSlots,
  computeProjectDuration,
  DrawableMedia,
  renderCompositeFrame,
  resolveTimelineAtTime,
} from './compositor';

export interface ExportResult {
  blob: Blob;
  url: string;
  fileName: string;
  mimeType: string;
  width: number;
  height: number;
  duration: number;
  sizeBytes: number;
  engineUsed: string;
  downgradedResolutionNote?: string;
}

interface PreparedMediaHandle {
  asset: MediaAsset;
  image?: HTMLImageElement;
  videoTrack?: InputVideoTrack;
  inputToClose?: Input;
  fallbackVideo?: HTMLVideoElement;
}

function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('تعذر تحميل الصورة أثناء التصدير'));
    img.src = src;
  });
}

function createPreparedVideoElement(src: string): Promise<HTMLVideoElement> {
  return new Promise((resolve, reject) => {
    const v = document.createElement('video');
    v.crossOrigin = 'anonymous';
    v.muted = true;
    v.playsInline = true;
    v.preload = 'auto';
    v.src = src;
    const onReady = () => {
      cleanup();
      resolve(v);
    };
    const onErr = () => {
      cleanup();
      reject(new Error('تعذر تهيئة مقطع الفيديو للقراءة'));
    };
    const cleanup = () => {
      v.removeEventListener('loadeddata', onReady);
      v.removeEventListener('error', onErr);
    };
    v.addEventListener('loadeddata', onReady);
    v.addEventListener('error', onErr);
    v.load();
  });
}

function seekVideoElement(
  video: HTMLVideoElement,
  targetTime: number
): Promise<void> {
  const clamped = Math.max(
    0,
    Math.min(targetTime, Math.max(0, (video.duration || targetTime) - 0.01))
  );
  if (Math.abs(video.currentTime - clamped) < 0.012 && video.readyState >= 2) {
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      video.removeEventListener('seeked', finish);
      clearTimeout(timer);
      resolve();
    };
    const timer = window.setTimeout(finish, 750);
    video.addEventListener('seeked', finish);
    try {
      video.currentTime = clamped;
    } catch {
      finish();
    }
  });
}

export async function exportProjectToMp4(params: {
  project: ProjectData;
  settings: ExportSettings;
  onProgress: (progress: ExportProgress) => void;
  signal?: AbortSignal;
}): Promise<ExportResult> {
  const { project, settings, onProgress, signal } = params;

  const checkAborted = () => {
    if (signal?.aborted) {
      throw new DOMException('تم إلغاء التصدير من قِبل المستخدم', 'AbortError');
    }
  };

  if (project.clips.length === 0) {
    throw new Error('المشروع فارغ — أضف مقطع فيديو أو صورة على الأقل قبل التصدير.');
  }

  const totalDuration = computeProjectDuration(
    project.clips,
    project.texts,
    project.audioClips
  );
  if (totalDuration <= 0.05) {
    throw new Error('مدة المشروع قصيرة جداً للتصدير.');
  }

  // Memory safety guard for budget devices (e.g., Samsung A04 with 3GB/4GB RAM)
  const deviceRamGb =
    (navigator as Navigator & { deviceMemory?: number }).deviceMemory || 4;
  if (totalDuration > 180 && deviceRamGb <= 3 && settings.resolution === '1080p') {
    throw new Error(
      'ذاكرة الجهاز محدودة لتصدير فيديو طويل بدقة 1080p دفعة واحدة. يرجى اختيار دقة 720p لحماية ذاكرة الهاتف وضمان تصدير سلس.'
    );
  }

  onProgress({
    phase: 'preparing',
    percent: 3,
    currentFrame: 0,
    totalFrames: Math.max(1, Math.ceil(totalDuration * settings.fps)),
    message: 'جاري فحص مرمّزات العتاد وتجهيز المقاطع...',
  });

  // Register pure-JS LAME MP3 encoder fallback if browser doesn't natively encode MP3
  try {
    if (!(await canEncodeAudio('mp3'))) {
      registerMp3Encoder();
    }
  } catch {
    // Non-fatal
  }

  let { width, height } = getResolutionDimensions(
    project.aspectRatio,
    settings.resolution
  );
  let downgradedResolutionNote: string | undefined;

  const mp4Format = new Mp4OutputFormat({
    fastStart: 'in-memory',
  });

  // Fast-path codec negotiation: probe H.264 ('avc') first so startup takes milliseconds
  const preferredVideoCodecs: ('avc' | 'hevc' | 'vp9' | 'av1')[] = [
    'avc',
    'hevc',
    'vp9',
    'av1',
  ];

  let selectedVideoCodec = await getFirstEncodableVideoCodec(
    preferredVideoCodecs,
    { width, height }
  );

  // Hardware fallback specifically helpful on Helio P35 / budget Android chipsets if 1080x1920 vertical exceeds profile level 4.0
  if (!selectedVideoCodec && settings.resolution === '1080p') {
    const fallbackDims = getResolutionDimensions(project.aspectRatio, '720p');
    const retryCodec = await getFirstEncodableVideoCodec(preferredVideoCodecs, {
      width: fallbackDims.width,
      height: fallbackDims.height,
    });
    if (retryCodec) {
      width = fallbackDims.width;
      height = fallbackDims.height;
      selectedVideoCodec = retryCodec;
      downgradedResolutionNote =
        'تم الضبط التلقائي إلى دقة 720p لتتوافق مع معالج الفيديو العتادي في جهازك.';
    }
  }

  checkAborted();

  // Prepare media decoders for every referenced main clip AND PIP overlay asset
  const projectOverlays = project.overlays || [];
  const projectEffects = project.effects || [];
  const usedAssetIds = new Set([
    ...project.clips.map((c) => c.assetId),
    ...projectOverlays.map((ov) => ov.assetId),
  ]);
  const mediaHandles = new Map<string, PreparedMediaHandle>();

  try {
    for (const assetId of usedAssetIds) {
      checkAborted();
      const asset = project.assets.find((a) => a.id === assetId);
      if (!asset) continue;

      if (asset.type === 'image') {
        const img = await loadImageElement(asset.url);
        mediaHandles.set(assetId, { asset, image: img });
      } else if (asset.type === 'video') {
        let sinkCreated = false;
        if (asset.blob) {
          try {
            const input = new Input({
              formats: ALL_FORMATS,
              source: new BlobSource(asset.blob),
            });
            const vTrack = await input.getPrimaryVideoTrack();
            if (vTrack && (await vTrack.canDecode())) {
              mediaHandles.set(assetId, {
                asset,
                videoTrack: vTrack,
                inputToClose: input,
              });
              sinkCreated = true;
            } else {
              input.dispose();
            }
          } catch {
            // Will gracefully use HTMLVideoElement decoder below
          }
        }

        if (!sinkCreated) {
          const fallbackVideo = await createPreparedVideoElement(asset.url);
          mediaHandles.set(assetId, { asset, fallbackVideo });
        }
      }
    }

    checkAborted();

    // Mix full multi-track project audio (original video clips + voiceovers + music + SFX)
    onProgress({
      phase: 'audio',
      percent: 12,
      currentFrame: 0,
      totalFrames: Math.max(1, Math.ceil(totalDuration * settings.fps)),
      message: 'جاري مزج المسارات الصوتية وضبط المستويات...',
    });

    const mixedAudioBuffer = await mixProjectAudioBuffer({
      assets: project.assets,
      clips: project.clips,
      audioClips: project.audioClips as AudioClip[],
      totalDuration,
      sampleRate: 48000,
      numberOfChannels: 2,
    });

    checkAborted();

    // If WebCodecs VideoEncoder is supported -> Primary True MP4 Pipeline via Mediabunny
    if (selectedVideoCodec) {
      const targetBitrate =
        settings.resolution === '1080p'
          ? settings.quality === 'high'
            ? 8_000_000
            : 5_000_000
          : settings.quality === 'high'
            ? 4_200_000
            : 2_600_000;

      const engineLabel = `MP4 (${selectedVideoCodec.toUpperCase()} WebCodecs)`;
      const target = new BufferTarget();
      const output = new Output({
        format: mp4Format,
        target,
      });

      const exportCanvas = document.createElement('canvas');
      exportCanvas.width = width;
      exportCanvas.height = height;
      const exportCtx = exportCanvas.getContext('2d', {
        alpha: false,
      })!;

      const videoSource = new CanvasSource(exportCanvas, {
        codec: selectedVideoCodec,
        bitrate: new Quality({ bitrate: targetBitrate }),
        latencyMode: 'realtime',
      });
      output.addVideoTrack(videoSource, {
        frameRate: settings.fps,
      });

      let audioSource: AudioBufferSource | null = null;
      if (mixedAudioBuffer) {
        const selectedAudioCodec = await getFirstEncodableAudioCodec(
          ['aac', 'opus', 'mp3', 'flac'],
          {
            numberOfChannels: mixedAudioBuffer.numberOfChannels,
            sampleRate: mixedAudioBuffer.sampleRate,
          }
        );

        if (selectedAudioCodec) {
          audioSource = new AudioBufferSource({
            codec: selectedAudioCodec,
            bitrate: new Quality({ bitrate: 128_000 }),
          });
          output.addAudioTrack(audioSource);
        }
      }

      await output.start();

      if (audioSource && mixedAudioBuffer) {
        await audioSource.add(mixedAudioBuffer);
      }

      const fps = settings.fps;
      const totalFrames = Math.max(1, Math.round(totalDuration * fps));
      const frameDuration = 1 / fps;
      const slots = computeClipSlots(project.clips);

      // Pre-compute monotonically sorted timestamp schedules per clip ID so each clip
      // streams sequentially through hardware VideoDecoder in a SINGLE forward pass (20x faster & tiny RAM footprint!)
      const framePlan = Array.from({ length: totalFrames }, (_, f) => {
        const timeSec = Math.min(totalDuration - 0.0005, f / fps);
        return {
          timeSec: Math.max(0, timeSec),
          resolved: resolveTimelineAtTime(slots, Math.max(0, timeSec)),
        };
      });

      const clipSchedules = new Map<string, number[]>();
      for (const step of framePlan) {
        for (const req of [step.resolved.secondary, step.resolved.primary]) {
          if (!req || req.clip.type !== 'video') continue;
          let arr = clipSchedules.get(req.clip.id);
          if (!arr) {
            arr = [];
            clipSchedules.set(req.clip.id, arr);
          }
          // Guarantee monotonic non-decreasing timestamps for zero re-seeking
          const prevT = arr.length > 0 ? arr[arr.length - 1] : 0;
          arr.push(Math.max(prevT, req.sourceTime));
        }
      }

      const clipIterators = new Map<
        string,
        AsyncGenerator<WrappedCanvas | null, void, unknown>
      >();
      for (const clip of project.clips) {
        const schedule = clipSchedules.get(clip.id);
        const handle = mediaHandles.get(clip.assetId);
        if (schedule && schedule.length > 0 && handle?.videoTrack) {
          const sink = new CanvasSink(handle.videoTrack, {
            width: Math.min(width, handle.videoTrack.displayWidth || width),
            poolSize: 2,
          });
          clipIterators.set(clip.id, sink.canvasesAtTimestamps(schedule));
        }
      }

      // Zero-GC reusable frame buffers for incoming/outgoing clips
      const currentFrameMap = new Map<string, DrawableMedia | null>();
      const slotCopyCanvases: Record<string, HTMLCanvasElement> = {
        A: document.createElement('canvas'),
        B: document.createElement('canvas'),
      };

      const fetchSingleMediaAt = async (
        clip: VideoClip,
        sourceTime: number,
        slotTag: 'A' | 'B'
      ): Promise<DrawableMedia | null> => {
        const handle = mediaHandles.get(clip.assetId);
        if (!handle) return null;
        if (handle.image) return handle.image;

        const copy = slotCopyCanvases[slotTag];
        const iter = clipIterators.get(clip.id);

        if (iter) {
          const nextRes = await iter.next();
          const wrapped = nextRes.value;
          if (wrapped?.canvas) {
            if (
              copy.width !== wrapped.canvas.width ||
              copy.height !== wrapped.canvas.height
            ) {
              copy.width = wrapped.canvas.width;
              copy.height = wrapped.canvas.height;
            }
            copy.getContext('2d')!.drawImage(wrapped.canvas, 0, 0);
            return copy;
          }
          return null;
        }

        if (handle.fallbackVideo) {
          await seekVideoElement(handle.fallbackVideo, sourceTime);
          const vw = handle.fallbackVideo.videoWidth || width;
          const vh = handle.fallbackVideo.videoHeight || height;
          if (copy.width !== vw || copy.height !== vh) {
            copy.width = vw;
            copy.height = vh;
          }
          copy.getContext('2d')!.drawImage(handle.fallbackVideo, 0, 0);
          return copy;
        }

        return null;
      };

      try {
      for (let f = 0; f < totalFrames; f++) {
        checkAborted();
        const { timeSec, resolved } = framePlan[f];

        currentFrameMap.clear();

        if (resolved.secondary) {
          const mediaSec = await fetchSingleMediaAt(
            resolved.secondary.clip,
            resolved.secondary.sourceTime,
            'A'
          );
          currentFrameMap.set(
            `${resolved.secondary.clip.id}_${resolved.secondary.sourceTime.toFixed(4)}`,
            mediaSec
          );
        }
        if (resolved.primary) {
          const mediaPri = await fetchSingleMediaAt(
            resolved.primary.clip,
            resolved.primary.sourceTime,
            'B'
          );
          currentFrameMap.set(
            `${resolved.primary.clip.id}_${resolved.primary.sourceTime.toFixed(4)}`,
            mediaPri
          );
        }

        // Also resolve any active PIP video overlays for this timestamp
        const overlayFrameMap = new Map<string, DrawableMedia | null>();
        const slotCopyOverlay = document.createElement('canvas');
        for (const ov of projectOverlays) {
          if (timeSec < ov.startTime || timeSec > ov.startTime + ov.duration) {
            continue;
          }
          const h = mediaHandles.get(ov.assetId);
          if (h?.image) {
            overlayFrameMap.set(ov.id, h.image);
          } else if (h?.fallbackVideo) {
            await seekVideoElement(
              h.fallbackVideo,
              ov.trimStart + (timeSec - ov.startTime)
            );
            slotCopyOverlay.width = h.fallbackVideo.videoWidth || 360;
            slotCopyOverlay.height = h.fallbackVideo.videoHeight || 640;
            slotCopyOverlay.getContext('2d')!.drawImage(h.fallbackVideo, 0, 0);
            overlayFrameMap.set(ov.id, slotCopyOverlay);
          } else if (h?.videoTrack) {
            const ovSink = new CanvasSink(h.videoTrack, { width: 480, poolSize: 1 });
            const w = await ovSink.getCanvas(
              Math.max(0, ov.trimStart + (timeSec - ov.startTime))
            );
            if (w?.canvas) overlayFrameMap.set(ov.id, w.canvas);
          }
        }

        renderCompositeFrame({
          ctx: exportCtx,
          width,
          height,
          clips: project.clips,
          texts: project.texts,
          effects: projectEffects,
          overlays: projectOverlays,
          bgColor: project.canvasBgColor || '#000000',
          timeSec: Math.max(0, timeSec),
          getMediaFrame: (clip, sTime) =>
            currentFrameMap.get(`${clip.id}_${sTime.toFixed(4)}`) ?? null,
          getOverlayFrame: (ov) => overlayFrameMap.get(ov.id) ?? null,
        });

        await videoSource.add(f * frameDuration, frameDuration, {
          keyFrame: f % (fps * 2) === 0,
        });

        const pct = 16 + Math.round(((f + 1) / totalFrames) * 78);
        onProgress({
          phase: 'video',
          percent: pct,
          currentFrame: f + 1,
          totalFrames,
          message: `جاري ترميز الفيديو (${f + 1} من ${totalFrames} إطار)...`,
          engineLabel,
        });

        if (f % 6 === 0) {
          await new Promise((r) => setTimeout(r, 0));
        }
      }
      } finally {
        for (const iter of clipIterators.values()) {
          await iter.return?.().catch(() => {});
        }
      }

      onProgress({
        phase: 'finalizing',
        percent: 96,
        currentFrame: totalFrames,
        totalFrames,
        message: 'جاري تجميع حاوية MP4 النهائية وتثبيت الفهرس السريع...',
        engineLabel,
      });

      await output.finalize();

      const finalBuffer = target.buffer;
      if (!finalBuffer || finalBuffer.byteLength === 0) {
        throw new Error('فشل إنتاج بيانات ملف MP4 النهائي.');
      }

      const blob = new Blob([finalBuffer], { type: 'video/mp4' });
      const url = URL.createObjectURL(blob);
      const safeName =
        (project.name || 'لقطة-برو')
          .replace(/[^\u0600-\u06FFa-zA-Z0-9_-]+/g, '-')
          .replace(/^-+|-+$/g, '') || 'laqta-pro';

      onProgress({
        phase: 'done',
        percent: 100,
        currentFrame: totalFrames,
        totalFrames,
        message: 'اكتمل تصدير ملف الفيديو بنجاح!',
        engineLabel,
      });

      return {
        blob,
        url,
        fileName: `${safeName}-${settings.resolution}.mp4`,
        mimeType: 'video/mp4',
        width,
        height,
        duration: totalDuration,
        sizeBytes: blob.size,
        engineUsed: engineLabel,
        downgradedResolutionNote,
      };
    }

    // Fallback engine if WebCodecs is disabled on an older browser: MediaStream real muxer
    return await fallbackMediaRecorderExport({
      project,
      width,
      height,
      fps: settings.fps,
      totalDuration,
      mixedAudioBuffer,
      mediaHandles,
      onProgress,
      signal,
    });
  } finally {
    // Always release hardware decoders and memory handles immediately
    for (const handle of mediaHandles.values()) {
      try {
        handle.inputToClose?.dispose();
      } catch {
        // ignore
      }
      if (handle.fallbackVideo) {
        handle.fallbackVideo.pause();
        handle.fallbackVideo.removeAttribute('src');
        handle.fallbackVideo.load();
      }
    }
  }
}

async function fallbackMediaRecorderExport(params: {
  project: ProjectData;
  width: number;
  height: number;
  fps: number;
  totalDuration: number;
  mixedAudioBuffer: AudioBuffer | null;
  mediaHandles: Map<string, PreparedMediaHandle>;
  onProgress: (p: ExportProgress) => void;
  signal?: AbortSignal;
}): Promise<ExportResult> {
  const {
    project,
    width,
    height,
    fps,
    totalDuration,
    mixedAudioBuffer,
    mediaHandles,
    onProgress,
    signal,
  } = params;

  const candidates = [
    'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    'video/mp4',
    'video/webm;codecs=vp9,opus',
    'video/webm',
  ];
  const supportedMime =
    candidates.find((m) => MediaRecorder.isTypeSupported(m)) || 'video/webm';
  const isMp4 = supportedMime.startsWith('video/mp4');

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
  const stream = canvas.captureStream(fps);

  let audioCtx: AudioContext | null = null;
  if (mixedAudioBuffer) {
    audioCtx = new AudioContext();
    const dest = audioCtx.createMediaStreamDestination();
    const src = audioCtx.createBufferSource();
    src.buffer = mixedAudioBuffer;
    src.connect(dest);
    src.start(0);
    dest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
  }

  const chunks: BlobPart[] = [];
  const recorder = new MediaRecorder(stream, {
    mimeType: supportedMime,
    videoBitsPerSecond: 3_500_000,
  });
  recorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };

  const stopped = new Promise<void>((resolve) => {
    recorder.onstop = () => resolve();
  });

  recorder.start(200);
  const totalFrames = Math.max(1, Math.round(totalDuration * fps));
  const slots = computeClipSlots(project.clips);
  const startWall = performance.now();

  try {
    let f = 0;
    while (true) {
      if (signal?.aborted) {
        recorder.stop();
        throw new DOMException('تم إلغاء التصدير', 'AbortError');
      }
      const elapsed = (performance.now() - startWall) / 1000;
      if (elapsed >= totalDuration) break;

      const resolved = resolveTimelineAtTime(slots, elapsed);
      const frameMap = new Map<string, DrawableMedia | null>();
      for (const req of [resolved.secondary, resolved.primary]) {
        if (!req) continue;
        const h = mediaHandles.get(req.clip.assetId);
        if (h?.image) {
          frameMap.set(`${req.clip.id}_${req.sourceTime.toFixed(4)}`, h.image);
        } else if (h?.fallbackVideo) {
          await seekVideoElement(h.fallbackVideo, req.sourceTime);
          frameMap.set(
            `${req.clip.id}_${req.sourceTime.toFixed(4)}`,
            h.fallbackVideo
          );
        }
      }

      renderCompositeFrame({
        ctx,
        width,
        height,
        clips: project.clips,
        texts: project.texts,
        bgColor: project.canvasBgColor || '#090B10',
        timeSec: elapsed,
        getMediaFrame: (c, s) =>
          frameMap.get(`${c.id}_${s.toFixed(4)}`) ?? null,
      });

      f++;
      onProgress({
        phase: 'video',
        percent: Math.min(96, Math.round((elapsed / totalDuration) * 95)),
        currentFrame: Math.min(totalFrames, f),
        totalFrames,
        message: 'جاري التصدير عبر المحرك الاحتياطي للمتصفح...',
        engineLabel: isMp4 ? 'MP4 Native Stream' : 'WebM Fallback Stream',
      });

      await new Promise((r) => setTimeout(r, 1000 / fps));
    }

    recorder.stop();
    await stopped;
  } finally {
    await audioCtx?.close();
  }

  const ext = isMp4 ? 'mp4' : 'webm';
  const blob = new Blob(chunks, {
    type: isMp4 ? 'video/mp4' : 'video/webm',
  });
  return {
    blob,
    url: URL.createObjectURL(blob),
    fileName: `${project.name || 'laqta-pro'}.${ext}`,
    mimeType: blob.type,
    width,
    height,
    duration: totalDuration,
    sizeBytes: blob.size,
    engineUsed: isMp4 ? 'MP4 Stream Recorder' : 'WebM Stream (متصفح بدون WebCodecs)',
  };
}
