import {
  AudioBufferSource,
  BufferTarget,
  CanvasSource,
  canEncodeAudio,
  getFirstEncodableAudioCodec,
  getFirstEncodableVideoCodec,
  Mp4OutputFormat,
  Output,
  Quality,
} from 'mediabunny';
import { registerMp3Encoder } from '@mediabunny/mp3-encoder';
import { decodeMediaAudio, extractWaveformPeaks } from '../engine/audioEngine';
import { MediaAsset, MediaType } from '../types/editor';

export interface ImportCheckResult {
  asset: MediaAsset;
  memoryWarning?: string;
}

const MAX_SAFE_FILE_BYTES_LOW_RAM = 260 * 1024 * 1024; // 260 MB guard for 3-4GB RAM phones like Samsung A04
const MAX_HARD_FILE_BYTES = 650 * 1024 * 1024; // 650 MB hard browser tab guard

export function detectMediaType(file: File): MediaType | null {
  const mime = (file.type || '').toLowerCase();
  const ext = file.name.split('.').pop()?.toLowerCase() || '';

  if (
    mime.startsWith('video/') ||
    ['mp4', 'mov', 'webm', 'mkv', 'm4v', '3gp'].includes(ext)
  ) {
    return 'video';
  }
  if (
    mime.startsWith('image/') ||
    ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'].includes(ext)
  ) {
    return 'image';
  }
  if (
    mime.startsWith('audio/') ||
    ['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac', 'opus'].includes(ext)
  ) {
    return 'audio';
  }
  return null;
}

export async function importMediaFile(file: File): Promise<ImportCheckResult> {
  if (file.size > MAX_HARD_FILE_BYTES) {
    throw new Error(
      `حجم الملف «${file.name}» كبير جداً (${(file.size / 1024 / 1024).toFixed(0)} ميجابايت) وقد يتجاوز ذاكرة الهاتف المتاحة. يرجى اختيار ملف أصغر من 650 ميجابايت أو تقسيمه مسبقاً.`
    );
  }

  const type = detectMediaType(file);
  if (!type) {
    throw new Error(
      `صيغة الملف «${file.name}» غير مدعومة. يرجى اختيار ملف فيديو (MP4/MOV/WebM) أو صورة (JPG/PNG/WebP) أو صوت (MP3/WAV/M4A).`
    );
  }

  const deviceRam =
    (navigator as Navigator & { deviceMemory?: number }).deviceMemory || 4;
  let memoryWarning: string | undefined;
  if (
    file.size > MAX_SAFE_FILE_BYTES_LOW_RAM ||
    (deviceRam <= 4 && file.size > 140 * 1024 * 1024)
  ) {
    memoryWarning = `تنبيه ذاكرة: حجم «${file.name}» كبير نسبياً (${(file.size / 1024 / 1024).toFixed(1)} MB). يُنصح بالتصدير بدقة 720p لأفضل استقرار على الهاتف.`;
  }

  const id = `asset_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const url = URL.createObjectURL(file);

  if (type === 'video') {
    const meta = await extractVideoMetadataAndThumbnail(url);
    if ((meta.width >= 3840 || meta.height >= 2160) && !memoryWarning) {
      memoryWarning = `الفيديو بدقة 4K (${meta.width}×${meta.height}). سيقوم «لقطة برو» بتحسين استهلاك الذاكرة تلقائياً أثناء المعاينة والتصدير.`;
    }
    const baseAsset: MediaAsset = {
      id,
      name: file.name,
      type: 'video',
      mimeType: file.type || 'video/mp4',
      sizeBytes: file.size,
      duration: Math.max(0.2, meta.duration),
      width: meta.width,
      height: meta.height,
      thumbnailDataUrl: meta.thumbnailDataUrl,
      url,
      blob: file,
      createdAt: Date.now(),
    };

    // Extract audio waveform in background-safe manner
    const audioBuf = await decodeMediaAudio(baseAsset);
    if (audioBuf) {
      baseAsset.waveformPeaks = extractWaveformPeaks(audioBuf, 64);
    }

    return { asset: baseAsset, memoryWarning };
  }

  if (type === 'image') {
    const meta = await extractImageMetadataAndThumbnail(url);
    return {
      asset: {
        id,
        name: file.name,
        type: 'image',
        mimeType: file.type || 'image/png',
        sizeBytes: file.size,
        duration: 4.0,
        width: meta.width,
        height: meta.height,
        thumbnailDataUrl: meta.thumbnailDataUrl,
        url,
        blob: file,
        createdAt: Date.now(),
      },
      memoryWarning,
    };
  }

  // Audio file
  const tempAsset: MediaAsset = {
    id,
    name: file.name,
    type: 'audio',
    mimeType: file.type || 'audio/mpeg',
    sizeBytes: file.size,
    duration: 5.0,
    url,
    blob: file,
    createdAt: Date.now(),
  };

  const decoded = await decodeMediaAudio(tempAsset);
  if (decoded) {
    tempAsset.duration = Math.max(0.2, decoded.duration);
    tempAsset.waveformPeaks = extractWaveformPeaks(decoded, 72);
  } else {
    const htmlDur = await probeHtmlAudioDuration(url);
    tempAsset.duration = Math.max(0.2, htmlDur);
  }

  return { asset: tempAsset, memoryWarning };
}

function extractVideoMetadataAndThumbnail(url: string): Promise<{
  duration: number;
  width: number;
  height: number;
  thumbnailDataUrl: string;
}> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;
    video.crossOrigin = 'anonymous';
    video.src = url;

    let done = false;
    const failTimer = window.setTimeout(() => {
      if (!done) {
        done = true;
        cleanup();
        reject(
          new Error('انتهت مهلة قراءة ملف الفيديو. قد يكون الترميز تالفاً أو غير مدعوم.')
        );
      }
    }, 10000);

    const cleanup = () => {
      clearTimeout(failTimer);
      video.pause();
      video.removeAttribute('src');
      video.load();
    };

    video.onerror = () => {
      if (done) return;
      done = true;
      cleanup();
      reject(
        new Error('تعذر تشغيل هذا الفيديو على المتصفح الحالي. جرب ملف MP4 (H.264).')
      );
    };

    video.onloadedmetadata = () => {
      const targetSeek = Math.min(0.5, Math.max(0.05, (video.duration || 1) * 0.15));
      video.currentTime = targetSeek;
    };

    video.onseeked = () => {
      if (done) return;
      done = true;
      const vw = video.videoWidth || 1280;
      const vh = video.videoHeight || 720;
      const thumbW = 240;
      const thumbH = Math.max(135, Math.round((vh / vw) * thumbW));
      const c = document.createElement('canvas');
      c.width = thumbW;
      c.height = thumbH;
      const ctx = c.getContext('2d')!;
      ctx.drawImage(video, 0, 0, thumbW, thumbH);
      const thumbnailDataUrl = c.toDataURL('image/jpeg', 0.72);
      const duration = Number.isFinite(video.duration) ? video.duration : 5;
      cleanup();
      resolve({ duration, width: vw, height: vh, thumbnailDataUrl });
    };
  });
}

function extractImageMetadataAndThumbnail(url: string): Promise<{
  width: number;
  height: number;
  thumbnailDataUrl: string;
}> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const iw = img.naturalWidth || 1080;
      const ih = img.naturalHeight || 1080;
      const thumbW = 240;
      const thumbH = Math.max(135, Math.round((ih / iw) * thumbW));
      const c = document.createElement('canvas');
      c.width = thumbW;
      c.height = thumbH;
      c.getContext('2d')!.drawImage(img, 0, 0, thumbW, thumbH);
      resolve({
        width: iw,
        height: ih,
        thumbnailDataUrl: c.toDataURL('image/jpeg', 0.75),
      });
    };
    img.onerror = () => reject(new Error('تعذر قراءة ملف الصورة.'));
    img.src = url;
  });
}

function probeHtmlAudioDuration(url: string): Promise<number> {
  return new Promise((resolve) => {
    const a = document.createElement('audio');
    a.preload = 'metadata';
    a.onloadedmetadata = () => resolve(Number.isFinite(a.duration) ? a.duration : 5);
    a.onerror = () => resolve(5);
    a.src = url;
  });
}

/**
 * Generates real, playable MP4 video files with animated scenes & musical audio
 * right in the browser so users can immediately test real MP4 import, trimming,
 * transitions, color grading, Arabic captions, and MP4 re-export in one click!
 */
export type SampleVideoTheme =
  | 'desert-sunset'
  | 'neon-city'
  | 'celestial-night'
  | 'emerald-sanctuary';

export async function generateSampleMp4File(
  theme: SampleVideoTheme,
  durationSec = 3.0,
  silentAudio = false
): Promise<File> {
  try {
    if (!(await canEncodeAudio('mp3'))) {
      registerMp3Encoder();
    }
  } catch {
    // ignore
  }

  const width = 640;
  const height = 1136; // 9:16 mobile portrait
  const fps = 24;
  const totalFrames = Math.round(durationSec * fps);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const format = new Mp4OutputFormat({ fastStart: 'in-memory' });
  const target = new BufferTarget();
  const output = new Output({ format, target });

  const vCodec =
    (await getFirstEncodableVideoCodec(['avc', 'vp9', 'av1'], {
      width,
      height,
    })) || 'avc';

  const vSource = new CanvasSource(canvas, {
    codec: vCodec,
    bitrate: new Quality({ bitrate: 2_200_000 }),
    latencyMode: 'realtime',
  });
  output.addVideoTrack(vSource, { frameRate: fps });

  // Synthesize audio track (pure silence for Quranic background videos so recitation is crystal pure!)
  const sampleRate = 48000;
  const offline = new OfflineAudioContext(
    2,
    Math.ceil(durationSec * sampleRate),
    sampleRate
  );
  if (!silentAudio && theme !== 'celestial-night' && theme !== 'emerald-sanctuary') {
    const notes =
      theme === 'desert-sunset'
        ? [220, 277.18, 329.63, 440]
        : [261.63, 329.63, 392.0, 523.25];
    notes.forEach((freq) => {
      const osc = offline.createOscillator();
      const g = offline.createGain();
      osc.type = 'triangle';
      osc.frequency.value = freq;
      g.gain.setValueAtTime(0.01, 0);
      g.gain.linearRampToValueAtTime(0.09, 0.25);
      g.gain.exponentialRampToValueAtTime(0.01, durationSec);
      osc.connect(g);
      g.connect(offline.destination);
      osc.start(0);
      osc.stop(durationSec);
    });
  }
  const audioBuffer = await offline.startRendering();

  const aCodec = await getFirstEncodableAudioCodec(
    format.getSupportedAudioCodecs(),
    { numberOfChannels: 2, sampleRate }
  );
  let aSource: AudioBufferSource | null = null;
  if (aCodec) {
    aSource = new AudioBufferSource({
      codec: aCodec,
      bitrate: new Quality({ bitrate: 128_000 }),
    });
    output.addAudioTrack(aSource);
  }

  await output.start();
  if (aSource) {
    await aSource.add(audioBuffer);
  }

  for (let f = 0; f < totalFrames; f++) {
    const p = f / totalFrames;
    if (theme === 'desert-sunset') {
      const sky = ctx.createLinearGradient(0, 0, 0, height);
      sky.addColorStop(0, '#1e1b4b');
      sky.addColorStop(0.48, '#c2410c');
      sky.addColorStop(0.82, '#fb923c');
      sky.addColorStop(1, '#451a03');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, width, height);

      // Animated golden sun
      const sunY = height * (0.46 - p * 0.12);
      const sunX = width * (0.5 + Math.sin(p * Math.PI) * 0.06);
      const sunGlow = ctx.createRadialGradient(sunX, sunY, 20, sunX, sunY, 220);
      sunGlow.addColorStop(0, '#fef08a');
      sunGlow.addColorStop(0.35, 'rgba(251, 146, 60, 0.75)');
      sunGlow.addColorStop(1, 'rgba(251, 146, 60, 0)');
      ctx.fillStyle = sunGlow;
      ctx.fillRect(0, 0, width, height);

      ctx.beginPath();
      ctx.arc(sunX, sunY, 68, 0, Math.PI * 2);
      ctx.fillStyle = '#fef9c3';
      ctx.fill();

      // Parallax desert dunes
      for (let layer = 0; layer < 3; layer++) {
        ctx.beginPath();
        const baseH = height * (0.66 + layer * 0.1);
        ctx.moveTo(0, height);
        for (let x = 0; x <= width; x += 16) {
          const wave =
            Math.sin((x / width) * Math.PI * 2.2 + p * 2.5 + layer * 1.4) *
            (34 - layer * 6);
          ctx.lineTo(x, baseH + wave);
        }
        ctx.lineTo(width, height);
        ctx.closePath();
        ctx.fillStyle =
          layer === 0 ? '#9a3412' : layer === 1 ? '#7c2d12' : '#431407';
        ctx.fill();
      }
    } else {
      // Neon cyber night skyline
      const bg = ctx.createLinearGradient(0, 0, width, height);
      bg.addColorStop(0, '#020617');
      bg.addColorStop(0.55, '#0f172a');
      bg.addColorStop(1, '#1e1b4b');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      // Moving neon light beams
      for (let b = 0; b < 5; b++) {
        ctx.save();
        const beamX = ((b * 160 + p * 260) % (width + 200)) - 100;
        const grad = ctx.createLinearGradient(beamX, 0, beamX + 90, height);
        grad.addColorStop(0, 'rgba(34, 211, 238, 0.28)');
        grad.addColorStop(1, 'rgba(168, 85, 247, 0.02)');
        ctx.fillStyle = grad;
        ctx.transform(1, 0, -0.25, 1, 0, 0);
        ctx.fillRect(beamX, 0, 75, height);
        ctx.restore();
      }

      // Futuristic skyline towers + lit windows
      for (let i = 0; i < 9; i++) {
        const tw = 78;
        const th = 260 + ((i * 113) % 340);
        const tx = i * 74 - p * 45;
        const ty = height - th;
        ctx.fillStyle = '#090d1a';
        ctx.fillRect(tx, ty, tw - 8, th);
        ctx.strokeStyle = i % 2 === 0 ? '#22d3ee' : '#c084fc';
        ctx.lineWidth = 2;
        ctx.strokeRect(tx, ty, tw - 8, th);
      }

      // Glowing cyber horizon grid
      ctx.strokeStyle = 'rgba(34, 211, 238, 0.45)';
      ctx.lineWidth = 2;
      for (let g = 0; g < 8; g++) {
        const gy = height * 0.78 + g * 28 + ((p * 28) % 28);
        ctx.beginPath();
        ctx.moveTo(0, gy);
        ctx.lineTo(width, gy);
        ctx.stroke();
      }
    }

    if (theme === 'celestial-night') {
      // Serene Starry Night Sky + Glowing Crescent Moon + Tranquil Horizon for Holy Quran Videos
      const night = ctx.createLinearGradient(0, 0, 0, height);
      night.addColorStop(0, '#030712');
      night.addColorStop(0.55, '#0b192c');
      night.addColorStop(0.85, '#172554');
      night.addColorStop(1, '#090d16');
      ctx.fillStyle = night;
      ctx.fillRect(0, 0, width, height);

      // Soft twinkling stars
      for (let s = 0; s < 55; s++) {
        const sx = ((s * 97.3) % width);
        const sy = ((s * 61.7) % (height * 0.75));
        const twinkle = 0.35 + 0.65 * Math.abs(Math.sin(p * Math.PI * 3 + s));
        ctx.fillStyle = `rgba(254, 249, 195, ${twinkle.toFixed(2)})`;
        ctx.beginPath();
        ctx.arc(sx, sy, 1.2 + (s % 3) * 0.7, 0, Math.PI * 2);
        ctx.fill();
      }

      // Glowing golden crescent moon high in the sky
      const mx = width * 0.76;
      const my = height * (0.16 - p * 0.02);
      const moonGlow = ctx.createRadialGradient(mx, my, 8, mx, my, 130);
      moonGlow.addColorStop(0, 'rgba(253, 224, 71, 0.45)');
      moonGlow.addColorStop(1, 'rgba(253, 224, 71, 0)');
      ctx.fillStyle = moonGlow;
      ctx.fillRect(0, 0, width, height);

      ctx.save();
      ctx.fillStyle = '#FEF08A';
      ctx.beginPath();
      ctx.arc(mx, my, 32, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(mx - 12, my - 8, 29, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      ctx.fillStyle = '#071120';
      ctx.beginPath();
      ctx.arc(mx - 12, my - 8, 28, 0, Math.PI * 2);
      ctx.fill();

      // Serene mountain silhouettes at bottom
      for (let m = 0; m < 2; m++) {
        ctx.beginPath();
        ctx.moveTo(0, height);
        for (let x = 0; x <= width; x += 18) {
          const hOff =
            Math.sin((x / width) * Math.PI * (2 + m) + p * 0.8 + m) * 26;
          ctx.lineTo(x, height * (0.8 + m * 0.06) + hOff);
        }
        ctx.lineTo(width, height);
        ctx.closePath();
        ctx.fillStyle = m === 0 ? '#081226' : '#030712';
        ctx.fill();
      }
    } else if (theme === 'emerald-sanctuary') {
      // Peaceful Deep Emerald & Gold Sanctuary Ambient Scene for Holy Quran Recitation
      const em = ctx.createLinearGradient(0, 0, 0, height);
      em.addColorStop(0, '#021814');
      em.addColorStop(0.5, '#06372d');
      em.addColorStop(0.85, '#084c3e');
      em.addColorStop(1, '#021a15');
      ctx.fillStyle = em;
      ctx.fillRect(0, 0, width, height);

      // Soft warm golden light aura in center
      const aura = ctx.createRadialGradient(
        width / 2,
        height * 0.42,
        20,
        width / 2,
        height * 0.42,
        width * 0.72
      );
      aura.addColorStop(0, 'rgba(251, 191, 36, 0.24)');
      aura.addColorStop(1, 'rgba(6, 78, 59, 0)');
      ctx.fillStyle = aura;
      ctx.fillRect(0, 0, width, height);

      // Gently rising golden light particles
      for (let g = 0; g < 35; g++) {
        const gx = ((g * 83.5 + Math.sin(p * 4 + g) * 18 + width) % width);
        const gy = height - (((g * 79.1 + p * 220) % height));
        ctx.fillStyle = `rgba(253, 224, 71, ${(0.25 + (g % 4) * 0.14).toFixed(2)})`;
        ctx.beginPath();
        ctx.arc(gx, gy, 2 + (g % 3) * 1.3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    await vSource.add(f / fps, 1 / fps, { keyFrame: f % 24 === 0 });
  }

  await output.finalize();
  const fileName =
    theme === 'celestial-night'
      ? 'سماء-السكينة-القرآنية.mp4'
      : theme === 'emerald-sanctuary'
        ? 'واحة-النور-القرآنية.mp4'
        : theme === 'desert-sunset'
          ? 'غروب-ذهبي-صحراوي.mp4'
          : 'أضواء-المدينة-الليلية.mp4';
  return new File([target.buffer!], fileName, { type: 'video/mp4' });
}
