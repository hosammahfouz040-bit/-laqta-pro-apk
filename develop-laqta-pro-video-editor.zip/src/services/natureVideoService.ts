import { generateSampleMp4File, SampleVideoTheme } from './mediaService';

export type NaturePackId =
  | 'mixed-nature'
  | 'waterfalls-rivers'
  | 'ocean-waves-sunset'
  | 'misty-mountains-clouds'
  | 'snow-peaks-sky'
  | 'spring-meadows-flowers'
  | 'rain-forest'
  | 'night-stars-moon'
  | 'mosque-skies'
  | 'mountains-desert';

export interface StockNatureClipSpec {
  id: string;
  nameAr: string;
  pack: Exclude<NaturePackId, 'mixed-nature'>;
  orientation: 'portrait' | 'landscape';
  durationHint: number;
  url: string;
  thumbnailUrl: string;
  fallbackProceduralTheme: SampleVideoTheme;
}

export const NATURE_PACK_OPTIONS: {
  id: NaturePackId;
  labelAr: string;
  descAr: string;
}[] = [
  {
    id: 'mixed-nature',
    labelAr: 'تشكيلة طبيعة وآفاق متنوعة 🌍🏞️',
    descAr: 'تتابع هادئ غني بين الشلالات والبحار والجبال والغابات والنجوم لطول دقيقة فأكثر',
  },
  {
    id: 'waterfalls-rivers',
    labelAr: 'شلالات وأنهار الغابات الصافية 🏞️💧',
    descAr: 'مياه جارية وشلالات طبيعية صافية للريلز والفيديو الطويل',
  },
  {
    id: 'ocean-waves-sunset',
    labelAr: 'أمواج البحر وغروب الشاطئ 🌊🌅',
    descAr: 'أمواج الشاطئ الهادئة وشفق الغروب الذهبي على امتداد الأفق',
  },
  {
    id: 'misty-mountains-clouds',
    labelAr: 'جبال خضراء وضباب وسحب عابرة ⛰️☁️',
    descAr: 'لقطات جوية هادئة للوديان الخضراء والسحب المنسابة بين القمم',
  },
  {
    id: 'snow-peaks-sky',
    labelAr: 'قمم ثلجية فوق السحاب وسماء صافية 🏔️❄️',
    descAr: 'مشاهد جليلة لقمم الجبال البيضاء وتدفق الغيوم السماوية',
  },
  {
    id: 'spring-meadows-flowers',
    labelAr: 'مروج وزهور الربيع في النسيم 🌸🌿',
    descAr: 'حقول زهور طبيعية تتمايل بهدوء تحت ضوء الشمس الدافئ',
  },
  {
    id: 'rain-forest',
    labelAr: 'قطرات المطر والندى والأشجار 🌧️🍃',
    descAr: 'قطرات المطر والندى الصافية فوق أوراق الأشجار الخضراء',
  },
  {
    id: 'night-stars-moon',
    labelAr: 'سماء الليل والنجوم والقمر 🌌🌙',
    descAr: 'البدر خلف السحب وبانوراما النجوم لقيام الليل والتدبر',
  },
  {
    id: 'mosque-skies',
    labelAr: 'قباب المساجد والسحب السماوية 🕌☁️',
    descAr: 'عمارة إسلامية مهيبة وسط الطبيعة وتحت السماء الصافية',
  },
  {
    id: 'mountains-desert',
    labelAr: 'رمال الصحراء الذهبية والآفاق 🏜️🌅',
    descAr: 'تموجات الكثبان الرملية الذهبية وسكون الصحراء المهيب',
  },
];

// 28 Verified Real Camera HD MP4 Videos (HTTP 200 OK + CORS: * + Fast Mobile Sizes!)
export const REAL_NATURE_STOCK_VIDEOS: StockNatureClipSpec[] = [
  // 1. Waterfalls & Rivers (6 clips: Portrait 9:16 + Landscape 16:9)
  {
    id: 'nat_waterfall_lake_p',
    nameAr: 'شلال متدفق في بحيرة فيروزية',
    pack: 'waterfalls-rivers',
    orientation: 'portrait',
    durationHint: 10,
    url: 'https://videos.pexels.com/video-files/8832065/8832065-hd_1080_1920_25fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/8832065/blue-blue-lake-blue-water-forest-8832065.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_forest_stream_p',
    nameAr: 'جدول مياه عذب وسط الغابة الخضراء',
    pack: 'waterfalls-rivers',
    orientation: 'portrait',
    durationHint: 5,
    url: 'https://videos.pexels.com/video-files/16190513/16190513-hd_1080_1920_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/16190513/pexels-photo-16190513.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_mountain_falls_p',
    nameAr: 'شلال جبلي صافي متدفق',
    pack: 'waterfalls-rivers',
    orientation: 'portrait',
    durationHint: 10,
    url: 'https://videos.pexels.com/video-files/5162942/5162942-hd_1080_1920_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/5162942/waterfall-background-5162942.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'celestial-night',
  },
  {
    id: 'nat_mag_waterfall_l',
    nameAr: 'شلال طبيعي مهيب في الوادي (16:9)',
    pack: 'waterfalls-rivers',
    orientation: 'landscape',
    durationHint: 7,
    url: 'https://videos.pexels.com/video-files/5250796/5250796-hd_1920_1080_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/5250796/pexels-photo-5250796.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_cliff_waterfall_l',
    nameAr: 'شلالات جبلية منحدرة وسط الضباب (16:9)',
    pack: 'waterfalls-rivers',
    orientation: 'landscape',
    durationHint: 13,
    url: 'https://videos.pexels.com/video-files/5408564/5408564-hd_1920_1080_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/5408564/pexels-photo-5408564.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_aerial_waterfall_l',
    nameAr: 'مشهد جوي لشلالات الغابة الواسعة (16:9)',
    pack: 'waterfalls-rivers',
    orientation: 'landscape',
    durationHint: 26,
    url: 'https://videos.pexels.com/video-files/5984500/5984500-hd_1920_1080_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/5984500/argentina-brazil-waterfall-waterfalls-5984500.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },

  // 2. Ocean Waves & Golden Sunset Horizon (4 clips)
  {
    id: 'nat_beach_sunset_p',
    nameAr: 'غروب الشمس الهادئ على أمواج الشاطئ',
    pack: 'ocean-waves-sunset',
    orientation: 'portrait',
    durationHint: 8,
    url: 'https://videos.pexels.com/video-files/4599003/4599003-hd_1080_1920_29fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/4599003/beach-sea-sunset-water-4599003.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'desert-sunset',
  },
  {
    id: 'nat_tranquil_waves_p',
    nameAr: 'أمواج البحر الذهبية المتهادية',
    pack: 'ocean-waves-sunset',
    orientation: 'portrait',
    durationHint: 5,
    url: 'https://videos.pexels.com/video-files/35627292/15098263_1080_1920_60fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/35627292/pexels-photo-35627292.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'desert-sunset',
  },
  {
    id: 'nat_ocean_horizon_p',
    nameAr: 'شفق الغروب الساكن فوق المحيط',
    pack: 'ocean-waves-sunset',
    orientation: 'portrait',
    durationHint: 15,
    url: 'https://videos.pexels.com/video-files/20648599/20648599-hd_1080_1920_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/20648599/pexels-photo-20648599.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'desert-sunset',
  },
  {
    id: 'nat_mountain_sea_l',
    nameAr: 'جبال شامخة وساحل البحر تحت السحب (16:9)',
    pack: 'ocean-waves-sunset',
    orientation: 'landscape',
    durationHint: 19,
    url: 'https://videos.pexels.com/video-files/19692680/19692680-hd_1920_1080_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/19692680/beach-dramatic-drone-italy-19692680.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'desert-sunset',
  },

  // 3. Misty Mountains & Drifting Clouds (4 clips)
  {
    id: 'nat_foggy_valley_p',
    nameAr: 'وادي الجبال الأخضر وسط الضباب',
    pack: 'misty-mountains-clouds',
    orientation: 'portrait',
    durationHint: 12,
    url: 'https://videos.pexels.com/video-files/38542191/16370014_1080_1920_60fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/38542191/pexels-photo-38542191.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_aerial_mist_mtn_p',
    nameAr: 'مشهد جوي للقمم الخضراء والغيوم',
    pack: 'misty-mountains-clouds',
    orientation: 'portrait',
    durationHint: 12,
    url: 'https://videos.pexels.com/video-files/34588746/14657457_1080_1920_25fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/34588746/a-beautiful-view-beautiful-nature-blue-blue-water-34588746.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_forest_clouds_p',
    nameAr: 'غابات الصنوبر الجبلية تعانق السحاب',
    pack: 'misty-mountains-clouds',
    orientation: 'portrait',
    durationHint: 11,
    url: 'https://videos.pexels.com/video-files/27770490/12220535_1080_1920_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/27770490/beautiful-carpathian-mountains-cloud-forest-dark-green-27770490.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_sunset_clouds_l',
    nameAr: 'انسياب السحب الذهبية عند الغروب (16:9)',
    pack: 'misty-mountains-clouds',
    orientation: 'landscape',
    durationHint: 18,
    url: 'https://videos.pexels.com/video-files/11439470/11439470-hd_1920_1080_60fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/11439470/timmelapse-11439470.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'desert-sunset',
  },

  // 4. Snow Peaks & Blue Sky Timelapse (3 clips)
  {
    id: 'nat_snow_above_clouds_p',
    nameAr: 'قمم الجبال الثلجية فوق السحاب',
    pack: 'snow-peaks-sky',
    orientation: 'portrait',
    durationHint: 5,
    url: 'https://videos.pexels.com/video-files/37985445/16119683_1080_1920_25fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/37985445/pexels-photo-37985445.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'celestial-night',
  },
  {
    id: 'nat_snow_peaks_majestic_p',
    nameAr: 'سلسلة جبال ثلجية بيضاء مهيبة',
    pack: 'snow-peaks-sky',
    orientation: 'portrait',
    durationHint: 8,
    url: 'https://videos.pexels.com/video-files/36374692/15427125_1080_1920_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/36374692/pexels-photo-36374692.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'celestial-night',
  },
  {
    id: 'nat_blue_sky_clouds_l',
    nameAr: 'سماء زرقاء صافية وغيوم بيضاء (16:9)',
    pack: 'snow-peaks-sky',
    orientation: 'landscape',
    durationHint: 20,
    url: 'https://videos.pexels.com/video-files/855347/855347-hd_1920_1080_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/855347/free-video-855347.jpg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'celestial-night',
  },

  // 5. Spring Meadows & Flowers in Breeze (2 clips)
  {
    id: 'nat_pink_wildflowers_p',
    nameAr: 'زهور برية وردية تحت السماء الصافية',
    pack: 'spring-meadows-flowers',
    orientation: 'portrait',
    durationHint: 6,
    url: 'https://videos.pexels.com/video-files/36702216/15557160_1080_1920_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/36702216/pexels-photo-36702216.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_spring_daisies_p',
    nameAr: 'حقل أزهار الأقحوان في نسيم الربيع',
    pack: 'spring-meadows-flowers',
    orientation: 'portrait',
    durationHint: 15,
    url: 'https://videos.pexels.com/video-files/32669262/13928786_1080_1920_25fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/32669262/pexels-photo-32669262.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },

  // 6. Rain & Green Leaves (3 clips)
  {
    id: 'nat_dew_leaves_l',
    nameAr: 'قطرات ندى صافية على أوراق النبات الأخضر',
    pack: 'rain-forest',
    orientation: 'landscape',
    durationHint: 12,
    url: 'https://videos.pexels.com/video-files/4706880/4706880-hd_1920_1080_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/4706880/pexels-photo-4706880.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_raindrops_leaves_l',
    nameAr: 'أمطار هادئة تتساقط على أوراق الشجر',
    pack: 'rain-forest',
    orientation: 'landscape',
    durationHint: 33,
    url: 'https://videos.pexels.com/video-files/5155678/5155678-hd_1280_720_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/5155678/pexels-photo-5155678.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_wet_forest_l',
    nameAr: 'أشجار الغابة الخضراء تحت المطر الهادئ',
    pack: 'rain-forest',
    orientation: 'landscape',
    durationHint: 19,
    url: 'https://videos.pexels.com/video-files/5407975/5407975-hd_1920_1080_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/5407975/pexels-photo-5407975.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },

  // 7. Night Sky, Stars & Moon (3 clips)
  {
    id: 'nat_starry_trees_p',
    nameAr: 'سماء الليل المرصعة بالنجوم فوق الأشجار',
    pack: 'night-stars-moon',
    orientation: 'portrait',
    durationHint: 10,
    url: 'https://videos.pexels.com/video-files/39463727/16808905_1080_1922_25fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/39463727/pexels-photo-39463727.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'celestial-night',
  },
  {
    id: 'nat_moon_clouds_p',
    nameAr: 'بدر الليل الهادئ خلف السحب العابرة',
    pack: 'night-stars-moon',
    orientation: 'portrait',
    durationHint: 27,
    url: 'https://videos.pexels.com/video-files/20766726/20766726-hd_1080_1920_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/20766726/moon-natural-nature-serene-20766726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'celestial-night',
  },
  {
    id: 'nat_starry_horizon_l',
    nameAr: 'بانوراما حركة النجوم في الفضاء الساكن (16:9)',
    pack: 'night-stars-moon',
    orientation: 'landscape',
    durationHint: 30,
    url: 'https://videos.pexels.com/video-files/31228270/13338251_2088_720_60fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/31228270/asteroids-astonomy-astronomy-backdrop-31228270.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=320&w=560',
    fallbackProceduralTheme: 'celestial-night',
  },

  // 8. Mosque Domes & Desert Dunes (3 clips -> Total = 28 Verified HD Stock Clips!)
  {
    id: 'nat_mosque_nature_p',
    nameAr: 'قبة مسجد مهيبة محاطة بالأشجار الخضراء',
    pack: 'mosque-skies',
    orientation: 'portrait',
    durationHint: 5,
    url: 'https://videos.pexels.com/video-files/39718851/16936764_1440_2560_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/39718851/pexels-photo-39718851.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'emerald-sanctuary',
  },
  {
    id: 'nat_mosque_clouds_p',
    nameAr: 'مآذن المسجد تحت السحب البيضاء المتحركة',
    pack: 'mosque-skies',
    orientation: 'portrait',
    durationHint: 9,
    url: 'https://videos.pexels.com/video-files/13257227/13257227-hd_1080_1920_30fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/13257227/darul-uloom-deoband-islam-mosque-rasheed-masjid-13257227.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'celestial-night',
  },
  {
    id: 'nat_desert_dunes_p',
    nameAr: 'كثبان الرمال الذهبية المتموجة في الصحراء',
    pack: 'mountains-desert',
    orientation: 'portrait',
    durationHint: 10,
    url: 'https://videos.pexels.com/video-files/19797595/19797595-hd_1080_1920_60fps.mp4',
    thumbnailUrl:
      'https://images.pexels.com/videos/19797595/pexels-photo-19797595.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=480&w=320',
    fallbackProceduralTheme: 'desert-sunset',
  },
];

const cachedNatureFileMap = new Map<string, File>();

export async function fetchStockNatureVideoFile(
  spec: StockNatureClipSpec,
  onStatus?: (msg: string) => void
): Promise<File> {
  const existing = cachedNatureFileMap.get(spec.id);
  if (existing) return existing;

  if (navigator.onLine) {
    try {
      onStatus?.(`جاري تحميل فيديو الطبيعة عالي الدقة: «${spec.nameAr}»...`);
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 14000);
      const resp = await fetch(spec.url, { signal: controller.signal });
      clearTimeout(timeoutId);

      if (resp.ok) {
        const blob = await resp.blob();
        if (blob.size > 10_000) {
          const safeFile = new File([blob], `${spec.nameAr}.mp4`, {
            type: 'video/mp4',
          });
          cachedNatureFileMap.set(spec.id, safeFile);
          return safeFile;
        }
      }
    } catch {
      // Fall through cleanly to offline procedural HD scene generator
    }
  }

  onStatus?.(`جاري توليد مشهد خلفية هادئ بديل لـ «${spec.nameAr}»...`);
  return generateSampleMp4File(spec.fallbackProceduralTheme, 4.0, true);
}

/**
 * Downloads 3–5 diverse real HD nature/sky/ocean/mountain/mosque video scenes in parallel
 * so 1-minute+ (`دقيقة وأكثر`) recitations have rich, varied natural visual scenery throughout!
 */
export async function resolveNatureVideoFilesForQuran(params: {
  packId: NaturePackId;
  isWidescreenLong: boolean;
  sceneCount?: number;
  seedOffset?: number;
  onStatus?: (msg: string) => void;
}): Promise<File[]> {
  const {
    packId,
    isWidescreenLong,
    sceneCount = 4,
    seedOffset = 0,
    onStatus,
  } = params;
  const preferredOrientation = isWidescreenLong ? 'landscape' : 'portrait';

  let candidates: StockNatureClipSpec[];
  if (packId === 'mixed-nature') {
    const sameOrient = REAL_NATURE_STOCK_VIDEOS.filter(
      (c) => c.orientation === preferredOrientation
    );
    const otherOrient = REAL_NATURE_STOCK_VIDEOS.filter(
      (c) => c.orientation !== preferredOrientation
    );
    const rotatedSame = [
      ...sameOrient.slice(seedOffset % Math.max(1, sameOrient.length)),
      ...sameOrient.slice(0, seedOffset % Math.max(1, sameOrient.length)),
    ];
    candidates = [...rotatedSame, ...otherOrient];
  } else {
    const packMatches = REAL_NATURE_STOCK_VIDEOS.filter(
      (c) => c.pack === packId
    );
    const sorted = [
      ...packMatches.filter((c) => c.orientation === preferredOrientation),
      ...packMatches.filter((c) => c.orientation !== preferredOrientation),
    ];
    const complement = REAL_NATURE_STOCK_VIDEOS.filter(
      (c) => c.pack !== packId && c.orientation === preferredOrientation
    );
    const rotatedComplement = [
      ...complement.slice(seedOffset % Math.max(1, complement.length)),
      ...complement.slice(0, seedOffset % Math.max(1, complement.length)),
    ];
    candidates = [...sorted, ...rotatedComplement];
  }

  const chosen = candidates.slice(0, Math.max(2, Math.min(5, sceneCount)));
  onStatus?.(`جاري تحميل ${chosen.length} مشاهد طبيعة حقيقية عالية الدقة...`);
  return Promise.all(chosen.map((spec) => fetchStockNatureVideoFile(spec)));
}
