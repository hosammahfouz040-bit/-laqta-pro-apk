import {
  audioBufferToWavBlob,
  extractWaveformPeaks,
} from '../engine/audioEngine';
import { SampleVideoTheme } from './mediaService';
import { NaturePackId } from './natureVideoService';
import { buildWordTimingsForPhrase } from './subtitleService';
import {
  AspectRatio,
  AudioClip,
  MediaAsset,
  TextOverlay,
} from '../types/editor';

export interface SurahMeta {
  number: number;
  nameAr: string;
  ayahCount: number;
}

// Complete 114 Surahs of the Holy Quran (exact order & exact verse counts)
export const SURAHS_LIST: SurahMeta[] = [
  { number: 1, nameAr: 'الفاتحة', ayahCount: 7 },
  { number: 2, nameAr: 'البقرة', ayahCount: 286 },
  { number: 3, nameAr: 'آل عمران', ayahCount: 200 },
  { number: 4, nameAr: 'النساء', ayahCount: 176 },
  { number: 5, nameAr: 'المائدة', ayahCount: 120 },
  { number: 6, nameAr: 'الأنعام', ayahCount: 165 },
  { number: 7, nameAr: 'الأعراف', ayahCount: 206 },
  { number: 8, nameAr: 'الأنفال', ayahCount: 75 },
  { number: 9, nameAr: 'التوبة', ayahCount: 129 },
  { number: 10, nameAr: 'يونس', ayahCount: 109 },
  { number: 11, nameAr: 'هود', ayahCount: 123 },
  { number: 12, nameAr: 'يوسف', ayahCount: 111 },
  { number: 13, nameAr: 'الرعد', ayahCount: 43 },
  { number: 14, nameAr: 'إبراهيم', ayahCount: 52 },
  { number: 15, nameAr: 'الحجر', ayahCount: 99 },
  { number: 16, nameAr: 'النحل', ayahCount: 128 },
  { number: 17, nameAr: 'الإسراء', ayahCount: 111 },
  { number: 18, nameAr: 'الكهف', ayahCount: 110 },
  { number: 19, nameAr: 'مريم', ayahCount: 98 },
  { number: 20, nameAr: 'طه', ayahCount: 135 },
  { number: 21, nameAr: 'الأنبياء', ayahCount: 112 },
  { number: 22, nameAr: 'الحج', ayahCount: 78 },
  { number: 23, nameAr: 'المؤمنون', ayahCount: 118 },
  { number: 24, nameAr: 'النور', ayahCount: 64 },
  { number: 25, nameAr: 'الفرقان', ayahCount: 77 },
  { number: 26, nameAr: 'الشعراء', ayahCount: 227 },
  { number: 27, nameAr: 'النمل', ayahCount: 93 },
  { number: 28, nameAr: 'القصص', ayahCount: 88 },
  { number: 29, nameAr: 'العنكبوت', ayahCount: 69 },
  { number: 30, nameAr: 'الروم', ayahCount: 60 },
  { number: 31, nameAr: 'لقمان', ayahCount: 34 },
  { number: 32, nameAr: 'السجدة', ayahCount: 30 },
  { number: 33, nameAr: 'الأحزاب', ayahCount: 73 },
  { number: 34, nameAr: 'سبأ', ayahCount: 54 },
  { number: 35, nameAr: 'فاطر', ayahCount: 45 },
  { number: 36, nameAr: 'يس', ayahCount: 83 },
  { number: 37, nameAr: 'الصافات', ayahCount: 182 },
  { number: 38, nameAr: 'ص', ayahCount: 88 },
  { number: 39, nameAr: 'الزمر', ayahCount: 75 },
  { number: 40, nameAr: 'غافر', ayahCount: 85 },
  { number: 41, nameAr: 'فصلت', ayahCount: 54 },
  { number: 42, nameAr: 'الشورى', ayahCount: 53 },
  { number: 43, nameAr: 'الزخرف', ayahCount: 89 },
  { number: 44, nameAr: 'الدخان', ayahCount: 59 },
  { number: 45, nameAr: 'الجاثية', ayahCount: 37 },
  { number: 46, nameAr: 'الأحقاف', ayahCount: 35 },
  { number: 47, nameAr: 'محمد', ayahCount: 38 },
  { number: 48, nameAr: 'الفتح', ayahCount: 29 },
  { number: 49, nameAr: 'الحجرات', ayahCount: 18 },
  { number: 50, nameAr: 'ق', ayahCount: 45 },
  { number: 51, nameAr: 'الذاريات', ayahCount: 60 },
  { number: 52, nameAr: 'الطور', ayahCount: 49 },
  { number: 53, nameAr: 'النجم', ayahCount: 62 },
  { number: 54, nameAr: 'القمر', ayahCount: 55 },
  { number: 55, nameAr: 'الرحمن', ayahCount: 78 },
  { number: 56, nameAr: 'الواقعة', ayahCount: 96 },
  { number: 57, nameAr: 'الحديد', ayahCount: 29 },
  { number: 58, nameAr: 'المجادلة', ayahCount: 22 },
  { number: 59, nameAr: 'الحشر', ayahCount: 24 },
  { number: 60, nameAr: 'الممتحنة', ayahCount: 13 },
  { number: 61, nameAr: 'الصف', ayahCount: 14 },
  { number: 62, nameAr: 'الجمعة', ayahCount: 11 },
  { number: 63, nameAr: 'المنافقون', ayahCount: 11 },
  { number: 64, nameAr: 'التغابن', ayahCount: 18 },
  { number: 65, nameAr: 'الطلاق', ayahCount: 12 },
  { number: 66, nameAr: 'التحريم', ayahCount: 12 },
  { number: 67, nameAr: 'الملك', ayahCount: 30 },
  { number: 68, nameAr: 'القلم', ayahCount: 52 },
  { number: 69, nameAr: 'الحاقة', ayahCount: 52 },
  { number: 70, nameAr: 'المعارج', ayahCount: 44 },
  { number: 71, nameAr: 'نوح', ayahCount: 28 },
  { number: 72, nameAr: 'الجن', ayahCount: 28 },
  { number: 73, nameAr: 'المزمل', ayahCount: 20 },
  { number: 74, nameAr: 'المدثر', ayahCount: 56 },
  { number: 75, nameAr: 'القيامة', ayahCount: 40 },
  { number: 76, nameAr: 'الإنسان', ayahCount: 31 },
  { number: 77, nameAr: 'المرسلات', ayahCount: 50 },
  { number: 78, nameAr: 'النبأ', ayahCount: 40 },
  { number: 79, nameAr: 'النازعات', ayahCount: 46 },
  { number: 80, nameAr: 'عبس', ayahCount: 42 },
  { number: 81, nameAr: 'التكوير', ayahCount: 29 },
  { number: 82, nameAr: 'الانفطار', ayahCount: 19 },
  { number: 83, nameAr: 'المطففين', ayahCount: 36 },
  { number: 84, nameAr: 'الانشقاق', ayahCount: 25 },
  { number: 85, nameAr: 'البروج', ayahCount: 22 },
  { number: 86, nameAr: 'الطارق', ayahCount: 17 },
  { number: 87, nameAr: 'الأعلى', ayahCount: 19 },
  { number: 88, nameAr: 'الغاشية', ayahCount: 26 },
  { number: 89, nameAr: 'الفجر', ayahCount: 30 },
  { number: 90, nameAr: 'البلد', ayahCount: 20 },
  { number: 91, nameAr: 'الشمس', ayahCount: 15 },
  { number: 92, nameAr: 'الليل', ayahCount: 21 },
  { number: 93, nameAr: 'الضحى', ayahCount: 11 },
  { number: 94, nameAr: 'الشرح', ayahCount: 8 },
  { number: 95, nameAr: 'التين', ayahCount: 8 },
  { number: 96, nameAr: 'العلق', ayahCount: 19 },
  { number: 97, nameAr: 'القدر', ayahCount: 5 },
  { number: 98, nameAr: 'البينة', ayahCount: 8 },
  { number: 99, nameAr: 'الزلزلة', ayahCount: 8 },
  { number: 100, nameAr: 'العاديات', ayahCount: 11 },
  { number: 101, nameAr: 'القارعة', ayahCount: 11 },
  { number: 102, nameAr: 'التكاثر', ayahCount: 8 },
  { number: 103, nameAr: 'العصر', ayahCount: 3 },
  { number: 104, nameAr: 'الهمزة', ayahCount: 9 },
  { number: 105, nameAr: 'الفيل', ayahCount: 5 },
  { number: 106, nameAr: 'قريش', ayahCount: 4 },
  { number: 107, nameAr: 'الماعون', ayahCount: 7 },
  { number: 108, nameAr: 'الكوثر', ayahCount: 3 },
  { number: 109, nameAr: 'الكافرون', ayahCount: 6 },
  { number: 110, nameAr: 'النصر', ayahCount: 3 },
  { number: 111, nameAr: 'المسد', ayahCount: 5 },
  { number: 112, nameAr: 'الإخلاص', ayahCount: 4 },
  { number: 113, nameAr: 'الفلق', ayahCount: 5 },
  { number: 114, nameAr: 'الناس', ayahCount: 6 },
];

export interface QuranReciter {
  id: string;
  folder: string;
  nameAr: string;
  styleAr: string;
}

export const QURAN_RECITERS: QuranReciter[] = [
  {
    id: 'alafasy',
    folder: 'Alafasy_128kbps',
    nameAr: 'مشاري راشد العفاسي',
    styleAr: 'ترتيل عذب خاشع',
  },
  {
    id: 'maher',
    folder: 'MaherAlMuaiqly128kbps',
    nameAr: 'ماهر المعيقلي',
    styleAr: 'تلاوة الحرم المكي',
  },
  {
    id: 'dossari',
    folder: 'Yasser_Ad-Dussary_128kbps',
    nameAr: 'ياسر الدوسري',
    styleAr: 'تلاوة مؤثرة خاشعة',
  },
  {
    id: 'qatami',
    folder: 'Nasser_Alqatami_128kbps',
    nameAr: 'ناصر القطامي',
    styleAr: 'خشوع وسكينة',
  },
  {
    id: 'abdulbasit_muj',
    folder: 'Abdul_Basit_Mujawwad_128kbps',
    nameAr: 'عبد الباسط عبد الصمد',
    styleAr: 'تجويد ذهبي خالد',
  },
  {
    id: 'abdulbasit_mur',
    folder: 'Abdul_Basit_Murattal_192kbps',
    nameAr: 'عبد الباسط (مرتل)',
    styleAr: 'ترتيل نقي واضح',
  },
  {
    id: 'minshawi',
    folder: 'Minshawy_Mujawwad_192kbps',
    nameAr: 'محمد صديق المنشاوي',
    styleAr: 'الصوت الباكي (مجود)',
  },
  {
    id: 'husary',
    folder: 'Husary_128kbps',
    nameAr: 'محمود خليل الحصري',
    styleAr: 'المصحف المرتل المتقن',
  },
  {
    id: 'sudais',
    folder: 'Abdurrahmaan_As-Sudais_192kbps',
    nameAr: 'عبد الرحمن السديس',
    styleAr: 'تلاوة الحرم الشريف',
  },
  {
    id: 'shuraym',
    folder: 'Saood_ash-Shuraym_128kbps',
    nameAr: 'سعود الشريم',
    styleAr: 'ترتيل هادئ متقن',
  },
];

export type QuranVisualThemeId =
  | 'waterfall-nature-reels'
  | 'ocean-waves-reels'
  | 'misty-mountains-reels'
  | 'snow-peaks-reels'
  | 'spring-flowers-reels'
  | 'rain-leaves-serenity'
  | 'youtube-long-nature'
  | 'mountain-sea-long'
  | 'waterfall-canyon-long'
  | 'clouds-sky-long'
  | 'gold-mihrab'
  | 'dawn-tranquility'
  | 'ramadan-lanterns'
  | 'rain-recitation'
  | 'madinah-mushaf'
  | 'emerald-oasis'
  | 'cosmos-reflection'
  | 'desert-dusk'
  | 'bilingual-dawah'
  | 'golden-karaoke'
  | 'square-ayah-card'
  | 'widescreen-quran';

/**
 * 22 PURE & CLEAN Quranic Scene Styles:
 * ZERO pre-applied Filters, ZERO pre-applied Transitions, ZERO pre-applied Video Effects!
 * Only pure camera HD nature/sky/ocean/mountain/meadow/mosque footage + Recitation Audio + Crisp Written Ayahs!
 */
export interface QuranVisualTheme {
  id: QuranVisualThemeId;
  nameAr: string;
  descAr: string;
  badge: string;
  gradient: string;
  aspectRatio: AspectRatio;
  defaultNaturePack: NaturePackId;
  bgVideoTheme: SampleVideoTheme;
  ayahColor: string;
  strokeColor: string;
  bgBoxColor: string;
  bgBoxOpacity: number;
  highlightWords: boolean;
  highlightColor: string;
  includeEnglishTranslation: boolean;
}

export const QURAN_VISUAL_THEMES: QuranVisualTheme[] = [
  {
    id: 'waterfall-nature-reels',
    nameAr: 'شلالات وأنهار الغابة الصافية 🏞️',
    descAr: 'فيديوهات شلالات وأنهار طبيعية خام + صوت التلاوة + الآيات مكتوبة بدون أي إضافات',
    badge: 'ريلز 9:16 • طبيعة نقية',
    gradient: 'from-cyan-500/40 via-emerald-950 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'waterfalls-rivers',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#060A10',
    bgBoxOpacity: 48,
    highlightWords: false,
    highlightColor: '#FDE047',
    includeEnglishTranslation: false,
  },
  {
    id: 'ocean-waves-reels',
    nameAr: 'أمواج البحر وغروب الشاطئ 🌊🌅',
    descAr: 'فيديوهات أمواج البحر والشفق الذهبي الطبيعية الخام + التلاوة والآيات المكتوبة',
    badge: 'ريلز 9:16 • بحر وغروب',
    gradient: 'from-amber-400/35 via-sky-950 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'ocean-waves-sunset',
    bgVideoTheme: 'desert-sunset',
    ayahColor: '#FFFBEB',
    strokeColor: '#000000',
    bgBoxColor: '#070B14',
    bgBoxOpacity: 48,
    highlightWords: false,
    highlightColor: '#FACC15',
    includeEnglishTranslation: false,
  },
  {
    id: 'misty-mountains-reels',
    nameAr: 'الجبال الخضراء والسحب العابرة ⛰️☁️',
    descAr: 'لقطات جوية صافية للوديان الخضراء والضباب مع الآيات والتلاوة بدون مؤثرات',
    badge: 'ريلز 9:16 • جبال وضباب',
    gradient: 'from-emerald-400/35 via-slate-900 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'misty-mountains-clouds',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#050910',
    bgBoxOpacity: 46,
    highlightWords: false,
    highlightColor: '#6EE7B7',
    includeEnglishTranslation: false,
  },
  {
    id: 'snow-peaks-reels',
    nameAr: 'قمم الجبال الثلجية فوق السحاب 🏔️❄️',
    descAr: 'مشاهد جليلة لقمم الثلج البيضاء فوق الغيوم + الآيات العثمانية الواضحة',
    badge: 'ريلز 9:16 • قمم ثلجية',
    gradient: 'from-sky-300/35 via-slate-800 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'snow-peaks-sky',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#070C18',
    bgBoxOpacity: 52,
    highlightWords: false,
    highlightColor: '#38BDF8',
    includeEnglishTranslation: false,
  },
  {
    id: 'spring-flowers-reels',
    nameAr: 'مروج وزهور الربيع الهادئة 🌸🌿',
    descAr: 'فيديوهات زهور ومروج طبيعية صافية في نسيم الصباح مع التلاوة العذبة',
    badge: 'ريلز 9:16 • زهور ومروج',
    gradient: 'from-pink-400/35 via-emerald-950 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'spring-meadows-flowers',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#060A0E',
    bgBoxOpacity: 50,
    highlightWords: false,
    highlightColor: '#FDE047',
    includeEnglishTranslation: false,
  },
  {
    id: 'rain-leaves-serenity',
    nameAr: 'قطرات المطر وأوراق الشجر 🌧️🍃',
    descAr: 'فيديو حقيقي نقي لقطرات المطر والندى على أوراق الأشجار مع الآيات والتلاوة',
    badge: 'ريلز 9:16 • مطر وأوراق',
    gradient: 'from-teal-500/35 via-green-950 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'rain-forest',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FFFBEB',
    strokeColor: '#000000',
    bgBoxColor: '#04120D',
    bgBoxOpacity: 48,
    highlightWords: false,
    highlightColor: '#34D399',
    includeEnglishTranslation: false,
  },
  {
    id: 'youtube-long-nature',
    nameAr: 'بانوراما الطبيعة المتنوعة الطويلة (16:9) 📺',
    descAr: 'مشاهد طبيعة عريضة نقية متعاقبة للتلاوات الطويلة على يوتيوب بدون أي فلاتر مسبقة',
    badge: 'طويل 16:9 📺 طبيعة نقية',
    gradient: 'from-emerald-400/35 via-slate-900 to-black',
    aspectRatio: '16:9',
    defaultNaturePack: 'mixed-nature',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FEF9C3',
    strokeColor: '#000000',
    bgBoxColor: '#060A12',
    bgBoxOpacity: 52,
    highlightWords: false,
    highlightColor: '#FACC15',
    includeEnglishTranslation: false,
  },
  {
    id: 'waterfall-canyon-long',
    nameAr: 'شلالات الوديان العريضة الطويلة (16:9) 🏞️📺',
    descAr: 'فيديوهات شلالات جبلية عريضة بدقة HD للتلاوات الطويلة المريحة للعين',
    badge: 'طويل 16:9 🏞️ شلالات',
    gradient: 'from-cyan-400/35 via-teal-950 to-black',
    aspectRatio: '16:9',
    defaultNaturePack: 'waterfalls-rivers',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#040B10',
    bgBoxOpacity: 52,
    highlightWords: false,
    highlightColor: '#67E8F9',
    includeEnglishTranslation: false,
  },
  {
    id: 'mountain-sea-long',
    nameAr: 'آفاق الجبال والبحر الطويل (16:9) 🌊⛰️',
    descAr: 'مشاهد جوية عريضة للسواحل والجبال للتلاوات الطويلة بدون أي مؤثرات مسبقة',
    badge: 'طويل 16:9 🌊 جبال وبحر',
    gradient: 'from-sky-400/35 via-blue-950 to-slate-950',
    aspectRatio: '16:9',
    defaultNaturePack: 'ocean-waves-sunset',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#050C1A',
    bgBoxOpacity: 52,
    highlightWords: false,
    highlightColor: '#38BDF8',
    includeEnglishTranslation: false,
  },
  {
    id: 'clouds-sky-long',
    nameAr: 'انسياب السحب والآفاق الطويل (16:9) ☁️🌅',
    descAr: 'تايم لابس السماء الزرقاء وسحب الغروب العريضة للسور والتلاوات الطويلة',
    badge: 'طويل 16:9 ☁️ سحب وسماء',
    gradient: 'from-amber-300/35 via-indigo-950 to-black',
    aspectRatio: '16:9',
    defaultNaturePack: 'snow-peaks-sky',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#FEF9C3',
    strokeColor: '#000000',
    bgBoxColor: '#060913',
    bgBoxOpacity: 52,
    highlightWords: false,
    highlightColor: '#FDE047',
    includeEnglishTranslation: false,
  },
  {
    id: 'gold-mihrab',
    nameAr: 'قباب المساجد والسحب السماوية 🕌',
    descAr: 'فيديوهات المساجد والطبيعة النقية مع الآيات المكتوبة بالذهبي الهادئ',
    badge: 'مساجد وسحب 🕌',
    gradient: 'from-amber-500/35 via-slate-900 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'mosque-skies',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#FEF9C3',
    strokeColor: '#000000',
    bgBoxColor: '#050811',
    bgBoxOpacity: 50,
    highlightWords: false,
    highlightColor: '#FACC15',
    includeEnglishTranslation: false,
  },
  {
    id: 'emerald-oasis',
    nameAr: 'جداول الغابة والآيات البيضاء 🌿',
    descAr: 'فيديوهات المياه والأشجار الطبيعية الخام + نص عثماني أبيض نقي',
    badge: 'نقي وواضح 🌿',
    gradient: 'from-emerald-500/35 via-teal-950 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'waterfalls-rivers',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#04120E',
    bgBoxOpacity: 48,
    highlightWords: false,
    highlightColor: '#FDE047',
    includeEnglishTranslation: false,
  },
  {
    id: 'dawn-tranquility',
    nameAr: 'نجوم الليل وسكون الفجر 🌌',
    descAr: 'فيديو النجوم الليلية الحقيقي بصورته الطبيعية النقية + التلاوة والآيات',
    badge: 'سماء النجوم 🌌',
    gradient: 'from-sky-400/30 via-indigo-950 to-slate-950',
    aspectRatio: '9:16',
    defaultNaturePack: 'night-stars-moon',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#FFFFFF',
    strokeColor: '#090D16',
    bgBoxColor: '#090D16',
    bgBoxOpacity: 46,
    highlightWords: false,
    highlightColor: '#38BDF8',
    includeEnglishTranslation: false,
  },
  {
    id: 'ramadan-lanterns',
    nameAr: 'ضوء البدر والسحب الليلية 🌙',
    descAr: 'فيديو القمر الحقيقي خلف السحب العابرة مع الآيات المكتوبة باللون الذهبي',
    badge: 'القمر والسحب 🌙',
    gradient: 'from-amber-400/35 via-indigo-900/50 to-zinc-950',
    aspectRatio: '9:16',
    defaultNaturePack: 'night-stars-moon',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#FEF08A',
    strokeColor: '#000000',
    bgBoxColor: '#0B0F1A',
    bgBoxOpacity: 48,
    highlightWords: false,
    highlightColor: '#FACC15',
    includeEnglishTranslation: false,
  },
  {
    id: 'rain-recitation',
    nameAr: 'غابات المطر الساكنة 🌧️',
    descAr: 'فيديوهات أمطار الغابة الحقيقية بألوانها الطبيعية دون أي فلاتر مسبقة',
    badge: 'مطر الغابة 🌧️',
    gradient: 'from-slate-500/35 via-slate-900 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'rain-forest',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#F8FAFC',
    strokeColor: '#000000',
    bgBoxColor: '#09090B',
    bgBoxOpacity: 48,
    highlightWords: false,
    highlightColor: '#00E5DF',
    includeEnglishTranslation: false,
  },
  {
    id: 'golden-karaoke',
    nameAr: 'تلوين الكلمات مع التلاوة (طبيعة نقية) ✨',
    descAr: 'فيديوهات طبيعة خام + إضاءة كل كلمة من الآية بالذهبي مع صوت القارئ',
    badge: 'تزامن الكلمات ✨',
    gradient: 'from-yellow-400/35 via-emerald-900/40 to-zinc-950',
    aspectRatio: '9:16',
    defaultNaturePack: 'mixed-nature',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#070A10',
    bgBoxOpacity: 52,
    highlightWords: true,
    highlightColor: '#FACC15',
    includeEnglishTranslation: false,
  },
  {
    id: 'bilingual-dawah',
    nameAr: 'الآيات مع الترجمة الإنجليزية 🌍',
    descAr: 'فيديوهات طبيعة نقية + الآية بالرسم العثماني مع ترجمتها بالإنجليزية',
    badge: 'عربي + English 🌍',
    gradient: 'from-[#00E5DF]/30 via-blue-950 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'waterfalls-rivers',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#FFFFFF',
    strokeColor: '#000000',
    bgBoxColor: '#050811',
    bgBoxOpacity: 58,
    highlightWords: false,
    highlightColor: '#00E5DF',
    includeEnglishTranslation: true,
  },
  {
    id: 'madinah-mushaf',
    nameAr: 'كثبان الصحراء الذهبية النقية 📖',
    descAr: 'فيديو رمال الصحراء الحقيقي بألوانه الطبيعية مع خط المصحف الكريمي',
    badge: 'كثبان الصحراء 🏜️',
    gradient: 'from-amber-200/30 via-amber-900/40 to-stone-950',
    aspectRatio: '9:16',
    defaultNaturePack: 'mountains-desert',
    bgVideoTheme: 'desert-sunset',
    ayahColor: '#FFFBEB',
    strokeColor: '#1C1917',
    bgBoxColor: '#1C140D',
    bgBoxOpacity: 52,
    highlightWords: false,
    highlightColor: '#FBBF24',
    includeEnglishTranslation: false,
  },
  {
    id: 'cosmos-reflection',
    nameAr: 'ملكوت السماوات والنجوم 🌌',
    descAr: 'مشاهد الفضاء والنجوم الليلية الخام للتفكر والتدبر بدون إضافات',
    badge: 'تدبر الكون 🌌',
    gradient: 'from-indigo-500/35 via-purple-950/40 to-black',
    aspectRatio: '9:16',
    defaultNaturePack: 'night-stars-moon',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#E0F2FE',
    strokeColor: '#000000',
    bgBoxColor: '#030712',
    bgBoxOpacity: 48,
    highlightWords: false,
    highlightColor: '#38BDF8',
    includeEnglishTranslation: false,
  },
  {
    id: 'desert-dusk',
    nameAr: 'آفاق الصحراء والجبال 🏜️',
    descAr: 'مشاهد طبيعية صافية للصحراء والجبال مع الآيات المكتوبة بوضوح',
    badge: 'آفاق الجبال ⛰️',
    gradient: 'from-orange-500/35 via-amber-900/40 to-stone-950',
    aspectRatio: '9:16',
    defaultNaturePack: 'mountains-desert',
    bgVideoTheme: 'desert-sunset',
    ayahColor: '#FEF9C3',
    strokeColor: '#000000',
    bgBoxColor: '#18100A',
    bgBoxOpacity: 50,
    highlightWords: false,
    highlightColor: '#FDE047',
    includeEnglishTranslation: false,
  },
  {
    id: 'square-ayah-card',
    nameAr: 'بطاقة قرآنية مربعة نقية (1:1)',
    descAr: 'فيديو طبيعة خام بمقاس مربع 1:1 مع التلاوة والآيات المكتوبة',
    badge: 'مربع 1:1 📲',
    gradient: 'from-teal-500/35 via-emerald-950 to-zinc-950',
    aspectRatio: '1:1',
    defaultNaturePack: 'waterfalls-rivers',
    bgVideoTheme: 'emerald-sanctuary',
    ayahColor: '#FEF9C3',
    strokeColor: '#000000',
    bgBoxColor: '#04120E',
    bgBoxOpacity: 50,
    highlightWords: false,
    highlightColor: '#FACC15',
    includeEnglishTranslation: false,
  },
  {
    id: 'widescreen-quran',
    nameAr: 'تلاوة السماء الليلية الطويلة (16:9)',
    descAr: 'فيديو بانوراما النجوم العريض النقي لقنوات يوتيوب بدون أي مؤثرات مسبقة',
    badge: 'يوتيوب طويل 16:9 📺',
    gradient: 'from-amber-500/30 via-slate-900 to-black',
    aspectRatio: '16:9',
    defaultNaturePack: 'night-stars-moon',
    bgVideoTheme: 'celestial-night',
    ayahColor: '#FEF9C3',
    strokeColor: '#000000',
    bgBoxColor: '#060A14',
    bgBoxOpacity: 52,
    highlightWords: false,
    highlightColor: '#FACC15',
    includeEnglishTranslation: false,
  },
];

export interface OfflineQuranGem {
  id: string;
  label: string;
  surahNumber: number;
  surahNameAr: string;
  startAyah: number;
  endAyah: number;
  ayahs: Array<{
    numberInSurah: number;
    textAr: string;
    textEn: string;
  }>;
}

export const OFFLINE_QURAN_GEMS: OfflineQuranGem[] = [
  {
    id: 'fatiha',
    label: 'سورة الفاتحة كاملة (دقيقة+)',
    surahNumber: 1,
    surahNameAr: 'الفاتحة',
    startAyah: 1,
    endAyah: 7,
    ayahs: [
      { numberInSurah: 1, textAr: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', textEn: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.' },
      { numberInSurah: 2, textAr: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', textEn: '[All] praise is [due] to Allah, Lord of the worlds -' },
      { numberInSurah: 3, textAr: 'الرَّحْمَٰنِ الرَّحِيمِ', textEn: 'The Entirely Merciful, the Especially Merciful,' },
      { numberInSurah: 4, textAr: 'مَالِكِ يَوْمِ الدِّينِ', textEn: 'Sovereign of the Day of Recompense.' },
      { numberInSurah: 5, textAr: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ', textEn: 'It is You we worship and You we ask for help.' },
      { numberInSurah: 6, textAr: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', textEn: 'Guide us to the straight path -' },
      { numberInSurah: 7, textAr: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ', textEn: 'The path of those upon whom You have bestowed favor, not of those who have evoked anger or of those who are astray.' },
    ],
  },
  {
    id: 'kursi',
    label: 'آية الكرسي + آيات النور (البقرة 255-257)',
    surahNumber: 2,
    surahNameAr: 'البقرة',
    startAyah: 255,
    endAyah: 257,
    ayahs: [
      {
        numberInSurah: 255,
        textAr: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ',
        textEn: 'Allah - there is no deity except Him, the Ever-Living, the Sustainer of existence...',
      },
      {
        numberInSurah: 256,
        textAr: 'لَا إِكْرَاهَ فِي الدِّينِ ۖ قَد تَّبَيَّنَ الرُّشْدُ مِنَ الْغَيِّ ۚ فَمَن يَكْفُرْ بِالطَّاغُوتِ وَيُؤْمِن بِاللَّهِ فَقَدِ اسْتَمْسَكَ بِالْعُرْوَةِ الْوُثْقَىٰ لَا انفِصَامَ لَهَا ۗ وَاللَّهُ سَمِيعٌ عَلِيمٌ',
        textEn: 'There shall be no compulsion in [acceptance of] the religion...',
      },
      {
        numberInSurah: 257,
        textAr: 'اللَّهُ وَلِيُّ الَّذِينَ آمَنُوا يُخْرِجُهُم مِّنَ الظُّلُمَاتِ إِلَى النُّورِ',
        textEn: 'Allah is the ally of those who believe. He brings them out from darknesses into the light.',
      },
    ],
  },
  {
    id: 'sharh',
    label: 'سورة الشرح كاملة (1-8)',
    surahNumber: 94,
    surahNameAr: 'الشرح',
    startAyah: 1,
    endAyah: 8,
    ayahs: [
      { numberInSurah: 1, textAr: 'أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ', textEn: 'Did We not expand for you, [O Muhammad], your breast?' },
      { numberInSurah: 2, textAr: 'وَوَضَعْنَا عَنكَ وِزْرَكَ', textEn: 'And We removed from you your burden' },
      { numberInSurah: 3, textAr: 'الَّذِي أَنقَضَ ظَهْرَكَ', textEn: 'Which had weighed upon your back' },
      { numberInSurah: 4, textAr: 'وَرَفَعْنَا لَكَ ذِكْرَكَ', textEn: 'And raised high for you your repute.' },
      { numberInSurah: 5, textAr: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا', textEn: 'For indeed, with hardship [will be] ease.' },
      { numberInSurah: 6, textAr: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا', textEn: 'Indeed, with hardship [will be] ease.' },
      { numberInSurah: 7, textAr: 'فَإِذَا فَرَغْتَ فَانصَبْ', textEn: 'So when you have finished [your duties], then stand up [for worship].' },
      { numberInSurah: 8, textAr: 'وَإِلَىٰ رَبِّكَ فَارْغَب', textEn: 'And to your Lord direct [your] longing.' },
    ],
  },
  {
    id: 'duha',
    label: 'سورة الضحى كاملة (1-11)',
    surahNumber: 93,
    surahNameAr: 'الضحى',
    startAyah: 1,
    endAyah: 11,
    ayahs: [
      { numberInSurah: 1, textAr: 'وَالضُّحَىٰ', textEn: 'By the morning brightness' },
      { numberInSurah: 2, textAr: 'وَاللَّيْلِ إِذَا سَجَىٰ', textEn: 'And [by] the night when it covers with darkness,' },
      { numberInSurah: 3, textAr: 'مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ', textEn: 'Your Lord has not taken leave of you, nor has He detested [you].' },
      { numberInSurah: 4, textAr: 'وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ', textEn: 'And the Hereafter is better for you than the first [life].' },
      { numberInSurah: 5, textAr: 'وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ', textEn: 'And your Lord is going to give you, and you will be satisfied.' },
      { numberInSurah: 6, textAr: 'أَلَمْ يَجِدْكَ يَتِيمًا فَآوَىٰ', textEn: 'Did He not find you an orphan and give [you] refuge?' },
      { numberInSurah: 7, textAr: 'وَوَجَدَكَ ضَالًّا فَهَدَىٰ', textEn: 'And He found you lost and guided [you],' },
      { numberInSurah: 8, textAr: 'وَوَجَدَكَ عَائِلًا فَأَغْنَىٰ', textEn: 'And He found you poor and made [you] self-sufficient.' },
      { numberInSurah: 9, textAr: 'فَأَمَّا الْيَتِيمَ فَلَا تَقْهَرْ', textEn: 'So as for the orphan, do not oppress [him].' },
      { numberInSurah: 10, textAr: 'وَأَمَّا السَّائِلَ فَلَا تَنْهَرْ', textEn: 'And as for the petitioner, do not repel [him].' },
      { numberInSurah: 11, textAr: 'وَأَمَّا بِنِعْمَةِ رَبِّكَ فَحَدِّثْ', textEn: 'But as for the favor of your Lord, report [it].' },
    ],
  },
  {
    id: 'ikhlas',
    label: 'سورة الإخلاص مكررة (دقيقة+)',
    surahNumber: 112,
    surahNameAr: 'الإخلاص',
    startAyah: 1,
    endAyah: 4,
    ayahs: [
      { numberInSurah: 1, textAr: 'قُلْ هُوَ اللَّهُ أَحَدٌ', textEn: 'Say, "He is Allah, [who is] One,' },
      { numberInSurah: 2, textAr: 'اللَّهُ الصَّمَدُ', textEn: 'Allah, the Eternal Refuge.' },
      { numberInSurah: 3, textAr: 'لَمْ يَلِدْ وَلَمْ يُولَدْ', textEn: 'He neither begets nor is born,' },
      { numberInSurah: 4, textAr: 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ', textEn: 'Nor is there to Him any equivalent."' },
    ],
  },
  {
    id: 'falaq',
    label: 'سورة الفلق (دقيقة+)',
    surahNumber: 113,
    surahNameAr: 'الفلق',
    startAyah: 1,
    endAyah: 5,
    ayahs: [
      { numberInSurah: 1, textAr: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ', textEn: 'Say, "I seek refuge in the Lord of daybreak' },
      { numberInSurah: 2, textAr: 'مِن شَرِّ مَا خَلَقَ', textEn: 'From the evil of that which He created' },
      { numberInSurah: 3, textAr: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ', textEn: 'And from the evil of darkness when it settles' },
      { numberInSurah: 4, textAr: 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ', textEn: 'And from the evil of the blowers in knots' },
      { numberInSurah: 5, textAr: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ', textEn: 'And from the evil of an envier when he envies."' },
    ],
  },
  {
    id: 'nas',
    label: 'سورة الناس (دقيقة+)',
    surahNumber: 114,
    surahNameAr: 'الناس',
    startAyah: 1,
    endAyah: 6,
    ayahs: [
      { numberInSurah: 1, textAr: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ', textEn: 'Say, "I seek refuge in the Lord of mankind,' },
      { numberInSurah: 2, textAr: 'مَلِكِ النَّاسِ', textEn: 'The Sovereign of mankind.' },
      { numberInSurah: 3, textAr: 'إِلَٰهِ النَّاسِ', textEn: 'The God of mankind,' },
      { numberInSurah: 4, textAr: 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ', textEn: 'From the evil of the retreating whisperer -' },
      { numberInSurah: 5, textAr: 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ', textEn: 'Who whispers [evil] into the breasts of mankind -' },
      { numberInSurah: 6, textAr: 'مِنَ الْجِنَّةِ وَالنَّاسِ', textEn: 'From among the jinn and mankind."' },
    ],
  },
];

function toArabicIndicNumerals(num: number): string {
  const digits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(num)
    .split('')
    .map((ch) => (ch >= '0' && ch <= '9' ? digits[parseInt(ch, 10)] : ch))
    .join('');
}

/**
 * Sample-accurate voice onset/offset detector so MP3 silence padding never delays written Ayahs!
 */
function detectActiveVoiceBounds(buf: AudioBuffer): {
  offsetSec: number;
  durationSec: number;
} {
  const data = buf.getChannelData(0);
  const sr = buf.sampleRate;
  const threshold = 0.008;
  let first = 0;
  while (first < data.length && Math.abs(data[first]) < threshold) {
    first++;
  }
  let last = data.length - 1;
  while (last > first && Math.abs(data[last]) < threshold) {
    last--;
  }
  if (first >= last) {
    return { offsetSec: 0, durationSec: Math.max(0.4, buf.duration) };
  }
  const padSamples = Math.floor(sr * 0.045); // Natural 45ms breath margin
  const cleanStart = Math.max(0, first - padSamples);
  const cleanEnd = Math.min(data.length, last + padSamples * 2);
  return {
    offsetSec: cleanStart / sr,
    durationSec: Math.max(0.4, (cleanEnd - cleanStart) / sr),
  };
}

interface FetchedAyahItem {
  numberInSurah: number;
  textAr: string;
  textEn?: string;
}

async function fetchQuranVerses(
  surahNumber: number,
  startAyah: number,
  endAyah: number,
  includeEnglish: boolean
): Promise<{ surahNameAr: string; verses: FetchedAyahItem[] }> {
  const surahInfo =
    SURAHS_LIST.find((s) => s.number === surahNumber) || SURAHS_LIST[0];
  const safeStart = Math.max(1, Math.min(surahInfo.ayahCount, startAyah));
  // Support up to 80 continuous verses for 1–5+ minute recitations!
  const safeEnd = Math.max(
    safeStart,
    Math.min(surahInfo.ayahCount, Math.min(safeStart + 79, endAyah))
  );

  const offlineMatch = OFFLINE_QURAN_GEMS.find(
    (g) =>
      g.surahNumber === surahNumber &&
      safeStart >= g.startAyah &&
      safeEnd <= g.endAyah
  );

  if (!navigator.onLine && offlineMatch) {
    return {
      surahNameAr: surahInfo.nameAr,
      verses: offlineMatch.ayahs
        .filter(
          (a) => a.numberInSurah >= safeStart && a.numberInSurah <= safeEnd
        )
        .map((a) => ({
          numberInSurah: a.numberInSurah,
          textAr: a.textAr,
          textEn: includeEnglish ? a.textEn : undefined,
        })),
    };
  }

  try {
    const arRes = await fetch(
      `https://api.alquran.cloud/v1/surah/${surahNumber}/quran-uthmani`
    );
    if (!arRes.ok) throw new Error('Network error');
    const arJson = await arRes.json();
    const rawArAyahs: Array<{ numberInSurah: number; text: string }> =
      arJson?.data?.ayahs || [];

    let rawEnAyahs: Array<{ numberInSurah: number; text: string }> = [];
    if (includeEnglish) {
      const enRes = await fetch(
        `https://api.alquran.cloud/v1/surah/${surahNumber}/en.sahih`
      ).catch(() => null);
      if (enRes?.ok) {
        const enJson = await enRes.json();
        rawEnAyahs = enJson?.data?.ayahs || [];
      }
    }

    const selected = rawArAyahs
      .filter(
        (a) => a.numberInSurah >= safeStart && a.numberInSurah <= safeEnd
      )
      .map((a) => {
        let cleaned = a.text.trim();
        if (surahNumber !== 1 && surahNumber !== 9 && a.numberInSurah === 1) {
          cleaned = cleaned
            .replace(/^بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ\s*/, '')
            .replace(/^بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\s*/, '')
            .trim();
        }
        const enMatch = rawEnAyahs.find(
          (e) => e.numberInSurah === a.numberInSurah
        );
        return {
          numberInSurah: a.numberInSurah,
          textAr: cleaned,
          textEn: enMatch?.text?.trim(),
        };
      });

    if (selected.length > 0) {
      return { surahNameAr: surahInfo.nameAr, verses: selected };
    }
  } catch {
    if (offlineMatch) {
      return {
        surahNameAr: surahInfo.nameAr,
        verses: offlineMatch.ayahs
          .filter(
            (a) => a.numberInSurah >= safeStart && a.numberInSurah <= safeEnd
          )
          .map((a) => ({
            numberInSurah: a.numberInSurah,
            textAr: a.textAr,
            textEn: includeEnglish ? a.textEn : undefined,
          })),
      };
    }
  }

  throw new Error(
    'تعذر جلب نص هذه السورة حالياً — تأكد من الاتصال بالإنترنت أو اختر إحدى السور المحفوظة محلياً.'
  );
}

interface ScheduledAyahOccurrence {
  verse: FetchedAyahItem;
  start: number;
  duration: number;
}

/**
 * Downloads real MP3 recitations, trims MP3 silence with millisecond precision,
 * and ensures total recitation duration meets `minDurationSec` (e.g., ≥ 62s = `دقيقة وأكثر`!)
 * by seamlessly repeating shorter Surahs with synchronized Ayah text overlays across the entire duration!
 */
async function buildRecitationAudioTrack(params: {
  surahNumber: number;
  verses: FetchedAyahItem[];
  reciterId: string;
  minDurationSec: number;
  onStatus: (msg: string) => void;
}): Promise<{
  audioAsset: MediaAsset | null;
  scheduledOccurrences: ScheduledAyahOccurrence[];
  totalDuration: number;
}> {
  const { surahNumber, verses, reciterId, minDurationSec, onStatus } = params;
  const reciter =
    QURAN_RECITERS.find((r) => r.id === reciterId) || QURAN_RECITERS[0];

  if (!navigator.onLine || reciterId === 'none') {
    const scheduledOccurrences: ScheduledAyahOccurrence[] = [];
    let cursor = 0.2;
    let guard = 0;
    do {
      for (const v of verses) {
        const dur = Math.max(4.0, Math.min(10.0, v.textAr.length * 0.095));
        scheduledOccurrences.push({
          verse: v,
          start: Number(cursor.toFixed(3)),
          duration: Number(dur.toFixed(3)),
        });
        cursor += dur + 0.1;
      }
      guard++;
    } while (cursor < minDurationSec && guard < 12);

    return {
      audioAsset: null,
      scheduledOccurrences,
      totalDuration: Math.max(minDurationSec, Number((cursor + 0.3).toFixed(2))),
    };
  }

  const surahPad = String(surahNumber).padStart(3, '0');
  const decodedBuffers: AudioBuffer[] = new Array(verses.length);

  const batchSize = 6;
  for (let startIdx = 0; startIdx < verses.length; startIdx += batchSize) {
    const endIdx = Math.min(verses.length, startIdx + batchSize);
    onStatus(
      `جاري تحميل ومزامنة التلاوة بدقة بصوت القارئ ${reciter.nameAr} (${endIdx}/${verses.length})...`
    );
    await Promise.all(
      verses.slice(startIdx, endIdx).map(async (v, offset) => {
        const ayahPad = String(v.numberInSurah).padStart(3, '0');
        const mp3Url = `https://everyayah.com/data/${reciter.folder}/${surahPad}${ayahPad}.mp3`;
        const resp = await fetch(mp3Url);
        if (!resp.ok) {
          throw new Error('تعذر تحميل ملف التلاوة الصوتي من الخادم.');
        }
        const arrBuf = await resp.arrayBuffer();
        const decoder = new OfflineAudioContext(2, 1, 44100);
        const audioBuf = await decoder.decodeAudioData(arrBuf.slice(0));
        decodedBuffers[startIdx + offset] = audioBuf;
      })
    );
  }

  // Compute exact trimmed speech bounds per verse for pinpoint millisecond sync!
  const trimmedBounds = decodedBuffers.map((b) => detectActiveVoiceBounds(b));
  const sampleRate = 44100;
  const verseBreathGapSec = 0.1;
  const cyclePauseSec = 0.55;

  const scheduledQueue: Array<{
    bufIdx: number;
    timelineStart: number;
    playOffset: number;
    playDuration: number;
  }> = [];
  const scheduledOccurrences: ScheduledAyahOccurrence[] = [];

  let cursor = 0.15;
  let cycleGuard = 0;

  do {
    if (cycleGuard > 0) {
      cursor += cyclePauseSec;
    }
    for (let i = 0; i < verses.length; i++) {
      const bounds = trimmedBounds[i];
      const tStart = cursor;
      scheduledQueue.push({
        bufIdx: i,
        timelineStart: tStart,
        playOffset: bounds.offsetSec,
        playDuration: bounds.durationSec,
      });
      scheduledOccurrences.push({
        verse: verses[i],
        start: Number(tStart.toFixed(3)),
        duration: Number((bounds.durationSec + verseBreathGapSec * 0.85).toFixed(3)),
      });
      cursor += bounds.durationSec + verseBreathGapSec;
    }
    cycleGuard++;
  } while (cursor < minDurationSec && cycleGuard < 14);

  const totalDur = cursor + 0.35;

  const mixOffline = new OfflineAudioContext(
    2,
    Math.ceil(totalDur * sampleRate),
    sampleRate
  );

  for (const item of scheduledQueue) {
    const buf = decodedBuffers[item.bufIdx];
    const src = mixOffline.createBufferSource();
    src.buffer = buf;
    const gain = mixOffline.createGain();
    const t0 = item.timelineStart;
    const tEnd = t0 + item.playDuration;
    gain.gain.setValueAtTime(0.001, t0);
    gain.gain.linearRampToValueAtTime(1.0, t0 + 0.025);
    gain.gain.setValueAtTime(1.0, Math.max(t0 + 0.025, tEnd - 0.035));
    gain.gain.linearRampToValueAtTime(0.001, tEnd);
    src.connect(gain);
    gain.connect(mixOffline.destination);
    src.start(t0, item.playOffset, item.playDuration);
  }

  const fullRendered = await mixOffline.startRendering();
  const wavBlob = audioBufferToWavBlob(fullRendered);
  const url = URL.createObjectURL(wavBlob);

  const audioAsset: MediaAsset = {
    id: `quran_rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    name: `تلاوة ${reciter.nameAr} — سورة ${SURAHS_LIST[surahNumber - 1]?.nameAr || ''}`,
    type: 'audio',
    mimeType: 'audio/wav',
    sizeBytes: wavBlob.size,
    duration: fullRendered.duration,
    url,
    blob: wavBlob,
    waveformPeaks: extractWaveformPeaks(fullRendered, 96),
    createdAt: Date.now(),
  };

  return {
    audioAsset,
    scheduledOccurrences,
    totalDuration: Number(fullRendered.duration.toFixed(2)),
  };
}

export interface BuiltQuranSceneResult {
  title: string;
  surahNameAr: string;
  theme: QuranVisualTheme;
  audioAsset: MediaAsset | null;
  recitationAudioClip: AudioClip | null;
  textOverlays: TextOverlay[];
  totalDuration: number;
}

/**
 * Builds a 100% pure, pinpoint-accurate Quranic scene (≥ 1 Minute by default!)
 * containing ONLY:
 *   1. Clean Written Uthmani Ayahs synchronized millisecond-for-millisecond to the Recitation
 *   2. Pure Recitation Audio Track (zero music)
 *   3. Ready to be paired with pure unaltered Nature/Sky/Ocean/Mountain/Meadow/Mosque videos (ZERO forced effects/filters/transitions!)
 */
export async function buildCompleteQuranScene(params: {
  surahNumber: number;
  startAyah: number;
  endAyah: number;
  reciterId: string;
  visualThemeId: QuranVisualThemeId;
  targetAspectRatio?: AspectRatio;
  minDurationSec?: number; // Default 62s ("دقيقة وأكثر" = 1:02+!)
  customIncludeEnglish?: boolean;
  customHighlightWords?: boolean;
  onStatus: (msg: string) => void;
}): Promise<BuiltQuranSceneResult> {
  const {
    surahNumber,
    startAyah,
    endAyah,
    reciterId,
    visualThemeId,
    targetAspectRatio,
    minDurationSec = 62,
    customIncludeEnglish,
    customHighlightWords,
    onStatus,
  } = params;

  const baseTheme =
    QURAN_VISUAL_THEMES.find((t) => t.id === visualThemeId) ||
    QURAN_VISUAL_THEMES[0];
  const effectiveAspect = targetAspectRatio || baseTheme.aspectRatio;
  const theme: QuranVisualTheme = {
    ...baseTheme,
    aspectRatio: effectiveAspect,
  };
  const isWide = effectiveAspect === '16:9';

  const withEnglish =
    customIncludeEnglish !== undefined
      ? customIncludeEnglish
      : theme.includeEnglishTranslation;
  const withWordHighlight =
    customHighlightWords !== undefined
      ? customHighlightWords
      : theme.highlightWords;

  onStatus('جاري جلب الآيات الكريمة بالرسم العثماني المضبوط بالتشكيل...');
  const { surahNameAr, verses } = await fetchQuranVerses(
    surahNumber,
    startAyah,
    endAyah,
    withEnglish
  );

  const { audioAsset, scheduledOccurrences, totalDuration } =
    await buildRecitationAudioTrack({
      surahNumber,
      verses,
      reciterId,
      minDurationSec,
      onStatus,
    });

  const textOverlays: TextOverlay[] = [];

  // 1. Clean Top Surah Name Header (static, zero animation distractions)
  const headerLabel =
    surahNumber === 9
      ? `﴿ سُورَةُ ${surahNameAr} ﴾`
      : `﷽\n﴿ سُورَةُ ${surahNameAr} ﴾`;

  textOverlays.push({
    id: `qhdr_${Date.now()}`,
    text: headerLabel,
    originalText: headerLabel,
    startTime: 0,
    duration: Number(totalDuration.toFixed(2)),
    fontFamily: 'Amiri',
    fontSize: isWide ? 29 : 33,
    fontWeight: 700,
    color: '#FEF9C3',
    strokeColor: '#000000',
    strokeWidth: 4,
    shadowColor: '#000000',
    shadowBlur: 10,
    bgColor: '#050811',
    bgOpacity: 38,
    bgRadius: 18,
    opacity: 95,
    align: 'center',
    x: 50,
    y: isWide ? 14 : 15,
    animation: 'none',
    presetId: 'quran-uthmani',
    isSticker: true,
    highlightWords: false,
  });

  // 2. Pinpoint Millisecond-Synchronized Written Uthmani Ayahs!
  scheduledOccurrences.forEach((occ, idx) => {
    const v = occ.verse;
    const ayahBadge = `﴿${toArabicIndicNumerals(v.numberInSurah)}﴾`;
    const arabicFormatted = `﴿ ${v.textAr} ﴾ ${ayahBadge}`;
    const fullDisplay =
      withEnglish && v.textEn
        ? `${arabicFormatted}\n${v.textEn}`
        : arabicFormatted;

    const autoFontSize = isWide
      ? v.textAr.length > 220
        ? 28
        : v.textAr.length > 120
          ? 34
          : withEnglish
            ? 36
            : 42
      : v.textAr.length > 220
        ? 30
        : v.textAr.length > 120
          ? 36
          : withEnglish
            ? 38
            : 46;

    textOverlays.push({
      id: `qayah_${Date.now()}_${idx}`,
      text: fullDisplay,
      originalText: arabicFormatted,
      startTime: occ.start,
      duration: occ.duration,
      fontFamily: 'Amiri',
      fontSize: autoFontSize,
      fontWeight: 700,
      color: theme.ayahColor,
      strokeColor: theme.strokeColor,
      strokeWidth: 5,
      shadowColor: '#000000',
      shadowBlur: 14,
      bgColor: theme.bgBoxColor,
      bgOpacity: theme.bgBoxOpacity,
      bgRadius: 22,
      opacity: 100,
      align: 'center',
      x: 50,
      y: 53,
      animation: 'none',
      presetId: 'quran-uthmani',
      isSubtitle: true,
      highlightWords: withWordHighlight && !withEnglish,
      highlightColor: theme.highlightColor,
      wordTimings: buildWordTimingsForPhrase(fullDisplay, occ.duration),
    });
  });

  // 3. Clean Reciter Name Label at Bottom
  const reciterObj = QURAN_RECITERS.find((r) => r.id === reciterId);
  if (reciterObj && reciterId !== 'none') {
    const credit = `القارئ: ${reciterObj.nameAr}`;
    textOverlays.push({
      id: `qrec_${Date.now()}`,
      text: credit,
      originalText: credit,
      startTime: 0,
      duration: Number(totalDuration.toFixed(2)),
      fontFamily: 'Cairo',
      fontSize: 22,
      fontWeight: 700,
      color: '#E2E8F0',
      strokeColor: '#000000',
      strokeWidth: 3,
      shadowColor: '#000000',
      shadowBlur: 8,
      bgColor: '#090D16',
      bgOpacity: 42,
      bgRadius: 99,
      opacity: 88,
      align: 'center',
      x: 50,
      y: 89,
      animation: 'none',
      isSticker: true,
      highlightWords: false,
    });
  }

  let recitationAudioClip: AudioClip | null = null;
  if (audioAsset) {
    recitationAudioClip = {
      id: `aud_quran_${Date.now()}`,
      assetId: audioAsset.id,
      name: audioAsset.name,
      category: 'voiceover',
      startTime: 0,
      trimStart: 0,
      duration: Number(audioAsset.duration.toFixed(2)),
      sourceDuration: audioAsset.duration,
      volume: 100,
      muted: false,
      fadeIn: 0.04,
      fadeOut: 0.2,
    };
  }

  return {
    title: `قرآن كريم — سورة ${surahNameAr} (${startAyah}-${endAyah})`,
    surahNameAr,
    theme,
    audioAsset,
    recitationAudioClip,
    textOverlays,
    totalDuration,
  };
}
