import { computeProjectDuration } from '../engine/compositor';
import { MediaAsset, ProjectData, ProjectSummary } from '../types/editor';

const DB_NAME = 'laqta_pro_studio_db';
const DB_VERSION = 1;
const STORE_PROJECTS = 'projects';
const STORE_BLOBS = 'media_blobs';

function openStudioDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
        const store = db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
        store.createIndex('updatedAt', 'updatedAt', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_BLOBS)) {
        db.createObjectStore(STORE_BLOBS, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveProjectToStorage(
  project: ProjectData
): Promise<{ savedBlobs: boolean }> {
  const db = await openStudioDb();
  let savedBlobs = true;

  // Store media blobs safely first (skip gracefully if phone storage quota is tight)
  for (const asset of project.assets) {
    if (asset.blob && asset.blob.size < 180 * 1024 * 1024) {
      try {
        await new Promise<void>((resolve, reject) => {
          const tx = db.transaction(STORE_BLOBS, 'readwrite');
          tx.objectStore(STORE_BLOBS).put({
            id: `${project.id}__${asset.id}`,
            projectId: project.id,
            blob: asset.blob,
          });
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error);
        });
      } catch {
        savedBlobs = false;
      }
    }
  }

  // Strip live blob & volatile blobURL from JSON record, store clean serializable state
  const serializableProject: ProjectData = {
    ...project,
    updatedAt: Date.now(),
    assets: project.assets.map((a) => ({
      ...a,
      url: '',
      blob: undefined,
    })),
  };

  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_PROJECTS, 'readwrite');
    tx.objectStore(STORE_PROJECTS).put(serializableProject);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });

  db.close();
  return { savedBlobs };
}

export async function listSavedProjects(): Promise<ProjectSummary[]> {
  try {
    const db = await openStudioDb();
    const projects = await new Promise<ProjectData[]>((resolve, reject) => {
      const tx = db.transaction(STORE_PROJECTS, 'readonly');
      const req = tx.objectStore(STORE_PROJECTS).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
    db.close();

    return projects
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .map((p) => ({
        id: p.id,
        name: p.name,
        createdAt: p.createdAt,
        updatedAt: p.updatedAt,
        thumbnailDataUrl:
          p.thumbnailDataUrl || p.assets.find((a) => a.thumbnailDataUrl)?.thumbnailDataUrl,
        aspectRatio: p.aspectRatio,
        duration: computeProjectDuration(p.clips, p.texts, p.audioClips),
        clipCount: p.clips.length,
      }));
  } catch {
    return [];
  }
}

export async function loadProjectFromStorage(
  projectId: string
): Promise<ProjectData | null> {
  const db = await openStudioDb();
  const rawProject = await new Promise<ProjectData | undefined>(
    (resolve, reject) => {
      const tx = db.transaction(STORE_PROJECTS, 'readonly');
      const req = tx.objectStore(STORE_PROJECTS).get(projectId);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    }
  );

  if (!rawProject) {
    db.close();
    return null;
  }

  const hydratedAssets: MediaAsset[] = [];
  for (const asset of rawProject.assets) {
    const blobRecord = await new Promise<{ blob?: Blob } | undefined>(
      (resolve) => {
        const tx = db.transaction(STORE_BLOBS, 'readonly');
        const req = tx.objectStore(STORE_BLOBS).get(`${projectId}__${asset.id}`);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(undefined);
      }
    );

    if (blobRecord?.blob) {
      hydratedAssets.push({
        ...asset,
        blob: blobRecord.blob,
        url: URL.createObjectURL(blobRecord.blob),
      });
    } else if (asset.thumbnailDataUrl && asset.type === 'image') {
      hydratedAssets.push({
        ...asset,
        url: asset.thumbnailDataUrl,
      });
    } else {
      hydratedAssets.push(asset);
    }
  }

  db.close();
  return {
    ...rawProject,
    assets: hydratedAssets,
  };
}

export async function deleteProjectFromStorage(projectId: string): Promise<void> {
  const db = await openStudioDb();
  const project = await new Promise<ProjectData | undefined>((resolve) => {
    const tx = db.transaction(STORE_PROJECTS, 'readonly');
    const req = tx.objectStore(STORE_PROJECTS).get(projectId);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => resolve(undefined);
  });

  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([STORE_PROJECTS, STORE_BLOBS], 'readwrite');
    tx.objectStore(STORE_PROJECTS).delete(projectId);
    if (project?.assets) {
      for (const a of project.assets) {
        tx.objectStore(STORE_BLOBS).delete(`${projectId}__${a.id}`);
      }
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });

  db.close();
}
