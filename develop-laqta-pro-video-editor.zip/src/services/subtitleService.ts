import { TEXT_STYLE_PRESETS } from '../constants/presets';
import {
  audioBufferToWavBlob,
  mixProjectAudioBuffer,
} from '../engine/audioEngine';
import { computeClipSlots } from '../engine/compositor';
import {
  AudioClip,
  MediaAsset,
  TextOverlay,
  TextStylePresetId,
  VideoClip,
  WordTiming,
} from '../types/editor';

export interface AiProviderConfig {
  provider: 'openai' | 'groq' | 'custom';
  baseUrl: string;
  apiKey: string;
  sttModel: string;
  translateModel: string;
}

export const DEFAULT_AI_PROVIDER_PRESETS: Record<
  'openai' | 'groq',
  Omit<AiProviderConfig, 'apiKey'>
> = {
  openai: {
    provider: 'openai',
    baseUrl: 'https://api.openai.com/v1',
    sttModel: 'whisper-1',
    translateModel: 'gpt-4o-mini',
  },
  groq: {
    provider: 'groq',
    baseUrl: 'https://api.groq.com/openai/v1',
    sttModel: 'whisper-large-v3-turbo',
    translateModel: 'llama-3.3-70b-versatile',
  },
};

export const SPOKEN_SOURCE_LANGUAGES = [
  { code: 'arabic', iso: 'ar', label: 'العربية (Arabic)' },
  { code: 'english', iso: 'en', label: 'الإنجليزية (English)' },
  { code: 'french', iso: 'fr', label: 'الفرنسية (Français)' },
  { code: 'turkish', iso: 'tr', label: 'التركية (Türkçe)' },
  { code: 'spanish', iso: 'es', label: 'الإسبانية (Español)' },
  { code: 'german', iso: 'de', label: 'الألمانية (Deutsch)' },
];

export const SUPPORTED_TRANSLATION_LANGUAGES = [
  { code: 'none', label: 'نفس لغة الفيديو (بدون ترجمة)' },
  { code: 'ar', label: 'العربية (Arabic)' },
  { code: 'en', label: 'الإنجليزية (English)' },
  { code: 'fr', label: 'الفرنسية (Français)' },
  { code: 'tr', label: 'التركية (Türkçe)' },
  { code: 'es', label: 'الإسبانية (Español)' },
  { code: 'de', label: 'الألمانية (Deutsch)' },
];

type WhisperTranscriberFn = ((
  audio: Float32Array,
  opts: Record<string, unknown>
) => Promise<{
  text?: string;
  chunks?: Array<{ text: string; timestamp: [number, number | null] }>;
}>) & {
  dispose?: () => Promise<void>;
};

// Reusable & self-healing Whisper ONNX pipeline instance — supports unlimited consecutive runs!
let cachedLocalWhisperPipeline: WhisperTranscriberFn | null = null;
let transcriptionQueuePromise: Promise<unknown> = Promise.resolve();

function guessIsoLanguageFromText(text: string): string {
  if (/[\u0600-\u06FF]/.test(text)) return 'ar';
  if (/[ğüşıöçĞÜŞİÖÇ]/.test(text)) return 'tr';
  if (/[éèêàùçœÉÈÊÀÙÇ]/.test(text)) return 'fr';
  if (/[ñáéíóú¿¡]/.test(text)) return 'es';
  if (/[äöüßÄÖÜ]/.test(text)) return 'de';
  return 'en';
}

export function buildWordTimingsForPhrase(
  phrase: string,
  durationSec: number
): WordTiming[] {
  const words = phrase.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];

  const weights = words.map((w) => Math.max(2, w.length));
  const totalWeight = weights.reduce((a, b) => a + b, 0);

  let cursor = 0;
  return words.map((word, idx) => {
    const dur = (weights[idx] / totalWeight) * durationSec;
    const timing: WordTiming = {
      word,
      start: Number(cursor.toFixed(3)),
      end: Number((cursor + dur).toFixed(3)),
    };
    cursor += dur;
    return timing;
  });
}

export function createSubtitleOverlay(params: {
  text: string;
  originalText?: string;
  startTime: number;
  duration: number;
  presetId?: TextStylePresetId;
  wordTimings?: WordTiming[];
  language?: string;
}): TextOverlay {
  const targetPresetId = params.presetId || 'bold-words';
  const preset =
    TEXT_STYLE_PRESETS.find((p) => p.id === targetPresetId) ||
    TEXT_STYLE_PRESETS[0];
  const dur = Math.max(0.4, params.duration);
  const cleanText = params.text.trim();
  return {
    id: `sub_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    text: cleanText,
    originalText: (params.originalText || cleanText).trim(),
    startTime: Math.max(0, Number(params.startTime.toFixed(2))),
    duration: Number(dur.toFixed(2)),
    fontFamily: preset.style.fontFamily || 'Cairo',
    fontSize: 48,
    fontWeight: preset.style.fontWeight || 900,
    color: preset.style.color || '#FFFFFF',
    strokeColor: preset.style.strokeColor || '#000000',
    strokeWidth: preset.style.strokeWidth ?? 8,
    shadowColor: preset.style.shadowColor || '#000000',
    shadowBlur: preset.style.shadowBlur ?? 14,
    bgColor: preset.style.bgColor || '#09090B',
    bgOpacity: preset.style.bgOpacity ?? 48,
    bgRadius: preset.style.bgRadius ?? 20,
    opacity: 100,
    align: 'center',
    x: 50,
    y: 80,
    animation: preset.style.animation || 'pop',
    presetId: preset.id,
    isSubtitle: true,
    language: params.language || 'ar',
    highlightWords: preset.style.highlightWords ?? true,
    highlightColor: preset.style.highlightColor || '#00E5DF',
    wordTimings:
      params.wordTimings && params.wordTimings.length > 0
        ? params.wordTimings
        : buildWordTimingsForPhrase(cleanText, dur),
  };
}

/**
 * Zero-API-Key Neural Translation Engine — works UNLIMITED times across any language pairs!
 */
export async function translateLinesKeyless(
  lines: string[],
  targetLangIso: string,
  sourceLangIso = 'auto'
): Promise<string[]> {
  if (!targetLangIso || targetLangIso === 'none' || lines.length === 0) {
    return lines;
  }

  if (!navigator.onLine) {
    throw new Error(
      'يتطلب الاتصال بالإنترنت لإتمام الترجمة اللغوية المجانية.'
    );
  }

  const translateSingle = async (text: string): Promise<string> => {
    const clean = text.trim();
    if (!clean) return text;

    const detectedSrc =
      sourceLangIso === 'auto' ? guessIsoLanguageFromText(clean) : sourceLangIso;
    if (detectedSrc === targetLangIso) {
      return clean;
    }

    // Primary zero-key fast neural translator (cache-busted so repeated re-translations always execute freshly)
    try {
      const url =
        `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(
          targetLangIso
        )}&dt=t&q=` + encodeURIComponent(clean);
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        const joined = Array.isArray(data?.[0])
          ? data[0].map((part: [string]) => part[0]).join('')
          : '';
        if (joined.trim()) return joined.trim();
      }
    } catch {
      // Fallback to MyMemory public translation API below
    }

    const safeSrc = detectedSrc === targetLangIso ? 'en' : detectedSrc;
    const pair = `${safeSrc}|${targetLangIso}`;
    const fbRes = await fetch(
      `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
        clean
      )}&langpair=${encodeURIComponent(pair)}`
    );
    if (fbRes.ok) {
      const fbJson = await fbRes.json();
      if (fbJson?.responseData?.translatedText) {
        return String(fbJson.responseData.translatedText).trim();
      }
    }
    return clean;
  };

  return Promise.all(lines.map((line) => translateSingle(line)));
}

/**
 * Translates ALL existing Text / Subtitle overlays unlimited times cleanly!
 * Always preserves `originalText` so switching from Arabic -> English -> French -> Turkish -> back to Arabic
 * or toggling Bilingual ON/OFF never loses fidelity!
 */
export async function translateExistingOverlaysKeyless(params: {
  overlays: TextOverlay[];
  targetLanguageCode: string;
  bilingual: boolean;
}): Promise<TextOverlay[]> {
  const { overlays, targetLanguageCode, bilingual } = params;
  // Filter out pure emoji stickers so stickers stay intact
  const translatable = overlays.filter((o) => !o.isSticker);
  if (translatable.length === 0) {
    throw new Error('لا توجد نصوص أو جمل ترجمة حالياً على الخط الزمني لترجمتها.');
  }
  if (!targetLanguageCode || targetLanguageCode === 'none') {
    throw new Error('يرجى اختيار اللغة المراد الترجمة إليها أولاً.');
  }

  // Always translate from preserved clean originalText (or first line) so unlimited re-translations stay 100% crisp!
  const baseLines = overlays.map((o) =>
    (o.originalText || o.text.split('\n')[0]).trim()
  );

  const translated = await Promise.all(
    overlays.map(async (ov, idx) => {
      if (ov.isSticker) return ov.text;
      const res = await translateLinesKeyless(
        [baseLines[idx]],
        targetLanguageCode,
        'auto'
      );
      return res[0] || baseLines[idx];
    })
  );

  return overlays.map((ov, idx) => {
    if (ov.isSticker) return ov;
    const orig = baseLines[idx];
    const newTranslated = translated[idx] || orig;
    const finalText =
      bilingual && orig.toLowerCase() !== newTranslated.toLowerCase()
        ? `${orig}\n${newTranslated}`
        : newTranslated;
    return {
      ...ov,
      originalText: orig,
      text: finalText,
      language: targetLanguageCode,
      highlightWords: !bilingual && Boolean(ov.highlightWords),
      wordTimings: buildWordTimingsForPhrase(finalText, ov.duration),
    };
  });
}

async function getOrCreateWhisperPipeline(
  forceReset: boolean,
  onProgress: (percent: number, message: string) => void
): Promise<WhisperTranscriberFn> {
  if (forceReset && cachedLocalWhisperPipeline) {
    try {
      await cachedLocalWhisperPipeline.dispose?.();
    } catch {
      // ignore disposal error
    }
    cachedLocalWhisperPipeline = null;
  }

  if (cachedLocalWhisperPipeline) {
    return cachedLocalWhisperPipeline;
  }

  if (!navigator.onLine) {
    throw new Error(
      'يتطلب تشغيل محرك الذكاء الاصطناعي Whisper اتصالاً بالإنترنت لتحميل النموذج المجاني (بدون مفتاح API).'
    );
  }

  onProgress(14, 'جاري تهيئة محرك الذكاء الاصطناعي المجاني Whisper...');
  const dynamicImport = new Function('u', 'return import(u)') as (
    u: string
  ) => Promise<{
    pipeline: (
      task: string,
      model: string,
      options: Record<string, unknown>
    ) => Promise<WhisperTranscriberFn>;
    env: { allowLocalModels: boolean };
  }>;

  const { pipeline, env } = await dynamicImport(
    'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.5.1'
  );
  env.allowLocalModels = false;

  const loaded = await pipeline(
    'automatic-speech-recognition',
    'onnx-community/whisper-tiny',
    {
      dtype: 'q8',
      device: 'wasm',
      progress_callback: (info: { status?: string; progress?: number }) => {
        if (typeof info?.progress === 'number') {
          const mapped = 15 + Math.round(info.progress * 0.48);
          onProgress(
            Math.min(64, mapped),
            `جاري تجهيز محرك Whisper الذكي (${Math.round(info.progress)}%)...`
          );
        }
      },
    }
  );

  cachedLocalWhisperPipeline = loaded;
  return loaded;
}

/**
 * Prepares a clean, peak-normalized, DC-centered standalone Float32Array (16kHz)
 * so every Whisper run gets fresh unshared memory and clear human vocal amplitude!
 */
function cloneAndNormalizeSpeechPcm(
  rawChannel: Float32Array,
  startSample = 0,
  endSample = rawChannel.length
): { normalized: Float32Array; maxPeak: number } {
  const safeStart = Math.max(0, Math.min(rawChannel.length, startSample));
  const safeEnd = Math.max(safeStart, Math.min(rawChannel.length, endSample));
  const len = safeEnd - safeStart;
  const out = new Float32Array(len);

  let maxPeak = 0;
  let mean = 0;
  for (let i = 0; i < len; i++) {
    const v = rawChannel[safeStart + i];
    mean += v;
    const abs = Math.abs(v);
    if (abs > maxPeak) maxPeak = abs;
  }
  mean = len > 0 ? mean / len : 0;

  if (maxPeak > 0.001) {
    const targetGain = Math.min(8.0, 0.92 / maxPeak);
    for (let i = 0; i < len; i++) {
      const s = (rawChannel[safeStart + i] - mean) * targetGain;
      out[i] = s < -1 ? -1 : s > 1 ? 1 : s;
    }
  }

  return { normalized: out, maxPeak };
}

/**
 * PRIMARY CAPCUT AUTO-CAPTIONS ENGINE — UNLIMITED USES, 100% FREE & ZERO API KEY!
 * Works unlimited times on ALL videos/projects OR on a specific selected clip,
 * with automatic session self-healing so subsequent runs NEVER stall or fail!
 */
export async function extractKeylessAiSubtitles(params: {
  assets: MediaAsset[];
  clips: VideoClip[];
  audioClips: AudioClip[];
  totalDuration: number;
  selectedClipId?: string | null; // Optional: transcribe ONLY the selected clip if user chose 'clip' scope!
  spokenLanguage: string;
  targetLanguageCode: string;
  bilingual: boolean;
  stylePresetId: TextStylePresetId;
  onProgress: (percent: number, message: string) => void;
}): Promise<TextOverlay[]> {
  // Serialize concurrent clicks cleanly via queue so rapid repeated clicks never collide in WASM memory
  const runTask = async (): Promise<TextOverlay[]> => {
    const {
      assets,
      clips,
      audioClips,
      totalDuration,
      selectedClipId,
      spokenLanguage,
      targetLanguageCode,
      bilingual,
      stylePresetId,
      onProgress,
    } = params;

    onProgress(6, 'جاري قراءة الموجة الصوتية وتنقية الصوت البشري...');
    const sampleRate = 16000;
    const mixedBuffer = await mixProjectAudioBuffer({
      assets,
      clips,
      audioClips,
      totalDuration,
      sampleRate,
      numberOfChannels: 1,
    });

    if (!mixedBuffer) {
      throw new Error(
        'لا يوجد صوت مسموع في المشروع حالياً. أضف فيديو بصوت أو سجل تعليقاً صوتياً أولاً.'
      );
    }

    // Determine exact timeline window (whole timeline vs single selected clip)
    let windowOffsetSec = 0;
    let windowDurationSec = totalDuration;
    if (selectedClipId) {
      const slot = computeClipSlots(clips).find(
        (s) => s.clip.id === selectedClipId
      );
      if (slot) {
        windowOffsetSec = slot.startTime;
        windowDurationSec = slot.clip.duration;
      }
    }

    const rawPcm = mixedBuffer.getChannelData(0);
    const startIdx = Math.floor(windowOffsetSec * sampleRate);
    const endIdx = Math.min(
      rawPcm.length,
      Math.ceil((windowOffsetSec + windowDurationSec) * sampleRate)
    );

    const { normalized: cleanFloat32, maxPeak } = cloneAndNormalizeSpeechPcm(
      rawPcm,
      startIdx,
      endIdx
    );

    if (maxPeak < 0.002 || cleanFloat32.length < 1600) {
      throw new Error(
        'المسار الصوتي الحالي مكتوم أو خالٍ من الصوت. تأكد من تفعيل صوت المقطع أو تسجيل تعليق صوتي.'
      );
    }

    // Run Whisper inference with automatic self-healing retry if WASM session ever needs fresh reset!
    let rawResult: {
      text?: string;
      chunks?: Array<{ text: string; timestamp: [number, number | null] }>;
    } | null = null;

    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const transcriber = await getOrCreateWhisperPipeline(
          attempt > 0,
          onProgress
        );
        onProgress(
          68,
          'جاري استخراج الكلام وتوقيتات الجمل بالذكاء الاصطناعي...'
        );
        // Always pass a fresh standalone Float32Array copy per attempt
        const inputCopy = new Float32Array(cleanFloat32);
        rawResult = await transcriber(inputCopy, {
          language: spokenLanguage || 'arabic',
          task: 'transcribe',
          chunk_length_s: 25,
          stride_length_s: 4,
          return_timestamps: true,
        });
        break;
      } catch (err) {
        if (attempt === 1) {
          throw err;
        }
        onProgress(40, 'جاري إعادة تنشيط جلسة المحرك الذكي تلقائياً...');
      }
    }

    const cleanSpeechText = (s: string) =>
      s
        .replace(/\[[^\]]*\]|\([^)]*\)/g, '')
        .replace(/\s+/g, ' ')
        .trim();

    let overlays: TextOverlay[] = [];

    if (Array.isArray(rawResult?.chunks) && rawResult!.chunks.length > 0) {
      overlays = rawResult!.chunks
        .map((ch) => {
          const txt = cleanSpeechText(ch.text || '');
          if (!txt) return null;
          const relStart = Math.max(0, ch.timestamp?.[0] ?? 0);
          const relEnd =
            ch.timestamp?.[1] != null
              ? Math.max(relStart + 0.5, ch.timestamp[1])
              : Math.min(windowDurationSec, relStart + 2.4);
          return createSubtitleOverlay({
            text: txt,
            originalText: txt,
            startTime: windowOffsetSec + relStart,
            duration: Math.max(0.45, relEnd - relStart),
            presetId: stylePresetId,
          });
        })
        .filter((x): x is TextOverlay => Boolean(x));
    }

    if (overlays.length === 0 && rawResult?.text) {
      const cleanedFull = cleanSpeechText(rawResult.text);
      if (cleanedFull) {
        overlays = generateSubtitlesFromScript(
          cleanedFull,
          windowDurationSec,
          5,
          stylePresetId
        ).map((ov) => ({
          ...ov,
          startTime: Number((windowOffsetSec + ov.startTime).toFixed(2)),
        }));
      }
    }

    if (overlays.length === 0) {
      throw new Error(
        'لم يُرصد كلام بشري مسموع في هذا المقطع (يبدو أنه موسيقى فقط بدون صوت متحدث). سجل تعليقاً صوتياً أو استخدم الإملاء الحي أو المزامنة النصية بالأسفل!'
      );
    }

    // Optional Zero-Key Neural Translation step!
    if (targetLanguageCode && targetLanguageCode !== 'none') {
      onProgress(86, 'جاري ترجمة الجمل المستخرجة تلقائياً...');
      const sourceIso =
        SPOKEN_SOURCE_LANGUAGES.find((s) => s.code === spokenLanguage)?.iso ||
        'auto';
      const translatedLines = await translateLinesKeyless(
        overlays.map((o) => o.text),
        targetLanguageCode,
        sourceIso
      );

      overlays = overlays.map((ov, idx) => {
        const transLine = translatedLines[idx] || ov.text;
        const origLine = ov.originalText || ov.text;
        const finalText = bilingual ? `${origLine}\n${transLine}` : transLine;
        return {
          ...ov,
          originalText: origLine,
          text: finalText,
          language: targetLanguageCode,
          highlightWords: !bilingual && Boolean(ov.highlightWords),
          wordTimings: buildWordTimingsForPhrase(finalText, ov.duration),
        };
      });
    }

    onProgress(100, 'تم إنشاء الترجمة التلقائية ومزامنة الكلمات بنجاح!');
    return overlays;
  };

  const resultPromise = transcriptionQueuePromise.then(runTask, runTask);
  transcriptionQueuePromise = resultPromise.catch(() => {});
  return resultPromise;
}

export function generateSubtitlesFromScript(
  scriptText: string,
  totalDuration: number,
  maxWordsPerLine = 5,
  presetId: TextStylePresetId = 'bold-words'
): TextOverlay[] {
  const cleaned = scriptText.trim();
  if (!cleaned) return [];

  const rawChunks = cleaned
    .split(/[\n.!؟?!،,;]+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const phrases: string[] = [];
  for (const chunk of rawChunks) {
    const words = chunk.split(/\s+/).filter(Boolean);
    for (let i = 0; i < words.length; i += maxWordsPerLine) {
      phrases.push(words.slice(i, i + maxWordsPerLine).join(' '));
    }
  }

  if (phrases.length === 0) return [];

  const usableDuration = Math.max(1.5, totalDuration - 0.15);
  const charCounts = phrases.map((p) => Math.max(4, p.length));
  const totalChars = charCounts.reduce((a, b) => a + b, 0);

  let currentStart = 0.08;
  return phrases.map((phrase, idx) => {
    const segDur = Math.max(
      0.55,
      (charCounts[idx] / totalChars) * usableDuration
    );
    const sub = createSubtitleOverlay({
      text: phrase,
      originalText: phrase,
      startTime: currentStart,
      duration: Math.max(0.45, segDur - 0.04),
      presetId,
    });
    currentStart += segDur;
    return sub;
  });
}

export function parseSrtContent(srtText: string): TextOverlay[] {
  const blocks = srtText
    .replace(/\r\n/g, '\n')
    .trim()
    .split(/\n\s*\n/);

  const parseTime = (str: string): number => {
    const match = str.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
    if (!match) return 0;
    const h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    const s = parseInt(match[3], 10);
    const ms = parseInt(match[4].padEnd(3, '0').slice(0, 3), 10);
    return h * 3600 + m * 60 + s + ms / 1000;
  };

  const results: TextOverlay[] = [];
  for (const block of blocks) {
    const lines = block
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);
    const timeLineIdx = lines.findIndex((l) => l.includes('-->'));
    if (timeLineIdx === -1) continue;
    const [startStr, endStr] = lines[timeLineIdx].split('-->');
    const startTime = parseTime(startStr);
    const endTime = parseTime(endStr);
    const text = lines
      .slice(timeLineIdx + 1)
      .join(' ')
      .trim();
    if (!text) continue;

    results.push(
      createSubtitleOverlay({
        text,
        originalText: text,
        startTime,
        duration: Math.max(0.4, endTime - startTime),
      })
    );
  }
  return results;
}

export function exportSubtitlesToSrt(texts: TextOverlay[]): string {
  const formatTime = (sec: number): string => {
    const totalMs = Math.max(0, Math.round(sec * 1000));
    const h = Math.floor(totalMs / 3600000);
    const m = Math.floor((totalMs % 3600000) / 60000);
    const s = Math.floor((totalMs % 60000) / 1000);
    const ms = totalMs % 1000;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
  };

  const sorted = [...texts].sort((a, b) => a.startTime - b.startTime);
  return sorted
    .map((item, idx) => {
      const start = formatTime(item.startTime);
      const end = formatTime(item.startTime + item.duration);
      return `${idx + 1}\n${start} --> ${end}\n${item.text}`;
    })
    .join('\n\n');
}

export async function extractAndTranslateAiSubtitles(params: {
  config: AiProviderConfig;
  assets: MediaAsset[];
  clips: VideoClip[];
  audioClips: AudioClip[];
  totalDuration: number;
  sourceLanguageHint?: string;
  targetLanguageCode: string;
  onStatus: (msg: string) => void;
}): Promise<TextOverlay[]> {
  const {
    config,
    assets,
    clips,
    audioClips,
    totalDuration,
    sourceLanguageHint,
    targetLanguageCode,
    onStatus,
  } = params;

  onStatus('جاري استخلاص المسار الصوتي من المشروع...');
  const mixedBuffer = await mixProjectAudioBuffer({
    assets,
    clips,
    audioClips,
    totalDuration,
    sampleRate: 16000,
    numberOfChannels: 1,
  });

  if (!mixedBuffer) {
    throw new Error('لا يوجد مسار صوتي قابل للاستخراج في المشروع الحالي.');
  }

  const wavBlob = audioBufferToWavBlob(mixedBuffer);
  const formData = new FormData();
  formData.append('file', wavBlob, 'timeline_audio.wav');
  formData.append('model', config.sttModel || 'whisper-1');
  formData.append('response_format', 'verbose_json');
  formData.append('timestamp_granularities[]', 'word');
  formData.append('timestamp_granularities[]', 'segment');
  if (sourceLanguageHint && sourceLanguageHint !== 'auto') {
    formData.append('language', sourceLanguageHint);
  }

  const baseUrl = config.baseUrl.replace(/\/+$/, '');
  const sttResp = await fetch(`${baseUrl}/audio/transcriptions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.apiKey.trim()}`,
    },
    body: formData,
  });

  if (!sttResp.ok) {
    throw new Error(`فشل الاتصال بالخادم الخارجي (${sttResp.status}).`);
  }

  const sttJson = (await sttResp.json()) as {
    text?: string;
    words?: Array<{ word: string; start: number; end: number }>;
    segments?: Array<{ text: string; start: number; end: number }>;
  };

  let overlays: TextOverlay[] = [];
  if (sttJson.segments && sttJson.segments.length > 0) {
    const allWords = sttJson.words || [];
    overlays = sttJson.segments
      .filter((seg) => seg.text.trim().length > 0)
      .map((seg) => {
        const segDur = Math.max(0.4, seg.end - seg.start);
        const matchedWords = allWords
          .filter((w) => w.start >= seg.start - 0.12 && w.end <= seg.end + 0.15)
          .map((w) => ({
            word: w.word.trim(),
            start: Math.max(0, Number((w.start - seg.start).toFixed(3))),
            end: Math.max(0.05, Number((w.end - seg.start).toFixed(3))),
          }))
          .filter((w) => w.word.length > 0);

        return createSubtitleOverlay({
          text: seg.text.trim(),
          originalText: seg.text.trim(),
          startTime: seg.start,
          duration: segDur,
          wordTimings: matchedWords.length > 0 ? matchedWords : undefined,
        });
      });
  } else if (sttJson.text && sttJson.text.trim()) {
    overlays = generateSubtitlesFromScript(sttJson.text, totalDuration);
  }

  if (targetLanguageCode && targetLanguageCode !== 'none' && overlays.length > 0) {
    const translated = await translateLinesKeyless(
      overlays.map((o) => o.text),
      targetLanguageCode
    );
    overlays = overlays.map((ov, idx) => ({
      ...ov,
      originalText: ov.text,
      text: translated[idx] || ov.text,
      language: targetLanguageCode,
      wordTimings: buildWordTimingsForPhrase(
        translated[idx] || ov.text,
        ov.duration
      ),
    }));
  }

  return overlays;
}
