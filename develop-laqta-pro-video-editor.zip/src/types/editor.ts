export type AspectRatio = '9:16' | '16:9' | '1:1' | '4:5';

export type MediaType = 'video' | 'image' | 'audio';

export interface MediaAsset {
  id: string;
  name: string;
  type: MediaType;
  mimeType: string;
  sizeBytes: number;
  duration: number;
  width?: number;
  height?: number;
  thumbnailDataUrl?: string;
  url: string;
  blob?: Blob;
  waveformPeaks?: number[];
  createdAt: number;
}

// 82 Distinct Color Grading & Atmosphere Filters (each with its own visual icon)
export type FilterType =
  | 'none'
  // Spiritual & Quranic (13)
  | 'dawn-serenity'
  | 'mihrab-gold'
  | 'ramadan-nights'
  | 'mushaf-cream'
  | 'sanctuary-emerald'
  | 'makkah-dusk'
  | 'sahar-stars'
  | 'andalus-blue'
  | 'madinah-marble'
  | 'andalus-gold'
  | 'hijaz-dawn'
  | 'quds-olive'
  | 'cordoba-warmth'
  // Nature, Rivers, Oceans & Travel (22)
  | 'warm'
  | 'golden-hour'
  | 'desert-amber'
  | 'emerald-forest'
  | 'santorini-blue'
  | 'autumn-maple'
  | 'tropical-island'
  | 'palm-oasis'
  | 'amazon-canopy'
  | 'ocean-abyss'
  | 'aurora-sky'
  | 'misty-valley'
  | 'morning-dew'
  | 'sea-breeze'
  | 'atlas-sunset'
  | 'desert-moon'
  | 'cedar-highlands'
  | 'red-sea-coral'
  | 'nile-sunset'
  | 'lavender-fields'
  | 'alpine-crisp'
  | 'monsoon-green'
  // Cinema & Blockbuster (15)
  | 'cinematic'
  | 'hdr-crisp'
  | 'dramatic-noir'
  | 'oppenheimer-gold'
  | 'matrix-code'
  | 'dune-sand'
  | 'avatar-biolum'
  | 'rainy-shadow'
  | 'anamorphic-teal'
  | 'fuji-eterna'
  | 'cool'
  | 'arctic-fade'
  | 'cinema-bleach'
  | 'imax-vivid'
  | 'midnight-express'
  // Neon & Modern Trend (10)
  | 'vivid'
  | 'cyberpunk'
  | 'tokyo-night'
  | 'synthwave-80s'
  | 'miami-vice'
  | 'electric-violet'
  | 'sky-neon'
  | 'twilight-purple'
  | 'neon-lime'
  | 'crimson-velvet'
  // Portrait & Beauty (9)
  | 'rose-glow'
  | 'pastel-dream'
  | 'porcelain-skin'
  | 'peach-blossom'
  | 'soft-velvet'
  | 'pearl-glow'
  | 'kodak-portra'
  | 'golden-skin'
  | 'airy-bright'
  // Classic, Film & Monochrome (12)
  | 'vintage'
  | 'sepia-classic'
  | 'kodak-gold'
  | 'polaroid-fade'
  | 'arabic-coffee'
  | 'film-35mm'
  | 'jerusalem-stone'
  | 'bw'
  | 'silver-chrome'
  | 'noir-contrast-pro'
  | 'platinum-mono'
  | 'agfa-retro';

export interface ColorAdjustments {
  filter: FilterType;
  filterIntensity: number; // 0 to 100
  brightness: number; // -100 to 100
  contrast: number; // -100 to 100
  saturation: number; // -100 to 100
  temperature: number; // -100 (cool) to 100 (warm)
  sharpness: number; // 0 to 100
}

// 72 Distinct Real-Rendered Transitions
export type TransitionType =
  | 'none'
  // Spiritual & Nature Smooth Transitions (15)
  | 'islamic-arch-wipe'
  | 'arch-double-doors'
  | 'octagram-star'
  | 'golden-dissolve'
  | 'soft-mist-fade'
  | 'nature-breeze'
  | 'horizon-rise'
  | 'water-drop-ripple'
  | 'page-curl'
  | 'starlight-flash'
  | 'wave-wipe'
  | 'crescent-moon-wipe'
  | 'emerald-mist'
  | 'sunbeam-sweep'
  | 'sand-breeze'
  // Basic & Light (12)
  | 'fade'
  | 'black-fade'
  | 'white-fade'
  | 'cinematic-dip-white'
  | 'flash'
  | 'light-sweep'
  | 'luma-soft-wipe'
  | 'color-burn'
  | 'blur-dissolve'
  | 'warm-glow-fade'
  | 'cool-shimmer-fade'
  | 'velvet-dark-dip'
  // Camera Motion (19)
  | 'slide'
  | 'slide-right'
  | 'slide-up'
  | 'slide-down'
  | 'diagonal-slide'
  | 'three-panel-slide'
  | 'four-slice-slide'
  | 'corner-reveal'
  | 'zoom-in'
  | 'zoom-out'
  | 'cross-zoom'
  | 'zoom-rotate-smooth'
  | 'whip-pan-blur'
  | 'accordion-fold'
  | 'rotate'
  | 'spin-zoom'
  | 'spiral-spin'
  | 'flip-3d'
  | 'film-roll'
  // Geometric Masks (21)
  | 'curtain-open'
  | 'vertical-curtain'
  | 'double-doors'
  | 'diagonal-split'
  | 'wipe'
  | 'wipe-up'
  | 'split-open'
  | 'split-vertical'
  | 'circle-iris'
  | 'double-ring-iris'
  | 'hexagon-iris'
  | 'octagon-iris'
  | 'cross-wipe'
  | 'diagonal-grid-wipe'
  | 'iris-rectangle'
  | 'diamond-open'
  | 'clock-radial'
  | 'blinds'
  | 'vertical-bars'
  | 'checkerboard-wipe'
  | 'venetian-diagonal'
  // Glitch & Digital FX (4)
  | 'glitch'
  | 'pixelate-trans'
  | 'prism-shift-trans'
  | 'scanline-wipe';

export interface TransitionConfig {
  type: TransitionType;
  duration: number; // seconds, e.g., 0.2 to 2.5
}

export type FitMode = 'blur-fill' | 'cover' | 'contain';

export interface VideoClip {
  id: string;
  assetId: string;
  type: 'video' | 'image';
  name: string;
  trimStart: number;
  duration: number;
  sourceDuration: number;
  speed: number;
  volume: number;
  muted: boolean;
  fitMode: FitMode;
  rotation: 0 | 90 | 180 | 270;
  flipH: boolean;
  kenBurns: boolean;
  adjustments: ColorAdjustments;
  transitionIn: TransitionConfig;
}

// 78 Distinct Real-Rendered Video Effects
export type VideoEffectType =
  // Islamic, Spiritual & Nature Atmosphere (24)
  | 'islamic-arch'
  | 'quran-frame'
  | 'ornate-corners'
  | 'recitation-waveform'
  | 'circular-audio-halo'
  | 'crescent-lanterns'
  | 'golden-arabesque'
  | 'celestial-rays'
  | 'aurora-lights'
  | 'fireflies-forest'
  | 'falling-leaves'
  | 'sakura-petals'
  | 'drifting-clouds'
  | 'ocean-caustics'
  | 'desert-mirage'
  | 'starfield-twinkle'
  | 'dandelion-seeds'
  | 'gentle-snow-mist'
  | 'bokeh-orbs'
  | 'morning-mist'
  | 'water-ripple'
  | 'slow-zoom-in'
  | 'slow-zoom-out'
  | 'gold-shimmer'
  // Motion & Beat (8)
  | 'shake'
  | 'zoom-pulse'
  | 'earthquake'
  | 'pendulum'
  | 'heartbeat-zoom'
  | 'floating-wave'
  | 'spin-dizzy'
  | 'pan-drift'
  // Glitch & Cyber (9)
  | 'rgb-split'
  | 'glitch-cyber'
  | 'matrix-rain'
  | 'scan-laser'
  | 'edge-glow-cyan'
  | 'neon-pulse-border'
  | 'hologram-lines'
  | 'cyber-hud-grid'
  | 'negative-invert'
  // Light, Sun & Bling (13)
  | 'dreamy-glow'
  | 'sunbeams-corner'
  | 'warm-flare-glow'
  | 'shooting-stars'
  | 'sparkle-stars'
  | 'golden-dust'
  | 'light-leak'
  | 'rainbow-prism'
  | 'crystal-diamonds'
  | 'snowfall'
  | 'rain-drops'
  | 'neon-frame'
  | 'strobe'
  // Cinema & Retro Cameras (13)
  | 'cinema-bars'
  | 'cinema-scope-gold'
  | 'letterbox-blur'
  | 'documentary-frame'
  | 'super8-border'
  | 'polaroid-frame'
  | 'retro-vhs'
  | 'vhs-timestamp'
  | 'film-grain'
  | 'sepia-vignette'
  | 'viewfinder-rec'
  | 'cctv-security'
  | 'halftone-comic'
  // Split Screen & Lenses (11)
  | 'three-screen'
  | 'four-grid'
  | 'nine-grid'
  | 'vertical-triptych'
  | 'mirror-split'
  | 'quad-mirror'
  | 'split-diagonal'
  | 'double-exposure'
  | 'fisheye-tunnel'
  | 'pixel-mosaic'
  | 'vignette-focus';

export interface VideoEffectClip {
  id: string;
  effectType: VideoEffectType;
  name: string;
  startTime: number;
  duration: number;
  intensity: number; // 10 to 100
}

export interface OverlayClip {
  id: string;
  assetId: string;
  type: 'video' | 'image';
  name: string;
  startTime: number;
  trimStart: number;
  duration: number;
  sourceDuration: number;
  x: number;
  y: number;
  scale: number;
  opacity: number;
  borderRadius: number;
}

export type TextStylePresetId =
  | 'cinematic'
  | 'colorful'
  | 'rounded-box'
  | 'neon'
  | 'bold-words'
  | 'quran-uthmani';

export type TextAnimationType =
  | 'none'
  | 'fade'
  | 'pop'
  | 'slide-up'
  | 'typewriter'
  | 'pulse';

export interface WordTiming {
  word: string;
  start: number;
  end: number;
}

export interface TextOverlay {
  id: string;
  text: string;
  originalText?: string;
  startTime: number;
  duration: number;
  fontFamily: string;
  fontSize: number;
  fontWeight: number;
  color: string;
  strokeColor: string;
  strokeWidth: number;
  shadowColor: string;
  shadowBlur: number;
  bgColor: string;
  bgOpacity: number;
  bgRadius: number;
  opacity: number;
  align: 'right' | 'center' | 'left';
  x: number;
  y: number;
  animation: TextAnimationType;
  presetId?: TextStylePresetId;
  isSubtitle?: boolean;
  isSticker?: boolean;
  language?: string;
  highlightWords?: boolean;
  highlightColor?: string;
  wordTimings?: WordTiming[];
}

export type AudioCategory = 'music' | 'voiceover' | 'sfx';

export interface AudioClip {
  id: string;
  assetId: string;
  name: string;
  category: AudioCategory;
  startTime: number;
  trimStart: number;
  duration: number;
  sourceDuration: number;
  volume: number;
  muted: boolean;
  fadeIn: number;
  fadeOut: number;
}

export interface ProjectStateSnapshot {
  clips: VideoClip[];
  texts: TextOverlay[];
  audioClips: AudioClip[];
  effects: VideoEffectClip[];
  overlays: OverlayClip[];
  aspectRatio: AspectRatio;
  canvasBgColor: string;
}

export interface ProjectData {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  thumbnailDataUrl?: string;
  aspectRatio: AspectRatio;
  canvasBgColor: string;
  assets: MediaAsset[];
  clips: VideoClip[];
  texts: TextOverlay[];
  audioClips: AudioClip[];
  effects?: VideoEffectClip[];
  overlays?: OverlayClip[];
}

export interface ProjectSummary {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  thumbnailDataUrl?: string;
  aspectRatio: AspectRatio;
  duration: number;
  clipCount: number;
}

export interface ExportSettings {
  resolution: '720p' | '1080p';
  fps: 24 | 30;
  quality: 'standard' | 'high';
}

export interface ExportProgress {
  phase: 'preparing' | 'audio' | 'video' | 'finalizing' | 'done' | 'error';
  percent: number;
  currentFrame: number;
  totalFrames: number;
  message: string;
  engineLabel?: string;
}

export type ActiveToolTab =
  | 'edit'
  | 'quran'
  | 'templates'
  | 'audio'
  | 'text'
  | 'captions'
  | 'stickers'
  | 'overlay'
  | 'effects'
  | 'transitions'
  | 'filters'
  | 'adjust'
  | 'canvas'
  | 'media';

export const DEFAULT_ADJUSTMENTS: ColorAdjustments = {
  filter: 'none',
  filterIntensity: 85,
  brightness: 0,
  contrast: 0,
  saturation: 0,
  temperature: 0,
  sharpness: 0,
};
